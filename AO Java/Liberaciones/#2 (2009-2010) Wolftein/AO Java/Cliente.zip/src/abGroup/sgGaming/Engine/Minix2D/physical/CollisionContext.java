/*
 * @(#)CollisionContext.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical;

/**
 * The description of a class which can compute the collisions of a 
 * set of bodies. This is part of decoupling the algorithm for broad phase
 * collisions against from the physics simulation world.
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public interface CollisionContext {

    /**
     * Resolve and store the collisions betwen each body in the list
     *
     * @param bodies The bodies to be resolved against each other
     * @param dt The time thats passed since last collision check
     */
    public void resolve(BodyList bodies, float dt);
}
