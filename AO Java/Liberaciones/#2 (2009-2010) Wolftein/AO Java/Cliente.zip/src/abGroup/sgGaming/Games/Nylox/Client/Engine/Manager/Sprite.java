//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.Client.Engine.Manager;

import abGroup.sgGaming.Games.Nylox.Client.Foundation.Application;
import abGroup.sgGaming.Minix2D.Renderer.Render2D;
import abGroup.sgGaming.Minix2D.Renderer.Spakt;
import abGroup.sgGaming.Minix2D.Util.Color;

/**
 * This class define a renderer sprite for the game.
 *
 * @author Agustin L. Alvarez
 */
public class Sprite {

    /** The fps locked **/
    protected final static float SPRITE_FRAME_PER_SECOND = Application.APPLICATION_FRAME_PER_SECOND;

    /** Enumeration of the diferent type of animation **/
    public static enum SpriteAnimationType {
        Single,
        Loop
    };

    /** Spakt Object, for better renderer **/
    protected Spakt pkObject;
    /** Sprite animation variables **/
    protected int pkSpriteIndex;
    protected SpriteDataClass pkSprite;
    protected SpriteAnimationType pkAnimation;
    protected float pkFrame, pkFrameLimit, pkFrameStart;
    protected float pkCurrentFrame = 0.0f;
    /** Sprite Animation end **/
    protected boolean pkAnimationEnd;

    /**
     * Constructor
     *
     * @param sprite
     */
    public Sprite( int sprite, SpriteAnimationType type ) {
        setSprite( sprite );
        setAnimationType(type);
    }

    /**
     * Cloneable constructor
     *
     * @param sprite
     */
    public Sprite( Sprite sprite ) {
        setSprite( sprite.pkSprite );
        setAnimationType(sprite.pkAnimation);
        setFrameLimit(sprite.pkFrameLimit);
        setFrameStart(sprite.pkFrameStart);
        setColor(sprite.getColor());
        setRotation(sprite.getRotation());
        setScale(sprite.getScale());
    }

    /**
     * Set the current sprite data.
     *
     * @param sprite Index of the sprite.
     */
    public void setSprite( int sprite ) {
        pkSpriteIndex = sprite;
        pkSprite = SpriteManager.pkSprite.pkSprite[sprite];
        pkObject = new Spakt( pkSprite.pkFilename );
        pkObject.SetTextureSource( pkSprite.pkSourceX, pkSprite.pkSourceY,
                                   pkSprite.pkSourceWidth, pkSprite.pkSourceHeight);
        pkFrameLimit = pkSprite.pkSprite.length;
        pkFrameStart = 0.0f;
        pkFrame      = pkFrameStart;
    }

    /**
     * Set the current sprite data.
     *
     * @param sprite data of the sprite.
     */
    public void setSprite( SpriteDataClass sprite ) {
        pkSpriteIndex = sprite.pkIndex;
        pkSprite = sprite;
        pkObject = new Spakt( pkSprite.pkFilename );
        pkObject.SetTextureSource( pkSprite.pkSourceX, pkSprite.pkSourceY,
                                   pkSprite.pkSourceWidth, pkSprite.pkSourceHeight);
        pkFrameLimit = pkSprite.pkSprite.length;
        pkFrameStart = 0.0f;
        pkFrame      = pkFrameStart;
    }

    /**
     * Set the animation type.
     *
     * @param type Enumeration(Single,Loop)
     */
    public void setAnimationType( SpriteAnimationType type ) {
        pkAnimation = type;
    }

    /**
     * Set a limit of a frame.
     *
     * @param limit
     */
    public void setFrameLimit( float limit ) {
        pkFrameLimit = limit;
    }

    /**
     * Set the frame start.
     *
     * @param start
     */
    public void setFrameStart( float start ) {
        pkFrameStart = start;
    }

    /**
     * Rotate the sprite.
     *
     * @param angle The angle to rotate
     */
    public void setRotation( float angle ) {
        pkObject.SetRotation(angle);
    }
    
    /**
     * @return The sprite rotation
     */
    public float getRotation() {
        return pkObject.getRotation();
    }

    /**
     * Scale the sprite.
     *
     * @param Scale Relative Multiplier size from 0.0f-inf.f
     */
    public void setScale( float Scale ) {
        pkObject.SetScale(Scale, Scale);
    }

    /**
     * @return The sprite scale
     */
    public float getScale() {
        return pkObject.getScaleX();
    }

    /**
     * Set the color of the sprite.
     *
     * @param c The color to set.
     */
    public void setColor( Color c ) {
        pkObject.SetColor(c);
    }

    /**
     * @return The sprite color
     */
    public Color getColor() {
        return pkObject.getColor();
    }

    /**
     * Start the animation.
     */
    public void startAnimation() {
        pkAnimationEnd = false;
    }

    /**
     * Pause the animation.
     */
    public void pauseAnimation() {
        pkAnimationEnd = true;
    }

    /**
     * End the animation.
     */
    public void endAnimation() {
        pauseAnimation();
        pkFrame = pkFrameStart;
        pkCurrentFrame = 0.0f;
    }

    /**
     * @return The sprite index within the database.
     */
    public int getSpriteID() {
        return pkSpriteIndex;
    }

    /**
     * Make the frame time.
     *
     * @param time The time passed
     * @return the frame of the sprite.
     */
    protected SpriteDataClass getNextFrame( float time ) {
        // new frame;
        pkCurrentFrame++;
        // Animation current frame.
        pkFrame = ((pkCurrentFrame * pkFrameLimit) / SPRITE_FRAME_PER_SECOND) + pkFrameStart;
        // Check for end.
        if( pkFrame >= (pkFrameLimit+pkFrameStart) ) {
            // Reset the frame.
            pkCurrentFrame = 0;
            pkFrame = (pkFrameStart - 1.0f < 0.0f ? 0.0f : pkFrameStart );
            // Check for end.
            if( pkAnimation == SpriteAnimationType.Single ) {
                pkAnimationEnd = true;
            }
        }
        return SpriteManager.pkSprite.pkSprite[pkSprite.pkSprite[(int)pkFrame]];
    }

    /**
     * Render the sprite.
     *
     * @param X The position to render.
     * @param Y The position to render.
     * @param animation TRUE if it's animated.
     * @param center TRUE if we need to center the tile.
     */
    public void Render( Render2D g, int X, int Y, float time, boolean animation, boolean center ) {
        SpriteDataClass spriteRender = pkSprite;
        // if it's an animation, then check for the next frame.
        if( animation == true ) {
            // End the animation.
            if( pkAnimationEnd == false && pkSprite.pkSprite.length > 1 ) {
                spriteRender = getNextFrame(time);
            //} else {
            //    spriteRender = SpriteManager.pkSprite.pkSprite[pkSprite.pkSprite[(int)pkFrame]];
            }
        }
        // if we need to center the tile then do it.
        if( center == true ) {
            X = X; // Todo; Sprite#CenterX
            Y = Y; // Todo: Sprite#CenterY
        }
        // Set the object render 
        pkObject.SetTextureSource( spriteRender.pkSourceX, spriteRender.pkSourceY,
                                   spriteRender.pkSourceWidth, spriteRender.pkSourceHeight);
        // set the position where to render.
        pkObject.SetLocation(X, Y);
        // Render the spakt
        pkObject.Render( g );
    }

}
