/*
 * @(#)ScriptCallbackRuby.java	1.0 May 26, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.script;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,May 26, 2010
 * @since
 */
public class ScriptCallbackRuby implements ScriptCallback {

    private boolean present;

    public ScriptCallbackRuby()
    {
        present = isRubyPresent();
    }

    public Object eval(String line) {
        return null;
    }

    public String getHeader() {
        return "[RUBY]";
    }

    public boolean isPresent() {
        return present;
    }

    public boolean isRegisterType() {
        return true;
    }

    public String getRegisterName() {
        return "ruby";
    }

    public String getRegisterPack() {
        return "rb";
    }

    public String getRegisterSource() {
        return "org.jruby.javasupport.bsf.JRubyEngine";
    }

    public String getName() {
        return "jruby";
    }

    private static boolean isRubyPresent() {
        try {
            Class.forName("org.jruby.javasupport.bsf.JRubyEngine");
        } catch (ClassNotFoundException ex) {
            return false;
        }
        return true;
    }


}
