/*
 * @(#)TextSpatial.java	1.0 Feb 12, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D_X.util;

import abGroup.sgGaming.Engine.Minix2D.device.Font;
import abGroup.sgGaming.Engine.Minix2D.device.Font.Aligment;
import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.util.Camera;
import abGroup.sgGaming.Engine.Minix2D.util.Spatial;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 12, 2010
 * @since
 */
public class TextSpatial extends Spatial {

    /** Property **/
    protected String caption = "";
    protected Font font;
    protected Aligment aligment = Aligment.Left;

    /**
     * Constructor
     *
     * @param imageFilename
     * @param x
     * @param y
     * @param z
     */
    public TextSpatial(String fontName, int x, int y, int z) {
        super("",x,y,z);
        font = Font.Retrieve(fontName);
    }

    /**
     * Constructor
     *
     * @param imageFilename
     * @param x
     * @param y
     * @param z
     */
    public TextSpatial(String fontName, int x, int y, int z, String caption) {
        super("",x,y,z);
        font = Font.Retrieve(fontName);
        setCaption(caption);
    }

    /**
     * Set the caption.
     *
     * @param text
     */
    public void setCaption(String text ) {
        caption = text;
    }

    /**
     * Set the aligment.
     *
     * @param alig
     */
    public void setAligment( Aligment alig ) {
        aligment = alig;
    }

    /**
     * Render the spakt.
     *
     * @param g The Graphics2D to render into the device.
     */
    @Override
    public void drawSpatial(Graphics2D g, Camera c) {
        // Enable the Color
        g.setColor(color);
        // Save the transformation
        g.getTransform();
        // get the buffer.
        boolean oldBuffer = g.getDepthBuffer();
        if (oldBuffer != useDepthBuffer) {
            g.setDepthBuffer(useDepthBuffer);
        }
        // Set for the Position for the rotate
        g.translate(translateX + font.getWidth(caption, aligment) / 2, translateY + font.getHeight() / 2, translateZ);
        // Set the Scale
        g.scale(scaleX, scaleY);
        // Set the rotation
        g.rotate(rotateAngle);
        // Pre Effect.
        c.applyPreSpatialRender(g, this);
        // Restore the location
        g.translate(-(translateX + font.getWidth(caption, aligment) / 2), -(translateY + font.getHeight() / 2), -(translateZ));
        // Render the object
        font.write(translateX, translateY, caption, 1.0f, 1.0f, aligment);
        // Pre Effect.
        c.applyPostSpatialRender(g, this);
        // Restore the depth buffer
        if (oldBuffer != useDepthBuffer) {
            g.setDepthBuffer(oldBuffer);
        }
        // Restore the transformation
        g.setTransform();
    }

}
