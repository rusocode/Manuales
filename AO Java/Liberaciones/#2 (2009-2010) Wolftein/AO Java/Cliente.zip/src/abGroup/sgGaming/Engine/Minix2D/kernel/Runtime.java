/*
 * @(#)Runtime.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.kernel;

import abGroup.sgGaming.Engine.Minix2D.device.ImageLoader;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug;
import abGroup.sgGaming.Engine.Minix2D.util.filesystem.ClassLoader;
import java.applet.Applet;
import java.io.File;
import java.security.AccessController;
import java.security.PrivilegedAction;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class Runtime {

    /** Minix2D Kernel version **/
    protected static String KERNEL_VERSION = "RT 1.0.4501";
    /** This is the resource class loader **/
    protected static ClassLoader rtClassLoader;
    /** This is the debug class **/
    protected static ClassDebug rtClassDebug = new ClassDebug();
    /** This is the image loader **/
    protected static ImageLoader vmImageLoader;
    protected static BaseApplication vmKernel;

    public static void createRuntime( Applet app ) {
        String basecode = (app == null ? null : getLocalPathFromAppletLauncher(app));
        rtClassLoader = new ClassLoader(basecode);
    }

    public static String getKernelVersion() {
        return KERNEL_VERSION;
    }

    public static BaseApplication getKernel() {
        return vmKernel;
    }

    public static ImageLoader getImageLoader() {
        return vmImageLoader;
    }

    public static void provideImageLoader(ImageLoader il) {
        vmImageLoader = il;
    }

    public static ClassLoader getClassLoader() {
        return rtClassLoader;
    }

    public static ClassDebug getClassDebug() {
        return rtClassDebug;
    }

    public static String getPrivilegeString(final String property) {
        return (String) AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
                return System.getProperty(property);
            }
        });
    }

    private static String getLocalPathFromAppletLauncher(Applet t) {
        String tmpDir = getPrivilegeString("java.io.tmpdir");
        // we append the code base to avoid naming collisions with al_title
        String codebase = "";
        if (getBooleanParameter(t, "al_prepend_host", true)) {
            codebase = t.getCodeBase().getHost();
            if (codebase == null || codebase.length() == 0) {
                codebase = "localhost";
            }
            codebase += File.separator;
        }
        return tmpDir + File.separator + codebase + t.getParameter("al_title") + File.separator;
    }

	/**
	 * Retrieves the boolean value for the applet
	 * @param name Name of parameter
	 * @param defaultValue default value to return if no such parameter
	 * @return value of parameter or defaultValue
	 */
	protected static boolean getBooleanParameter(Applet t, String name, boolean defaultValue) {
		String parameter = t.getParameter(name);
		if(parameter != null) {
			return Boolean.parseBoolean(parameter);
		}
		return defaultValue;
	}
}
