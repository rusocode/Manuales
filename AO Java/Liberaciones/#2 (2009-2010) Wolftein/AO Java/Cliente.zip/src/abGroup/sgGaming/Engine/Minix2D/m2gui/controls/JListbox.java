/*
 * @(#)JListbox.java	1.0 Feb 2, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.m2gui.controls;

import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import abGroup.sgGaming.Engine.Minix2D.device.Color;
import abGroup.sgGaming.Engine.Minix2D.device.Font;
import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.input.Keyboard;
import abGroup.sgGaming.Engine.Minix2D.input.Keyboard.enumKeyboardKey;
import abGroup.sgGaming.Engine.Minix2D.input.Mouse;
import abGroup.sgGaming.Engine.Minix2D.input.Mouse.MouseButton;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Control;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Drawable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Eventable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Focuseable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Keyable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Mouseable;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLException;
import java.util.ArrayList;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 2, 2010
 * @since JDK 1.6
 */
public class JListbox extends Control implements Drawable, Eventable, Focuseable, Keyable, Mouseable {

    /** Select Texture **/
    protected String imageSelect = "";
    protected Color colorSelect = Color.White;
    /** Each Value **/
    protected ArrayList<JLabel> line = new ArrayList<JLabel>();
    /** Cursor Variables **/
    protected int cursor = 0, cursorFirst = 0, cursorLast = 0, cursorMax;
    protected int mouseY;
    /** Use of Font **/
    protected Font font;

    /**
     * Constructor
     *
     * @param x
     * @param y
     * @param f
     */
    public JListbox(int x, int y, Font f) {
        super("JListbox");
        setPosition(new Vector2f(x, y));
        font = f;
    }

    /**
     * Constructor
     *
     * @param element
     * @throws XMLException
     */
    public JListbox(XMLElement element) throws XMLException {
        this(0, 0, null);
        parse(element);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Control#parse(abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement)
     */
    @Override
    public void parse(XMLElement element) throws XMLException {
        // Control parse native.
        super.parse(element);
        // JPicture propertys.
        String[] xmlProperty = element.getAttributeNames();
        String currentProperty;
        for (int i = 0; i < xmlProperty.length; i++) {
            currentProperty = xmlProperty[i].toUpperCase();
            if (currentProperty.equals("COLOR")) {
                setColor(Color.parseOf(element.getAttribute("Color")));
            } else if (element.getAttributeNames()[i].toUpperCase().equals("IMAGE")) {
                setImage(element.getAttribute("Image"));
            }
        }
    }

    /**
     * Set the font of the values
     *
     * @param f Font to set.
     */
    public void setFont(Font f) {
        font = f;
        cursorMax = this.height / f.getHeight();
    }

    /**
     * Set the texture for the selection image.
     *
     * @param picName The picture name to load.
     */
    public void setImage(String picName) {
        imageSelect = picName;
    }

    /**
     * Set the select color.
     *
     * @param c The color to set.
     */
    public void setColor(Color c) {
        colorSelect = c;
    }

    /**
     * Set the caption of a line.
     *
     * @param index
     * @param s
     */
    public void setValue(int index, String s) {
        line.get(index).setCaption(s);
    }

    /**
     * Set the color of a line.
     *
     * @param index
     * @param c
     */
    public void setColor(int index, Color c) {
        line.get(index).setColor(c);
    }

    /**
     * Clear all the listbox values.
     */
    public void clear() {
        line.clear();
    }

    /**
     * Add a value to the list.
     *
     * @param s
     */
    public void addValue(String s) {
        JLabel b = new JLabel(0, 0, font);
        b.setSize(new Vector2f(width, font.getHeight()));
        b.setCaption(s);
        line.add(b);
        setCursorPosition(cursor + 1);  // Move the column one down.
    }

    /**
     * Move the cursor.
     *
     * @param relative The relative position within the current position
     */
    public void cursorMove(int relative) {
        setCursorPosition(cursor + relative);
    }

    /**
     * @return The selected node index.
     */
    public int getSelectedIndex() {
        return cursor;
    }

    /**
     * @return The current selected string.
     */
    public String getSelected() {
        return line.get(cursor).caption;
    }

    /**
     * Set the cursor position to the index.
     *
     * @param index
     */
    private void setCursorPosition(int index) {
        int deltaCursor = cursor;
        // Normalize the boundary
        cursor = index;
        if (cursor < 0) {
            cursor = 0;
        }
        if (cursor >= line.size()) {
            cursor = line.size() - 1;
            if (cursor < 0) {
                cursor = 0;
            }
        }
        deltaCursor -= cursor;
        // Check for first index
        if (cursor < cursorFirst) {
            // Normalize the first boundary
            if (cursorFirst < 0) {
                cursorFirst = 0;
            }
            cursorFirst = cursor;
            cursorLast = cursorFirst + cursorMax;
            // Normalize the last boundary.
            if (cursorLast > line.size()) {
                cursorLast = line.size();
            }
        } else if (cursor > cursorLast) {
            cursorLast -= deltaCursor;
            if (cursorLast > line.size()) {
                cursorLast = line.size();
            }
            cursorFirst = cursorLast - cursorMax;
            if (cursorFirst < 0) {
                cursorFirst = 0;
            }
        } else {
            cursorLast = cursorFirst + cursorMax;
            if (cursorLast > line.size()) {
                cursorLast = line.size();
            }
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Drawable#Drawable(abGroup.sgGaming.Engine.Minix2D.device.Graphics2D, int, int)
     */
    public void Drawable(Graphics2D g, int x, int y) {
        for (int i = cursorFirst; i < cursorLast; i++) {
            int index = cursorFirst - i;
            // not negative.
            if (index < 0) {
                index = -index;
            }
            // Render the Current Selection
            if (i == cursor) {
                // Render the Selection Image.
                if (imageSelect != null) {
                    // Bind the Selection Color.
                    g.setColor(colorSelect);
                    g.drawImage(Runtime.getImageLoader().getImage(imageSelect),
                            this.x + x, this.y + y + (font.getHeight() * index));
                }
            }
            // Render the label Color
            line.get(i).Drawable(g, x + this.x, y + this.y + (font.getHeight() * index));
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Keyable
     */
    public void keyDown(enumKeyboardKey key, Keyboard trigger) {
        keyPress(key, trigger);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Keyable
     */
    public void keyRelease(enumKeyboardKey key, Keyboard trigger) {
        return;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Keyable
     */
    public void keyPress(enumKeyboardKey key, Keyboard trigger) {
        switch (key) {
            case KEY_UP:
                cursorMove(-1);
                break;
            case KEY_DOWN:
                cursorMove(+1);
                break;
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Mouseable
     */
    public void mouseMove(int dX, int dY, int rX, int rY) {
        mouseY = dY;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Mouseable
     */
    public void mouseButton(MouseButton button) {
        if (button == Mouse.MouseButton.BUTTON_LEFT) {
            setCursorPosition(cursorFirst + mouseY / font.getHeight());
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Mouseable
     */
    public void mouseWheel(int WheelNumber) {
        if (WheelNumber > 0) {
            cursorMove(-1);
        } else {
            cursorMove(+1);
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Focuseable
     */
    public boolean focus(boolean bValue) {
        return true;
    }
}
