/*
 * @(#)FileSystemStreamZip.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.util.filesystem;

import de.schlichtherle.io.File;
import de.schlichtherle.io.FileInputStream;
import de.schlichtherle.io.FileOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class FileSystemStreamZip implements FileSystemStream {

    /** This is the path of the file system **/
    private String fsPath;

    public FileSystemStreamZip(String path) {
        fsPath = path;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.util.filesystem.FileSystemStream#create(java.lang.String)
     */
    public void create(String path) throws IOException {
        // Create the raw stream.
        FileSystemStream stream = new FileSystemStreamFile(fsPath);
        // Check if it exist
        if (stream.check(fsPath + path) == true) {
            return;
        }
        // Create the file
        stream.create(fsPath + path);
        // Get the Output Stream.
        DataOutputStream out = stream.retrieve(fsPath + path);
        // Zip Header
        byte[] zipHeader = new byte[]{0x50, 0x4B, 0x05, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
        // Put the Header
        out.write(zipHeader);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.util.filesystem.FileSystemStream#load(java.lang.String)
     */
    public byte[] load(String filename) throws IOException {
        // Open the input stream.
        InputStream fileStream = new FileInputStream(fsPath + filename);
        // Read the bytes from the input stream.
        byte[] inputBytes = new byte[fileStream.available()];
        fileStream.read(inputBytes, 0, fileStream.available());
        fileStream.close();
        // Return the loaded bytes.
        return inputBytes;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.util.filesystem.FileSystemStream#open(java.lang.String)
     */
    public DataInputStream open(String filename) throws IOException {
        File file = new File(fsPath + filename);
        // Open the input stream.
        InputStream fileStream = new FileInputStream(fsPath + file);
        // Return the Stream
        return new DataInputStream(fileStream);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.util.filesystem.FileSystemStream#getFileList(java.lang.String)
     */
    public String[] getFileList(String path) {
        // Open the Directory
        File f = new File(fsPath + path);
        // Return the path
        return f.list();
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.util.filesystem.FileSystemStream#retrieve(java.lang.String)
     */
    public DataOutputStream retrieve(String filename) throws IOException {
        if (check(filename) == false) {
            // Open the file
            File file = new File(fsPath + filename);
            // Create the file
            file.createNewFile();
        }
        // get the output stream
        OutputStream out = new FileOutputStream(fsPath + filename);
        // return the output stream
        return new DataOutputStream(out);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.util.filesystem.FileSystemStream#check(java.lang.String)
     */
    public boolean check(String filename) {
        return new File(fsPath + filename).exists();
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.util.filesystem.FileSystemStream#delete(java.lang.String)
     */
    public void delete(String filename) {
        new File(fsPath + filename).delete();
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.util.filesystem.FileSystemStream#getLocalPath()
     */
    public String getLocalPath() {
        return fsPath;
    }
}
