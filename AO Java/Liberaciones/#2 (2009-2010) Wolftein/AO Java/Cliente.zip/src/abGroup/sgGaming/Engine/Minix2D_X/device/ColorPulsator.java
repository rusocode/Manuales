/*
 * @(#)ColorPulsator.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D_X.device;

import abGroup.sgGaming.Engine.Minix2D.device.Color;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class ColorPulsator extends Color {

    /** This is the color pulsator **/
    protected Color pkColorPulsator;
    protected Color pkBaseColor;
    /** Pulsator Property **/
    protected boolean pkDirection = true;
    protected float pkFrame;
    protected float pkCurrentFrame;
    protected boolean pkOneDirection = false;
    protected boolean pkAlready = false;

    /**
     * Constructor
     *
     * @param red
     * @param green
     * @param blue
     * @param alpha
     */
    public ColorPulsator(float red, float green, float blue, float alpha) {
        super(red, green, blue, alpha);
        pkBaseColor = new Color(red, green, blue, alpha);
    }

    /**
     * Constructor
     *
     * @param c
     */
    public ColorPulsator(Color c) {
        super(c);
        pkBaseColor = new Color(c);
    }

    /**
     * Set the color pulsator.
     *
     * @param c
     */
    public void setPulsator(Color c) {
        pkColorPulsator = c;

    }

    /**
     * Set if the color only reach one of the end or start.
     * @param value
     */
    public void setOriginDestination(boolean value) {
        pkOneDirection = value;
    }

    /**
     * Reset the frame already.
     */
    public void resetFrame() {
        pkAlready = false;
    }

    /**
     * Set the frame timer.
     *
     * @param frame
     */
    public void setFrameTimer(float frame) {
        pkFrame = frame;
    }

    /**
     * Make the color pulsator logical.
     */
    public void Logical() {
        // Top direction.
        if (pkDirection == true && pkAlready == false) {
            // Add a frame.
            pkCurrentFrame += 1.0f;
            // Each Color.
            for (int i = 0; i < colorArray.length; i++) {
                // Only add the color if it's not the max.
                if (colorArray[i] < pkColorPulsator.colorArray[i]) {
                    colorArray[i] = (pkCurrentFrame * pkColorPulsator.colorArray[i]) / pkFrame;
                }
            }
            // Change the direction.
            if (pkCurrentFrame == pkFrame) {
                pkAlready = (pkOneDirection == true ? true : false);
                pkDirection = false;
            }
            // Down direction
        } else if (pkDirection == false && pkAlready == false) {
            // Add a frame.
            pkCurrentFrame -= 1.0f;
            // Each Color.
            for (int i = 0; i < colorArray.length; i++) {
                // Only add the color if it's not the max.
                if (colorArray[i] != pkBaseColor.colorArray[i]) {
                    colorArray[i] = (pkCurrentFrame * pkColorPulsator.colorArray[i]) / pkFrame;
                }
            }
            // Change the direction.
            if (pkCurrentFrame <= 0) {
                pkAlready = (pkOneDirection == true ? true : false);
                pkDirection = true;
            }
        }
    }
}
