/*
 * @(#)implShader.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl;

import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import abGroup.sgGaming.Engine.Minix2D.device.Shader;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug.TypeDebug;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug.TypeDebugChannel;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.ARBFragmentShader;
import org.lwjgl.opengl.ARBShaderObjects;
import org.lwjgl.opengl.ARBVertexProgram;
import org.lwjgl.opengl.ARBVertexShader;
import org.lwjgl.opengl.ContextCapabilities;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GLContext;
import org.lwjgl.opengl.Util;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class implShader extends Shader {

    /** Opengl Support version **/ 
    private static boolean useNative;
    /** Shader information **/
    protected int vertexShader = 0, fragmentShader = 0, programShader = 0;
    
    /**
     * Constructor
     * 
     * @param name
     * @param vertex
     * @param fragment
     * @throws IOException
     */
    public implShader( String name, String vertex, String fragment) throws IOException {
        super(name);
        // check for supported shader.
        if( isSupported() == false ) {
            Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                    TypeDebug.ERROR,
                    "Shaders aren't allowed, please check your opengl drivers also check that your current driver card support it");
        }
        createShaderFromFile(vertex,fragment);
    }
    
    /**
     * Create the program/fragment shader from the file.
     *
     * @param vertex
     * @param fragment
     * @throws IOException
     */
    private void createShaderFromFile( String vertex, String fragment ) throws IOException {
        String fileData;
        ByteBuffer fileBuffer;
        // Create the program.
        programShader = ARBShaderObjects.glCreateProgramObjectARB();
        // Create the vertex shader if we have.
        if (vertex != null) {
            // Create the vs object.
            vertexShader = ARBShaderObjects.glCreateShaderObjectARB(ARBVertexShader.GL_VERTEX_SHADER_ARB);
            // load the file and save it into a string.
            fileData = super.getDataFromStream(Runtime.getClassLoader().getResourceAsStream(vertex));
            fileBuffer = super.getDataIntoByteBuffer(fileData);
            ARBShaderObjects.glShaderSourceARB(vertexShader, fileBuffer);
            ARBShaderObjects.glCompileShaderARB(vertexShader);
            printShaderError(vertexShader);
            ARBShaderObjects.glAttachObjectARB(programShader, vertexShader);
        }
        // Create the fragment shader if we have.
        if (fragment != null) {
            // Create the vs object.
            fragmentShader = ARBShaderObjects.glCreateShaderObjectARB(ARBFragmentShader.GL_FRAGMENT_SHADER_ARB);
            // load the file and save it into a string.
            fileData = super.getDataFromStream(Runtime.getClassLoader().getResourceAsStream(fragment));
            fileBuffer = super.getDataIntoByteBuffer(fileData);
            ARBShaderObjects.glShaderSourceARB(fragmentShader, fileBuffer);
            ARBShaderObjects.glCompileShaderARB(fragmentShader);
            printShaderError(fragmentShader);
            ARBShaderObjects.glAttachObjectARB(programShader, fragmentShader);
        }
        // Compile, link and validate.
        ARBShaderObjects.glLinkProgramARB(programShader);
        printShaderError(programShader);
        ARBShaderObjects.glValidateProgramARB(programShader);
    }

    /**
     * Print an error of the shader in case of error.
     *
     * @param shader
     */
    private void printShaderError(int shader) {
        IntBuffer iVal = BufferUtils.createIntBuffer(1);
        ARBShaderObjects.glGetObjectParameterARB(shader, ARBShaderObjects.GL_OBJECT_INFO_LOG_LENGTH_ARB, iVal);

        int length = iVal.get();
        if (length > 0) {
            ByteBuffer infoLog = BufferUtils.createByteBuffer(length);
            iVal.flip();
            ARBShaderObjects.glGetInfoLogARB(shader, iVal, infoLog);
            byte[] infoBytes = new byte[length];
            infoLog.get(infoBytes);
            String out = new String(infoBytes);
            if (out.equals("") != false) {
                Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                        TypeDebug.WARNING,
                        out);
            }
        }
        Util.checkGLError();
    }
    
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Shader
     */
    @Override
    public void enable() {
        if (useNative == true) {
            GL11.glEnable(ARBVertexProgram.GL_VERTEX_PROGRAM_ARB);
            GL20.glUseProgram(programShader);
        } else {
            ARBShaderObjects.glUseProgramObjectARB(programShader);
        }
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Shader
     */
    @Override
    public void disable() {
        if (useNative == true) {
            GL11.glDisable(ARBVertexProgram.GL_VERTEX_PROGRAM_ARB);
            GL20.glUseProgram(0);
        } else {
            ARBShaderObjects.glUseProgramObjectARB(0);
        }
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Shader
     */
    @Override
    public int getUniformVariable(String variable) {
        return getUniformLocation( programShader, variable );
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Shader
     */
    @Override
    public void setUniform1fARB(int variable, float a) {
        ARBShaderObjects.glUniform1fARB(variable, a);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Shader
     */
    @Override
    public void setUniform2fARB(int variable, float a, float b) {
        ARBShaderObjects.glUniform2fARB(variable, a, b);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Shader
     */
    @Override
    public void setUniform3fARB(int variable, float a, float b, float c) {
        ARBShaderObjects.glUniform3fARB(variable, a, b, c);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Shader
     */
    @Override
    public void setUniform4fARB(int variable, float a, float b, float c, float d) {
        ARBShaderObjects.glUniform4fARB(variable, a, b, c, d);
    }

    /**
     * @return If the shader is supported.
     */
    public static boolean isSupported() {
        // get the context capabilities.
        ContextCapabilities caps = GLContext.getCapabilities();
        // Check opengl2.0
        if (caps.OpenGL20 == true) {
            // OpenGL 2.0 requires both vertex and fragment shader functionality.
            Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                    TypeDebug.INFORMATION,
                    "Vertex and fragment shaders are supported in the GL core!");
            return true;
        } else {
            // we dont support native opengl call.
            useNative = false;
            if (!(caps.GL_ARB_vertex_shader || caps.GL_ARB_fragment_shader)) {
                return false;
            }
            Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                    TypeDebug.INFORMATION,
                    "Vertex and fragment shaders are supported in the ARB extension!");
            return true;
        }
    }

    /**
     * Return the uniformat variable location.
     *
     * @param ID
     * @param name
     * @return
     */
    private static int getUniformLocation(int ID, String name) {
        ByteBuffer buffer = BufferUtils.createByteBuffer(1024 * 10);

        int length = name.length();

        char[] charArray = new char[length];
        name.getChars(0, length, charArray, 0);

        for (int i = 0; i < length; i++) {
            buffer.put((byte) charArray[i]);
        }
        buffer.put((byte) 0); // Must be null-terminated.
        buffer.flip();

        final int location = ARBShaderObjects.glGetUniformLocationARB(ID, buffer);

        if (location == -1) {
            throw new IllegalArgumentException("The uniform \"" + name + "\" does not exist in the Shader Program.");
        }
        return location;
    }

    @Override
    public void setUniform1iARB(int variable, int a) {
        ARBShaderObjects.glUniform1iARB(variable, a);
    }

    @Override
    public void setUniform2iARB(int variable, int a, int b) {
        ARBShaderObjects.glUniform2iARB(variable, a, b);
    }

    @Override
    public void setUniform3iARB(int variable, int a, int b, int c) {
        ARBShaderObjects.glUniform3iARB(variable, a, b, c);
    }

    @Override
    public void setUniform4iARB(int variable, int a, int b, int c, int d) {
        ARBShaderObjects.glUniform4iARB(variable, a, b, c, d);
    }

}
