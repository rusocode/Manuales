/*
 * @(#)implImageLoader.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl;

import abGroup.sgGaming.Engine.Minix2D.math.FastMath;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.device.Image;
import abGroup.sgGaming.Engine.Minix2D.device.ImageLoader;
import abGroup.sgGaming.Engine.Minix2D.device.ImageObserver;
import abGroup.sgGaming.Engine.Minix2D.util.thread.ThreadContext;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferByte;
import java.awt.image.DataBufferInt;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class implImageLoader extends ImageLoader {

    /** Scratch buffer for texture ID's */
    private IntBuffer idBuffer = BufferUtils.createIntBuffer(1);
    /** Default Texture **/
    //private Image defaultTexture;

    /**
     * Constructor
     */
    public implImageLoader(String texture) {
        // create the default texture
        //ImageObserver ob = new ImageObserver(texture);
        //ob.run();
        //defaultTexture = createTexture(ob);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.ImageLoader
     */
    @Override
    public Image createImage( int width, int height ) {
        // generate the opengl texture id.
        int textureID = generateValidID( );
        // create the image.
        Image image = new Image( "onFlyImage", new Vector2f(width,height), textureID );
        image.setTextureVector( new Vector2f( FastMath.getClosedPowerTwo(width), FastMath.getClosedPowerTwo(height)));
        // Bind the texture into opengl.
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureID);
        // Check for alpha color.
        int srcPixelFormat = GL11.GL_RGBA;
        // Texture2D Property.
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        // produce a texture from the byte buffer
        GL11.glTexImage2D(GL11.GL_TEXTURE_2D,
                0,
                GL11.GL_RGBA,
                FastMath.getClosedPowerTwo(image.getWidth()),
                FastMath.getClosedPowerTwo(image.getHeight()),
                0,
                srcPixelFormat,
                GL11.GL_UNSIGNED_BYTE,
                (ByteBuffer) null);
        return image;
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.ImageLoader
     */
    @Override
    public Image createImageData( int width, int height ) {
        Image image = new Image("OnFly", new Vector2f(width,height), generateValidID() );
        image.setTextureVector(new Vector2f( FastMath.getClosedPowerTwo(width), FastMath.getClosedPowerTwo(height)));
        return image;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.ImageLoader
     */
    @Override
    public Image getImage(String image) {
        Image imageLoaded = super.getImage(image);
        // if we didn't find the image in the cache.
        if (imageLoaded == null) {
            // create a default image.
            imageLoaded = new Image("", new Vector2f(0, 0), 0);
            imageLoaded.setTextureVector(new Vector2f(0, 0));
            ImageObserver ob = new ImageObserver(image);
            // add to the loading list.
            loadingTextureList.add(imageLoaded);
            loadingTexture.put(imageLoaded, ob);
            // Create the threads for the loading.
            ThreadContext loadThread = new ThreadContext("ImageObserver", ob);
            loadThread.start();
            // add it to the cache
            cacheTexture.put(image, imageLoaded);
        }
        return imageLoaded;
    }

    /**
     * @note This functions is called within the Opengl Context.
     *
     * @see abGroup.sgGaming.Engine.Minix2D.device.ImageLoader
     */
    @Override
    protected Image createTexture(ImageObserver ob) {
        // generate the opengl texture id.
        int textureID = generateValidID( );
        // create the image.
        Image image = new Image( ob.getTextureName(), ob.getImageSize(), textureID );
        image.setTextureVector( ob.getTextureSize() );
        // Bind the texture into opengl.
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureID);
        // Check for alpha color.
        int srcPixelFormat = (ob.isTextureAlphaChannel() == true ? GL11.GL_RGBA : GL11.GL_RGB);
        // Texture2D Property.
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        // produce a texture from the byte buffer
        GL11.glTexImage2D(GL11.GL_TEXTURE_2D,
                0,
                GL11.GL_RGBA,
                FastMath.getClosedPowerTwo(image.getWidth()),
                FastMath.getClosedPowerTwo(image.getHeight()),
                0,
                srcPixelFormat,
                GL11.GL_UNSIGNED_BYTE,
                ob.getTextureData());
        return image;
    }

    /**
     * @note This functions is called within the Opengl Context.
     *
     * @see abGroup.sgGaming.Engine.Minix2D.device.ImageLoader
     */
    @Override
    public void convertBufferedImage(BufferedImage bufferedimage, Image image) {
        try {
            short width = (short) image.getWidth();
            short height = (short) image.getHeight();
            int bpp = (byte) bufferedimage.getColorModel().getPixelSize();
            ByteBuffer byteBuffer;
            DataBuffer db = bufferedimage.getData().getDataBuffer();
            if (db instanceof DataBufferInt) {
                int intI[] = ((DataBufferInt) (bufferedimage.getData().getDataBuffer())).getData();
                byte newI[] = new byte[intI.length * 4];
                for (int i = 0; i < intI.length; i++) {
                    byte b[] = intToByteArray(intI[i]);
                    int newIndex = i * 4;

                    newI[newIndex] = b[1];
                    newI[newIndex + 1] = b[2];
                    newI[newIndex + 2] = b[3];
                    newI[newIndex + 3] = b[0];
                }

                byteBuffer = ByteBuffer.allocateDirect(
                        width * height * (bpp / 8)).order(ByteOrder.nativeOrder()).put(newI);
            } else {
                byteBuffer = ByteBuffer.allocateDirect(
                        width * height * (bpp / 8)).order(ByteOrder.nativeOrder()).put(((DataBufferByte) (bufferedimage.getData().getDataBuffer())).getData());
            }
            byteBuffer.flip();

            int internalFormat = GL11.GL_RGBA8,
                    format = GL11.GL_RGBA;
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, image.getTextureID());
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL11.GL_CLAMP);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL11.GL_CLAMP);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
            GL11.glTexEnvf(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_MODULATE);

            GLU.gluBuild2DMipmaps(GL11.GL_TEXTURE_2D,
                    internalFormat,
                    width,
                    height,
                    format,
                    GL11.GL_UNSIGNED_BYTE,
                    byteBuffer);
        } catch (Exception e) {
        }
    }

   /**
     * Convert integer to byte array.
     *
     * @param value
     * @return
     */
    private byte[] intToByteArray(int value) {
        return new byte[]{
                    (byte) (value >>> 24),
                    (byte) (value >>> 16),
                    (byte) (value >>> 8),
                    (byte) value};
    }

    /**
     * @return A new validated opengl id.
     */
    private int generateValidID() {
        GL11.glGenTextures(idBuffer);
        return idBuffer.get(0);
    }

}
