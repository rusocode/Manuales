//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.Client.Foundation;

import abGroup.sgGaming.Games.Nylox.Client.Engine.Manager.VirtualState;
import abGroup.sgGaming.Games.Nylox.Client.Foundation.Space.NetworkMessageFactory;
import abGroup.sgGaming.Games.Nylox.Client.Foundation.Space.vpCharacterMessage;
import abGroup.sgGaming.Games.Nylox.Client.Foundation.Space.vpLoginMessage;
import abGroup.sgGaming.Minix2D.Foundation.Singleton;
import abGroup.sgGaming.Minix2D.Gui.Object.Button;
import abGroup.sgGaming.Minix2D.Gui.Object.Label;
import abGroup.sgGaming.Minix2D.Gui.Object.Listbox;
import abGroup.sgGaming.Minix2D.Gui.Object.MessageBox;
import abGroup.sgGaming.Minix2D.Gui.Property.ActionTrigger;
import abGroup.sgGaming.Minix2D.Gui.System;
import abGroup.sgGaming.Minix2D.Networking.Message.Message;
import abGroup.sgGaming.Minix2D.Networking.Message.MessageChannel;
import abGroup.sgGaming.Minix2D.Networking.Transport.TransportFactory;
import abGroup.sgGaming.Minix2D.Networking.UrlConnection;
import abGroup.sgGaming.Minix2D.Util.Tokenizer;
import java.io.IOException;

/**
 *
 * @author Agustin L. Alvarez
 */
public class vsClientServer implements VirtualState {
    /** Language used by this vs **/
    private final static String GAME_LANGUAGE_ERROR = "GetLocaleID(SystemError)";
    private final static String GAME_LANGUAGE_SERVER_OFFLINE = "GetLocaleID(FoundationNetworkID2)";
    /** Refresh Variables and Constant **/
    private final static int GAME_REFRESH_TIME = 6000;
    private final static String GAME_MASTER_SERVER = "http://www.nylox-online.com.ar";
    private float pkRefreshTime;

    private vpCharacterMessage pkCharacter;
    /** This boolean represent if the state need to continue **/
    private boolean pkFinish = false;
    /** Master server information **/
    private String[] pkInformation; // (SESSION,NAME,FIRSTNAME,LASTNAME,AGE,EMAIL)
    private String[][] pkServer; // (IP,PORT,NAME,ONLINE,MAXONLINE)

    /**
     * Constructor
     * 
     * @param information the list of string that we retrieve from the master server
     */
    public vsClientServer( String[] information ) {
        pkInformation = information;
        createRuntimeControl( );
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public String getStateName() {
        return "vsClientServer";
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public void Execute(float virtualTimer) {
        // refresh the game server states.
        pkRefreshTime += virtualTimer;
        if( pkRefreshTime >= GAME_REFRESH_TIME ) {
            // Reset the counter.
            pkRefreshTime = 0;
            // Connect into the master server and send the retrieve packet
            UrlConnection postConnection = new UrlConnection(GAME_MASTER_SERVER);
            if( postConnection.Post("validation.php?type=refresh", "s=" + pkInformation[0] ) == true ) {
                // we are connected into the master server and he send us
                // the list of servers.
                String postData = postConnection.GetBuffer().toString();
                pkServer = new String[Tokenizer.Count(postData, "<br>")][];
                for( int i = 0; i < pkServer.length; i++ ) {
                    String servData = Tokenizer.Tokenize(postData, i, "<br>");
                    pkServer[i] = new String[Tokenizer.Count(servData, "\n")];
                    for( int j = 0; j < pkServer[i].length; j++ ) {
                        pkServer[i][j] = Tokenizer.Tokenize(servData, i, "\n");
                    }
                }
            } else {
                // This means that the master server is closed.
                // Nothing to do yet.
                pkServer = null;
            }
            // Update the listbox that contain the server list
            refreshRuntimeListbox();
        }
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public boolean hasNextState() {
        return true;
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public VirtualState getNextState() {
        return new vsClientCharacter(pkCharacter);
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public VirtualState getPrevState() {
        return new vsClientLogin();
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public boolean isFinished() {
        return pkFinish;
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public void parseMessage(Message c) {
        // Character list message.
        if( c.getID() == vpCharacterMessage.ID ) {
            pkCharacter = (vpCharacterMessage)c;
            pkFinish = true;
        }
    }
    /**
     * Refresh all the listbox in runtime with the list of servers.
     */
    private void refreshRuntimeListbox() {
       System g = Singleton.GetEngine().GetUserSystem();
       Listbox lst = ((Listbox)g.ControlRetrieve("lstWorld"));
       // Clear the previues listbox values.
       lst.Clear();
       // Add all the game servers founds.
       for( int i = 0; i < pkServer.length; i++ ) {
           lst.AddValue( buildServerDescription(i) );
       }
    }
    /**
     * Build the server description from the data recieved.
     *
     * @param index
     * @return
     */
    private String buildServerDescription( int index ) {
       return String.format("%s\t\t%d/%d", pkServer[index][2], pkServer[index][3], pkServer[index][4] );
    }
    /**
     * Create the runtime controls for the state.
     */
    private void createRuntimeControl() {
        System g = Singleton.GetEngine().GetUserSystem();
        ((Button)g.ControlRetrieve("btnLogin")).SetCallback(actionLogin);
        ((Label)g.ControlRetrieve("lblAccount_")).SetCaption(pkInformation[1]);
        buildLabelResize( (Label)g.ControlRetrieve("lblName"), (Label)g.ControlRetrieve("lblName_"), pkInformation[2] );
        buildLabelResize( (Label)g.ControlRetrieve("lblLastName"), (Label)g.ControlRetrieve("lblLastName_"), pkInformation[3] );
        buildLabelResize( (Label)g.ControlRetrieve("lblAge"), (Label)g.ControlRetrieve("lblAge_"), pkInformation[4] );
        buildLabelResize( (Label)g.ControlRetrieve("lblEmail"), (Label)g.ControlRetrieve("lblEmail_"), pkInformation[5] );
    }
    /**
     * Edit in runtime the labels control that need autoresize and has some account data caption.
     * 
     * @param source
     * @param dest
     * @param caption
     */
    private void buildLabelResize( Label source, Label dest, String caption ) {
        dest.SetPosition(source.GetPositionX() + source.GetWidth(), dest.GetPositionY());
        dest.SetCaption(caption);
    }

    /**
     * @Callback -> #btnLogin
     * @description Login the client into the game server.
     */
    private ActionTrigger actionLogin = new ActionTrigger( ) {
        public void ActionCallback() {
            // get the listbox control
            System g = Singleton.GetEngine().GetUserSystem();
            Listbox lst = ((Listbox)g.ControlRetrieve("lstWorld"));
            // get the selected index and connect into the server
            int sel = lst.GetSelectedIndex();
            // Create the connection to the gameserver
            TransportFactory.configureMode( TransportFactory.UDP );
            try {
                // connect to the selected server
                Application.pkServerChannel = new MessageChannel( new NetworkMessageFactory(), pkServer[sel][0], Short.parseShort(pkServer[sel][1]));
                // Send the SessionID of the Master Server Protocol
                Application.pkServerChannel.write( new vpLoginMessage(pkInformation[0]) , false);
            } catch (IOException ex) {
                // Game Server Offline.
                ((MessageBox)g.ControlRetrieve("msgBoxCustom")).Show( 320, 320, GAME_LANGUAGE_ERROR, GAME_LANGUAGE_SERVER_OFFLINE );
                return;
            }
        }
    };

}
