//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.Client.Engine.Manager;

import abGroup.sgGaming.Minix2D.Foundation.Singleton;
import abGroup.sgGaming.Minix2D.Gui.Object.ArrayControl;
import abGroup.sgGaming.Minix2D.Networking.Message.Message;
import abGroup.sgGaming.Minix2D.Util.Debug.Debug;

/**
 * This class manage all the game states.
 *
 * @author Agustin L. Alvarez
 */
public class ManagerState {

    /** The current state executing **/
    protected static VirtualState pkCurrentState;


    /**
     * Set the current virtual state for execution.
     *
     * @param vs The virtualstate interface.
     */
    public static void setState( VirtualState vs ) {
        pkCurrentState = vs;
        setUserControlVisible( vs.getStateName(), true );
    }

    /**
     * @return if we are running custom virtual states.
     */
    public static boolean isVsRunning() {
        return (pkCurrentState != null);
    }

    /**
     * This class execute the manager state.
     */
    public static void executeManager( float deltaTime, Message c ) {
        // if null, that means that we are executing the game state renderer.
        if( pkCurrentState != null ) {
            // check for finished state
            if( pkCurrentState.isFinished() == false ) {
                pkCurrentState.Execute( deltaTime ); // Continue executing the state.
                // Network State
                if( c != null ) {
                    pkCurrentState.parseMessage(c);
                }
            } else if( pkCurrentState.hasNextState() == true ) {
                // destroy the interface of the last state
                setUserControlVisible( pkCurrentState.getStateName(), false );
                // set the new state
                setState( pkCurrentState.getNextState() );
            }
        }
    }

    /**
     * Set the user interface visiblitiy.
     *
     * @param arrayName The controls name
     * @param visible TRUE if we need to show it.
     */
    private static void setUserControlVisible(String arrayName, boolean visible) {
        ArrayControl c = (ArrayControl) Singleton.GetEngine().GetUserSystem().ControlRetrieve(arrayName);
        if (c != null) {
            c.SetEnable(visible);
        } else {
            Debug.Print("[Nylox]: The engine couldn't find the controls for %s", arrayName);
        }
    }


}
