/*
 * @(#)ClassLoader.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.util.filesystem;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.JarURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class ClassLoader {

    /** List of the file system streams **/
    private ArrayList<FileSystemStream> fsList;
    private static String fsAppletPath;

    public ClassLoader(String appletPath) {
        fsAppletPath = appletPath;
        fsList = new ArrayList<FileSystemStream>();
        findLocalFileSystem();
    }

    private void findLocalFileSystem() {
        //try {
            // first we add our local class execution
            fsList.add(fileFactory(getLocalPath()));
            // add our jar application to the list.
            // If there is more thatn one path, then this is debug mode, else it's execution time
            StringTokenizer token = new StringTokenizer(getClassPath(), ";");
            if (token.countTokens() > 1) {
                // Add each class debug path.
                for (int i = 1; i <= token.countTokens(); i++) {
                    String debugPathLibrary = token.nextToken() + File.separator;
                    // add the file system.
                    fsList.add(fileFactory(debugPathLibrary));
                }
            } else {
                /*
                // add each jar application library contained in the MANIFEST.
                URL jarUrl = new URL("jar:file:" + getClassPath() + "!/");
                // Open the Connection
                JarURLConnection jarNative = (JarURLConnection) jarUrl.openConnection();
                String lineLibrary = jarNative.getManifest().getMainAttributes().getValue("Class-Path");
                if (lineLibrary != null) {
                    // Parse each Library and Add
                    token = new StringTokenizer(lineLibrary, " ");
                    for (int i = 0; i < token.countTokens(); i++) {
                        // Add the Library
                        fsList.add(fileFactory(token.nextToken() + File.separator));
                    }
                } */
            }

        //} catch (IOException ex) {
        //    ex.printStackTrace();
        //    throw new RuntimeException("Exception while looking external library in the jar file");
        //}
    }

    public static String getLocalPath() {
        return fsAppletPath == null ? System.getProperty("user.dir") : fsAppletPath;
    }

    public static String getClassPath() {
        return System.getProperty("java.class.path");
    }

    public void add(String path) {
        fsList.add(fileFactory(path));
    }

    public void remove(String path) {
        Iterator<FileSystemStream> it = fsList.iterator();
        while (it.hasNext()) {
            FileSystemStream fsStream = it.next();
            if (fsStream.getLocalPath().equalsIgnoreCase(path)) {
                fsList.remove(fsStream);
                return;
            }
        }
    }

    public byte[] getResource(String file) {
        Iterator<FileSystemStream> it = fsList.iterator();
        while (it.hasNext()) {
            FileSystemStream fsStream = it.next();
            if (fsStream.check(file)) {
                try {
                    return fsStream.load(file);
                } catch (IOException ex) {
                    throw new RuntimeException("The ClassLoader couldn't find the resource " + file);
                }
            }
        }
        throw new RuntimeException("The ClassLoader couldn't find the resource " + file);
    }

    public DataInputStream getResourceAsStream(String file) {
        Iterator<FileSystemStream> it = fsList.iterator();
        while (it.hasNext()) {
            FileSystemStream fsStream = it.next();
            if (fsStream.check(file)) {
                try {
                    return fsStream.open(file);
                } catch (IOException ex) {
                    throw new RuntimeException("The ClassLoader couldn't find the resource " + file);
                }
            }
        }
        return null;
    }

    public DataOutputStream getResourceAsOutput(String path, String file) {
        Iterator<FileSystemStream> it = fsList.iterator();
        while (it.hasNext()) {
            FileSystemStream fsStream = it.next();
            if (fsStream.getLocalPath().equalsIgnoreCase(path)) {
                try {
                    return fsStream.retrieve(file);
                } catch (IOException ex) {
                    throw new RuntimeException("The ClassLoader couldn't find the resource path " + path);
                }
            }
        }
        throw new RuntimeException("The ClassLoader couldn't find the resource path " + path);
    }

    public void deleteResource(String file) {
        Iterator<FileSystemStream> it = fsList.iterator();
        while (it.hasNext()) {
            FileSystemStream fsStream = it.next();
            if (fsStream.check(file)) {
                fsStream.delete(file);
            }
        }
        throw new RuntimeException("The ClassLoader couldn't find the resource " + file);
    }

    public FileSystemStream fileFactory(String path) {
        if (path.toUpperCase().endsWith(".JAR") || path.toUpperCase().endsWith(".ZIP")) {
            return new FileSystemStreamZip(path);
        } else {
            return new FileSystemStreamFile(path);
        }
    }
}
