/*
 * @(#)FastMath.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.math;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class FastMath {

    /**
     * Get the closest greater power of 2 to the fold number
     *
     * @param fold The target number
     * @return The power of 2
     */
    public static int getClosedPowerTwo(int fold) {
        int ret = 2;
        while (ret < fold) {
            ret *= 2;
        }
        return ret;
    }

    /**
     * Clamp a value
     *
     * @param a The original value
     * @param low The lower bound
     * @param high The upper bound
     * @return The clamped value
     */
    public static float clamp(float a, float low, float high) {
        return Math.max(low, Math.min(a, high));
    }

    /**
     * Check the sign of a value
     *
     * @param x The value to check
     * @return -1.0f if negative, 1.0 if positive
     */
    public static float sign(float x) {
        return x < 0.0f ? -1.0f : 1.0f;
    }
}
