/*
 * @(#)Collide.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical;

import abGroup.sgGaming.Engine.Minix2D.physical.collide.Collider;
import abGroup.sgGaming.Engine.Minix2D.physical.collide.ColliderFactory;
import abGroup.sgGaming.Engine.Minix2D.physical.collide.ColliderUnavailableException;


/**
 * A static utility for resolve the collision between shapes
 * 
 * TODO: make this nonstatic to allow a user to provide his/her own factory
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public strictfp class Collide {

    /** The factory that provides us with colliders */
    private static ColliderFactory collFactory = new ColliderFactory();

    /**
     * Perform the collision between two bodies
     *
     * @param contacts The points of contact that should be populated
     * @param bodyA The first body
     * @param bodyB The second body
     * @param dt The amount of time that's passed since we last checked collision
     * @return The number of points at which the two bodies contact
     */
    public static int collide(Contact[] contacts, Body bodyA, Body bodyB, float dt) {
        Collider collider;
        try {
            collider = collFactory.createCollider(bodyA, bodyB);
        } catch (ColliderUnavailableException e) {
            System.out.println(e.getMessage() + "\n Ignoring any possible collision between the bodies in question");
            return 0;
        }

        return collider.collide(contacts, bodyA, bodyB);
    }
}
