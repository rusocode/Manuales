/*
 * @(#)Timer.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.util;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class Timer {

    /** Timer Resolution of Nano Seconds */
    public static final long TIMER_RESOLUTION = 1000000000L;
    public static final long TIME_MILLISECOND = 1000;
    /** Last time called. **/
    private long lastTime = Timer.getTime();

    /**
     * Returns the current value of the most precise available system
     * timer, in nanoseconds.
     *
     * <p>This method can only be used to measure elapsed time and is
     * not related to any other notion of system or wall-clock time.
     * The value returned represents nanoseconds since some fixed but
     * arbitrary time (perhaps in the future, so values may be
     * negative).  This method provides nanosecond precision, but not
     * necessarily nanosecond accuracy. No guarantees are made about
     * how frequently values change. Differences in successive calls
     * that span greater than approximately 292 years (2<sup>63</sup>
     * nanoseconds) will not accurately compute elapsed time due to
     * numerical overflow.
     *
     * <p> For example, to measure how long some code takes to execute:
     * <pre>
     *   long startTime = Timer.getTime();
     *   // ... the code being measured ...
     *   long estimatedTime = Timer.getTime() - startTime;
     * </pre>
     *
     * @return The current value of the system timer, in nanoseconds.
     * @since JDK 1.6 1.5
     */
    public static long getTime() {
        return System.nanoTime();
    }

    /**
     * Returns the current value of the system
     * timer, in milliseconds.
     *
     * <p>This method can only be used to measure elapsed time and is
     * not related to any other notion of system or wall-clock time.
     * The value returned represents milliseconds since some fixed but
     * arbitrary time (perhaps in the future, so values may be
     * negative).  This method provides milliseconds precision, but not
     * necessarily milliseconds accuracy. No guarantees are made about
     * how frequently values change. Differences in successive calls
     * that span greater than approximately 292 years (2<sup>63</sup>
     * nanoseconds) will not accurately compute elapsed time due to
     * numerical overflow.
     *
     * <p> For example, to measure how long some code takes to execute:
     * <pre>
     *   long startTime = Timer.getMillisecondTime();
     *   // ... the code being measured ...
     *   long estimatedTime = Timer.getMillisecondTime() - startTime;
     * </pre>
     *
     * @return The current value of the system timer, in milliseconds.
     * @since JDK 1.6 1.5
     */
    public static long getMillisecondTime() {
        return (getTime() * TIME_MILLISECOND) / TIMER_RESOLUTION;
    }

    /**
     * Return the how long some code takes to execute, in nanoseconds.
     * <pre>
     *   long codeExecution = Timer.getElapsedTime();
     * </pre>
     *
     * @return Return the how long some code takes to execute in nanoseconds.
     * @since JDK 1.6 1.5
     */
    public long getElapsedTime() {
        // Get the diferent beetween now and the last time
        long returnValue = getTime() - lastTime;
        // Update last time
        lastTime = getTime();
        // Return the value
        return returnValue;
    }


}
