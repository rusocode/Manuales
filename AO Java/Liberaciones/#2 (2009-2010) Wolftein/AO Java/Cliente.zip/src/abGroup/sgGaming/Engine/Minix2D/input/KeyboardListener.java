/*
 * @(#)KeyboardListener.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.input;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public interface KeyboardListener {

    /**
     * Event that raise when the
     * key is down
     * @param KeyNumber
     */
    public boolean keyDown(Keyboard.enumKeyboardKey key);

    /**
     * Event that raise when the key
     * is release, after doing down
     * @param KeyNumber
     * @return
     */
    public boolean keyRelease(Keyboard.enumKeyboardKey key);

    /**
     * Event that raise then the key
     * is pressed
     * @param KeyNumber
     */
    public boolean keyPress(Keyboard.enumKeyboardKey key);

}