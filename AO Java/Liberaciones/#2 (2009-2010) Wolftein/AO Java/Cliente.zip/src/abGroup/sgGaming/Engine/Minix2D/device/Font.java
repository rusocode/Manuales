/*
 * @(#)Font.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.device;

import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D.AlphaBlending;
import abGroup.sgGaming.Engine.Minix2D.script.Evaluator;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLException;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class Font {
    /**
     * Correction Constants.
     */
    private final static int CORRECTION_RIGHT = 8;
    private final static int CORRECTION_LEFT = 7;

    /**
     * Font Alignation.
     */
    public static enum Aligment {

        Left,
        Right,
        Center
    };

    /**
     * Character Object
     */
    private class CharacterDimension {

        /**
         * Character's width
         */
        public int iWidth;
        /**
         * Character's height
         */
        public int iHeight;
        /**
         * Character's stored x position
         */
        public int iX;
        /**
         * Character's stored y position
         */
        public int iY;
    }
    /**
     * Array that holds necessary information about the font characters
     */
    private CharacterDimension[] pkCharacter = new CharacterDimension[256];
    /**
     * Map of user defined font characters (Character <-> CharacterDimension)
     */
    private Map pkCustomCharacter = new HashMap();
    /**
     * Boolean flag on whether AntiAliasing is enabled or not
     */
    private boolean bAntialiasing;
    /**
     * Java's AWT Font Size.
     */
    private int iFontSize = 0;
    /**
     * A reference to Java's AWT Font that we create our font texture from
     */
    private java.awt.Font pkFont;
    /**
     * The font metrics for our Java AWT font
     */
    private FontMetrics pkFontMetrics;
    /**
     * Font Line Height
     */
    private int iFontLineHeight;
    /**
     * Font Texture.
     */
    private Image pkTexture;
    private abGroup.sgGaming.Engine.Minix2D.device.Graphics2D g2D;
    /**
     * Font Global List.
     */
    private static Map<String, Font> pkFontList = new HashMap<String, Font>();

        /**
     * Constructor
     *
     * @param font
     * @param antiAlias
     * @param additionalChars
     */
    public Font(abGroup.sgGaming.Engine.Minix2D.device.Graphics2D g2D, java.awt.Font font, boolean antiAlias, char[] additionalChars) {
        this.g2D = g2D;
        this.pkFont = font;
        this.iFontSize = font.getSize() + 3;
        this.bAntialiasing = antiAlias;
        createCharacterSet(additionalChars);
    }

    /**
     * Constructor
     *
     * @param font
     * @param antiAlias
     */
    public Font(abGroup.sgGaming.Engine.Minix2D.device.Graphics2D g2D,java.awt.Font font, boolean antiAlias) {
        this(g2D, font, antiAlias, null);
    }

    /**
     * Constructor
     *
     * @param parse
     * @throws XMLException
     */
    public Font(XMLElement parse) throws XMLException {
        for (int i = 0; i < parse.getAttributeNames().length; i++) {
            if (parse.getAttributeNames()[i].compareTo("Filename") == 0) {
                if (createFromFile(parse.getAttribute("Filename")) == false) {
                    return;
                }
            }
        }
        this.pkFont = new java.awt.Font(parse.getAttribute("Name"), parse.getIntAttribute("Style"), parse.getIntAttribute("Size"));
        this.iFontSize = pkFont.getSize() + 3;
        this.bAntialiasing = parse.getBooleanAttribute("Quality");
        createCharacterSet(null);
        Register(parse.getName(), this);
        this.g2D = Runtime.getKernel().getGraphics();
    }

    /**
     * Create a texture with Java2D with the Character of the given font.
     *
     * @param ch
     * @return
     */
    private BufferedImage getCharacterTexture(char ch) {
        // Create a temporary image to extract the character's size
        BufferedImage tempfontImage = new BufferedImage(1, 1,
                BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = (Graphics2D) tempfontImage.getGraphics();
        if (bAntialiasing == true) {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
        }
        g.setFont(pkFont);
        pkFontMetrics = g.getFontMetrics();
        int charwidth = pkFontMetrics.charWidth(ch) + 8;

        if (charwidth <= 0) {
            charwidth = 7;
        }
        int charheight = pkFontMetrics.getHeight() + 3;
        if (charheight <= 0) {
            charheight = iFontSize;
        }

        // Create another image holding the character we are creating
        BufferedImage fontImage;
        fontImage = new BufferedImage(charwidth, charheight,
                BufferedImage.TYPE_INT_ARGB);
        Graphics2D gt = (Graphics2D) fontImage.getGraphics();
        if (bAntialiasing == true) {
            gt.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            gt.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,
                    RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        }
        gt.setFont(pkFont);
        gt.setColor(Color.WHITE);
        int charx = 3;
        int chary = 1;
        gt.drawString(String.valueOf(ch), (charx), (chary) + pkFontMetrics.getAscent());
        return fontImage;
    }

    /**
     * Create the character set of the given awtFont.
     *
     * @param customCharsArray
     */
    private void createCharacterSet(char[] customCharsArray) {
        int widthTexture = 1024, heightTexture = 1024;
        pkTexture = Runtime.getImageLoader().createImageData(widthTexture, heightTexture);
        // If there are custom chars then I expand the font texture twice
        if (customCharsArray != null && customCharsArray.length > 0) {
            pkTexture.setTextureVector(new Vector2f(pkTexture.getTextureWidth() * 2, pkTexture.getTextureHeight()));
        }
        // In any case this should be done in other way. Texture with size 512x512
        // can maintain only 256 characters with resolution of 32x32. The texture
        // size should be calculated dynamicaly by looking at character sizes.
        try {
            BufferedImage imgTemp = new BufferedImage(pkTexture.getTextureWidth(), pkTexture.getTextureHeight(), BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = (Graphics2D) imgTemp.getGraphics();
            // Fill the image with the background of the color black
            g.setColor(new Color(0, 0, 0, 1));
            g.fillRect(0, 0, pkTexture.getTextureWidth(), pkTexture.getTextureHeight());

            int rowHeight = 0;
            int positionX = 0;
            int positionY = 0;
            // Get the size of the custom characters
            int customCharsLength = (customCharsArray != null) ? customCharsArray.length : 0;
            // For each Character..
            for (int i = 0; i < 256 + customCharsLength; i++) {
                // get 0-255 characters and then custom characters
                char ch = (i < 256) ? (char) i : customCharsArray[i - 256];
                // Get the Character texture
                BufferedImage fontImage = getCharacterTexture(ch);
                // Allocate memory for the new character.
                CharacterDimension newCharacter = new CharacterDimension();
                // Set each Character Property
                newCharacter.iWidth = fontImage.getWidth();
                newCharacter.iHeight = fontImage.getHeight();
                // Check for next line.
                if (positionX + newCharacter.iWidth >= pkTexture.getTextureWidth()) {
                    positionX = 0;
                    positionY += rowHeight;
                    rowHeight = 0;
                }
                // Set the position that the character is at in the texture.
                newCharacter.iX = positionX;
                newCharacter.iY = positionY;
                // Check for Biggest Character of the font
                if (newCharacter.iHeight > iFontLineHeight) {
                    iFontLineHeight = newCharacter.iHeight;
                }
                // Check for the row height.
                if (newCharacter.iHeight > rowHeight) {
                    rowHeight = newCharacter.iHeight;
                }
                // Draw it here the character into the texture.
                g.drawImage(fontImage, positionX, positionY, null);
                // Next Column.
                positionX += newCharacter.iWidth;
                // Save the Character Property.
                if (i < 256) { // standard characters
                    pkCharacter[i] = newCharacter;
                } else { // custom characters
                    pkCustomCharacter.put(new Character(ch), newCharacter);
                }
                // Release the Java Image of the character.
                fontImage = null;
            }
            // Buffered the Texture
            Runtime.getImageLoader().convertBufferedImage(imgTemp, pkTexture);
        } catch (Exception e) {
            throw new RuntimeException("Font#CreateCharacterSet Exception");
        }
    }

    /**
     * Draw a string to the screen with aligment left.
     *
     * @param x
     * @param y
     * @param whatchars
     * @param scaleX
     * @param scaleY
     */
    public void write(float x, float y,
            String whatchars, float scaleX, float scaleY) {
        // Automate Script Language.
        String languageScript = (String) Evaluator.eval(whatchars);
        // Render the font.
        write(x, y, languageScript, 0, languageScript.length() - 1, scaleX, scaleY, Aligment.Left);
    }

    /**
     * Draw a string to the screen.
     *
     * @param x
     * @param y
     * @param whatchars
     * @param scaleX
     * @param scaleY
     * @param format
     */
    public void write(float x, float y,
            String whatchars, float scaleX, float scaleY, Aligment format) {
        // Automate Script Language.
        String languageScript = (String) Evaluator.eval(whatchars);
        // Render the font.
        write(x, y, languageScript, 0, languageScript.length() - 1, scaleX, scaleY, format);
    }

    /**
     * Draw a string to the screen.
     *
     * @param x
     * @param y
     * @param whatchars
     * @param startIndex
     * @param endIndex
     * @param scaleX
     * @param scaleY
     * @param format
     */
    public void write(float x, float y, String whatchars, int startIndex, int endIndex, float scaleX, float scaleY, Aligment format) {
        CharacterDimension charDimension = null;
        int charCurrent;
        int totalwidth = 0;
        int i = startIndex, d = 0, c = 0;
        float startY = 0;
        // Select what type of alignation is the text
        // that we are going to render.
        switch (format) {
            // Right Alignation
            case Right: {
                d = -1;
                c = CORRECTION_RIGHT;

                while (i < endIndex) {
                    if (whatchars.charAt(i) == '\n') {
                        startY -= iFontLineHeight;
                    }
                    i++;
                }
                break;
            }
            // Center Alignation
            case Center: {
                for (int l = startIndex; l <= endIndex; l++) {
                    charCurrent = whatchars.charAt(l);
                    if (charCurrent == '\n') {
                        break;
                    }
                    if (charCurrent < 256) {
                        charDimension = pkCharacter[charCurrent];
                    } else {
                        charDimension = (CharacterDimension) pkCustomCharacter.get(new Character((char) charCurrent));
                    }
                    totalwidth += charDimension.iWidth - CORRECTION_LEFT;
                }
                totalwidth /= -2;
            }
            // Left Alignation
            case Left: {
                d = 1;
                c = CORRECTION_LEFT;
                break;
            }
        }
        // A Font Renderer set the alpha blending state for the texture
        // not overlapping with the font background.
        AlphaBlending alpha = g2D.getAlphaBlending();
        g2D.setAlphaBlending(AlphaBlending.SOURCE_ALPHA);
        // For each Character, Render.
        while (i >= startIndex && i <= endIndex) {
            try {
                charCurrent = whatchars.charAt(i);
            } catch (StringIndexOutOfBoundsException ex) // This happend because of the multithreading...
            {
                charCurrent = 0x50;
            }
            if (charCurrent < 256) {
                charDimension = pkCharacter[charCurrent];
            } else {
                charDimension = (CharacterDimension) pkCustomCharacter.get(new Character((char) charCurrent));
            }
            // Only Render if is valid the character we are going to render.
            if (charDimension != null) {
                if (d < 0) {
                    totalwidth += (charDimension.iWidth - c) * d;
                }

                if (charCurrent == '\n') {
                    startY += iFontLineHeight * d;
                    totalwidth = 0;
                    if (format == Aligment.Center) {
                        for (int l = i + 1; l <= endIndex; l++) {
                            charCurrent = whatchars.charAt(l);
                            if (charCurrent == '\n') {
                                break;
                            }
                            if (charCurrent < 256) {
                                charDimension = pkCharacter[charCurrent];
                            } else {
                                charDimension = (CharacterDimension) pkCustomCharacter.get(new Character((char) charCurrent));
                            }
                            totalwidth += charDimension.iWidth - CORRECTION_LEFT;
                        }
                        totalwidth /= -2;
                    }
                    //if center get next lines total width/2;
                    } else {
                    g2D.drawFont(pkTexture,
                            (int)((totalwidth + charDimension.iWidth) * scaleX + x),
                            (int)(startY * scaleY + y),
                            (totalwidth * scaleX + x),
                            ((startY + charDimension.iHeight) * scaleY + y),
                            charDimension.iX + charDimension.iWidth,
                            charDimension.iY + charDimension.iHeight,
                            charDimension.iX,
                            charDimension.iY);


                    if (d > 0) {
                        totalwidth += (charDimension.iWidth - c) * d;
                    }
                }
                i += d;
            }
        }
        //g2D.setAlphaBlending(alpha);
    }

    /**
     * @return The height of the font. The height of the font is the biggest character that
     * use the Y dimension.
     */
    public int getHeight() {
        return iFontLineHeight;
    }

    /**
     * Return the width that the string took in the screen pixels with this font.
     *
     * @param string
     * @return
     */
    public int getWidth(String string, Aligment aligment) {
        int currentCharacter = 0;
        CharacterDimension character = null;
        int totalWidth = 0;

        // Precalculate the Aligment Coordinate
        int aligmentCalculation = 0;
        if (aligment == Aligment.Left) {
            aligmentCalculation = CORRECTION_LEFT;
        } else if (aligment == Aligment.Right) {
            aligmentCalculation = CORRECTION_RIGHT;
        }

        // For Each Character in the string, calculate
        for (int i = 0; i < string.length(); i++) {
            currentCharacter = string.charAt(i);
            if (currentCharacter < 256) {
                character = pkCharacter[currentCharacter];
            } else {
                character = (CharacterDimension) pkCustomCharacter.get(new Character((char) currentCharacter));
            }
            if (character != null) {
                totalWidth += character.iWidth - aligmentCalculation;
            }
        }
        // Return the Total Width
        return totalWidth;
    }

    /**
     * Return the amount of character that enter in the width space.
     *
     * @param string
     * @param aligment
     * @param iWidth
     * @return
     */
    public int getSpaceWidth(String string, Aligment aligment, int iWidth) {
        String checkString = string;
        while (getWidth(checkString, aligment) > iWidth && checkString.length() > 0) {
            checkString = checkString.substring(0, checkString.length() - 1);
        }
        return checkString.length();
    }

    /**
     * Return the offset index at the character given.
     *
     * @param string
     * @param aligment
     * @param iX
     * @return
     */
    public int getIndexFromPosition(String string, Aligment aligment, int iX) {
        int currentCharacter = 0;
        CharacterDimension character = null;
        int index = 0;
        int currentX = 0;

        // Precalculate the Aligment Coordinate
        int aligmentCalculation = 0;
        if (aligment == Aligment.Left) {
            aligmentCalculation = CORRECTION_LEFT;
        } else if (aligment == Aligment.Right) {
            aligmentCalculation = CORRECTION_RIGHT;
        }

        // For Each Character in the string, calculate
        for (int i = 0; i < string.length(); i++) {
            currentCharacter = string.charAt(i);
            if (currentCharacter < 256) {
                character = pkCharacter[currentCharacter];
            } else {
                character = (CharacterDimension) pkCustomCharacter.get(new Character((char) currentCharacter));
            }
            if (character != null) {
                if (currentX >= iX) {
                    return index;
                }
                currentX += character.iWidth - aligmentCalculation;
                index++;
            }
        }
        // Return the Total Width
        return index;
    }

    public Image getFontImage() {
        return pkTexture;
    }

    /**
     * @return the Fonts Supported.
     */
    public static String[] getFontSupported() {
        java.awt.Font[] font = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
        String[] returnValue = new String[font.length];
        for (int i = 0; i < font.length; i++) {
            returnValue[i] = font[i].getName();
        }
        return returnValue;
    }

    /**
     * Check if a font is supported by the system.
     *
     * @param fontName
     * @return
     */
    public static boolean isSupported(String fontName) {
        java.awt.Font[] font = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
        for (int i = font.length - 1; i >= 0; i--) {
            if (font[i].getName().equalsIgnoreCase(fontName)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Register a font to the global list.
     *
     * @param fontName
     * @param font
     */
    public static void Register(String fontName, Font font) {
        pkFontList.put(fontName, font);
    }

    /**
     * Unregister a font from the global list.
     *
     * @param fontName
     */
    public static void Unregister(String fontName) {
        pkFontList.remove(fontName);
    }

    /**
     * Return an global registered font.
     *
     * @param fontName
     * @return
     */
    public static Font Retrieve(String fontName) {
        return pkFontList.get(fontName);
    }

    /**
     * Parse from a xml.
     *
     * @param element
     */
    public static void Parse(XMLElement element) throws XMLException {
        for (int i = 0; i < element.getChildren().size(); i++) {
            // Parse each font.
            new Font(element.getChildren().get(i));
        }
    }

    /**
     * Create the font from a tty file.
     *
     * @param in
     * @return
     */
    public static boolean createFromFile(String Filename) {
        try {
            java.awt.Font.createFont(java.awt.Font.TRUETYPE_FONT, Runtime.getClassLoader().getResourceAsStream(Filename));
        } catch (Exception ex) {
            return false;
        }
        return true;
    }
}