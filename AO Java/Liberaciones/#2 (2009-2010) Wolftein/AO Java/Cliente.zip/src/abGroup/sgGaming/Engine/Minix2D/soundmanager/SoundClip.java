/*
 * @(#)SoundClip.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.soundmanager;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class SoundClip {

    protected String soundFilename;
    protected SoundManager soundManagerLoader;
    protected int soundSource;

    public SoundClip(SoundManager loader, String filename) {
        soundFilename = filename;
        soundManagerLoader = loader;
        createSoundClip();
    }

    public void play() {
        soundManagerLoader.play(soundSource);
    }

    public void pause() {
        soundManagerLoader.pause(soundSource, true);
    }

    public void stop() {
        soundManagerLoader.stop(soundSource);
    }

    public void setGain(float gain) {
        soundManagerLoader.setGain(soundSource, gain);
    }

    private void createSoundClip() {
        // Allocate Memory for the sound
        int soundDataBufferHandle = soundManagerLoader.allocateSoundData();
        // Get the sound input
        SoundInput in = soundManagerLoader.soundInputFactory(soundFilename);
        // generate the buffer
        soundManagerLoader.generateBuffer(soundDataBufferHandle, in);
        // Make the sound source
        soundSource = soundManagerLoader.makeSoundSource(soundDataBufferHandle);
        // dispose the sound data
        in.dispose();
    }
}
