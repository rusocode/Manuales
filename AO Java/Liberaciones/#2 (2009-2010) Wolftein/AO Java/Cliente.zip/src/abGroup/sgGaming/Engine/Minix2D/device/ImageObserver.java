/*
 * @(#)ImageObserver.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.device;

import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import abGroup.sgGaming.Engine.Minix2D.math.FastMath;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug.TypeDebug;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug.TypeDebugChannel;
import java.awt.Graphics;
import java.awt.color.ColorSpace;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.ComponentColorModel;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferByte;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Hashtable;
import javax.imageio.ImageIO;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class ImageObserver implements Runnable {
    
    /** The colour model including alpha for the device image */
    private static ColorModel glAlphaColorModel = new ComponentColorModel(ColorSpace.getInstance(ColorSpace.CS_sRGB),
            new int[]{8, 8, 8, 8},
            true,
            false,
            ComponentColorModel.TRANSLUCENT,
            DataBuffer.TYPE_BYTE);
    /** The colour model for the device image */
    private static ColorModel glColorModel = new ComponentColorModel(ColorSpace.getInstance(ColorSpace.CS_sRGB),
            new int[]{8, 8, 8, 0},
            false,
            false,
            ComponentColorModel.OPAQUE,
            DataBuffer.TYPE_BYTE); 
    
    /** observer texture variables **/
    private String texName;
    private int imageWidth, imageHeight;
    private int texWidth, texHeight;
    private BufferedImage texImage;
    private boolean texLoaded = false;
    private boolean texEnded = false;
    private ByteBuffer texBuffer;
    private boolean texHasAlpha;

    /**
     * Constructor
     * 
     * @param image
     */
    public ImageObserver(String image) {
        texName = image;
    }

    /**
     * @see java.lang.Runnable#run() 
     */
    public void run() {
        try {
            // read the image
            BufferedImage bufferedImage = ImageIO.read(Runtime.getClassLoader().getResourceAsStream(texName));
            // check for alpha image
            texHasAlpha = bufferedImage.getColorModel().hasAlpha();
            // convert the image into texture data.
            texBuffer = convertImageData(bufferedImage);
            // texture loaded
            texLoaded = true;
        } catch (Exception ex) {
            Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                    TypeDebug.WARNING,
                    String.format("Couldn't find the image %s", texName));
        }
        texEnded = true;
    }

    /**
     * Convert the buffered image to a texture
     *
     * @param bufferedImage The image to convert to a texture
     * @param texture The texture to store the data into
     * @return A buffer containing the data
     */
    private ByteBuffer convertImageData(BufferedImage bufferedImage) {
        ByteBuffer imageBuffer = null;
        WritableRaster raster;
        // find the texture size.
        imageWidth = bufferedImage.getWidth();
        imageHeight = bufferedImage.getHeight();
        texWidth = FastMath.getClosedPowerTwo(bufferedImage.getWidth());
        texHeight = FastMath.getClosedPowerTwo(bufferedImage.getHeight());

        // create a raster that can be used by OpenGL as a source
        // for a texture
        if (bufferedImage.getColorModel().hasAlpha()) {
            raster = Raster.createInterleavedRaster(DataBuffer.TYPE_BYTE, texWidth, texHeight, 4, null);
            texImage = new BufferedImage(glAlphaColorModel, raster, false, new Hashtable());
        } else {
            raster = Raster.createInterleavedRaster(DataBuffer.TYPE_BYTE, texWidth, texHeight, 3, null);
            texImage = new BufferedImage(glColorModel, raster, false, new Hashtable());
        }

        // copy the source image into the produced image
        Graphics g = texImage.getGraphics();
        g.setColor(new java.awt.Color(0f, 0f, 0f, 0f));
        g.fillRect(0, 0, texWidth, texHeight);
        g.drawImage(bufferedImage, 0, 0, null);
        // build a byte buffer from the temporary image
        // that be used by OpenGL to produce a texture.
        byte[] data = ((DataBufferByte) texImage.getRaster().getDataBuffer()).getData();
        imageBuffer = ByteBuffer.allocateDirect(data.length);
        imageBuffer.order(ByteOrder.nativeOrder());
        imageBuffer.put(data, 0, data.length);
        imageBuffer.flip();
        return imageBuffer;
    }

    public Vector2f getTextureSize() {
        return new Vector2f(texWidth, texHeight);
    }

    public Vector2f getImageSize() {
        return new Vector2f( imageWidth, imageHeight );
    }

    public BufferedImage getTextureImage() {
        return texImage;
    }

    public boolean isTextureLoaded() {
        return texLoaded;
    }

    public boolean isLoadingFinished() {
        return texEnded;
    }

    public boolean isTextureAlphaChannel() {
        return texHasAlpha;
    }

    public ByteBuffer getTextureData() {
        return texBuffer;
    }

    public String getTextureName() {
        return texName;
    }

}
