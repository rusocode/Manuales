/*
 * @(#)MinixState.java	1.0 Feb 7, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.kernel;

import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.input.Keyboard.enumKeyboardKey;
import abGroup.sgGaming.Engine.Minix2D.input.Mouse.MOUSE_BUTTON_EVENT;
import abGroup.sgGaming.Engine.Minix2D.input.Mouse.MouseButton;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 7, 2010
 * @since
 */
public class MinixState {

    /** state name **/
    protected String name;

    /**
     * Constructor
     *
     * @param stateName
     */
    public MinixState(String stateName) {
        name = stateName;
    }

    /**
     * @return The next state.
     */
    public MinixState getNextState() {
        return null;
    }

    /**
     * @return The previues state.
     */
    public MinixState getPrevState() {
        return null;
    }

    /**
     * @return If the state doesn't contain enxt state
     */
    public boolean hasNextState() {
        return false;
    }

    /**
     * @return If the state doesn't contain prev state
     */
    public boolean hasPrevState() {
        return false;
    }

    /**
     * @return close teh game on this state?
     */
    public boolean isCloseOnRequest() {
        return false;
    }

    /**
     * Render callback of the state.
     *
     * @param g
     */
    public void render(Graphics2D g) {
        return;
    }

    /**
     * Logical callback of the state.
     *
     * @param timeDelta
     */
    public void logical(float timeDelta) {
        return;
    }

    /**
     * Keyboard event.
     *
     * @param key
     */
    public void keyPress(enumKeyboardKey key) {
        return;
    }

    /**
     * Keyboard event.
     *
     * @param key
     */
    public void keyDown(enumKeyboardKey key ) {
        return;
    }

    /**
     * Mouse event.
     *
     * @param x
     * @param y
     */
    public void mouseMove(int x, int y) {
        return;
    }

    /**
     * Mouse button event
     *
     * @param button
     * @param event
     */
    public void mouseButton( MouseButton button, MOUSE_BUTTON_EVENT event ) {
        return;
    }

    /**
     * Mouse Whell event.
     *
     * @param up
     */
    public void mouseWheel( boolean up ) {
        return;
    }

}
