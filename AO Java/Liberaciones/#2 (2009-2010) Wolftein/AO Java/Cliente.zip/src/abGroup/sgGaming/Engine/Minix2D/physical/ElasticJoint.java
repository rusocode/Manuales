/*
 * @(#)ElasticJoint.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical;

import abGroup.sgGaming.Engine.Minix2D.math.Matrix2f;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;

/**
 * A joint between two bodies. The joint affects the impulses applied to 
 * each body each step constraining the movement. Behaves a bit like elastic
 * 
 * Behaviour is undefined - it does something and it's definitely odd. Might
 * be useful for something
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public strictfp class ElasticJoint implements Joint {

    /** The next ID to be used */
    public static int NEXT_ID = 0;
    /** The first body attached to the joint */
    private Body body1;
    /** The second body attached to the joint */
    private Body body2;
    /** The matrix describing the connection between two bodies */
    private Matrix2f M = new Matrix2f();
    /** The local anchor for the first body */
    private Vector2f localAnchor1 = new Vector2f();
    /** The local anchor for the second body */
    private Vector2f localAnchor2 = new Vector2f();
    /** The rotation of the anchor of the first body */
    private Vector2f r1 = new Vector2f();
    /** The rotation of the anchor of the second body */
    private Vector2f r2 = new Vector2f();
    /** ? */
    private Vector2f bias = new Vector2f();
    /** The impulse to be applied throught the joint */
    private Vector2f accumulatedImpulse = new Vector2f();
    /** How much slip there is in the joint */
    private float relaxation;
    /** The ID of this joint */
    private int id;

    /**
     * Create a joint holding two bodies together
     *
     * @param b1 The first body attached to the joint
     * @param b2 The second body attached to the joint
     */
    public ElasticJoint(Body b1, Body b2) {
        id = NEXT_ID++;
        accumulatedImpulse.Set(0.0f, 0.0f);
        relaxation = 1.0f;

        set(b1, b2);
    }

    /**
     * Set the relaxtion value on this joint. This value determines
     * how loose the joint will be
     *
     * @param relaxation The relaxation value
     */
    public void setRelaxation(float relaxation) {
        this.relaxation = relaxation;
    }

    /**
     * Retrieve the anchor for the first body attached
     *
     * @return The anchor for the first body
     */
    public Vector2f getLocalAnchor1() {
        return localAnchor1;
    }

    /**
     * Retrieve the anchor for the second body attached
     *
     * @return The anchor for the second body
     */
    public Vector2f getLocalAnchor2() {
        return localAnchor2;
    }

    /**
     * Get the first body attached to this joint
     *
     * @return The first body attached to this joint
     */
    public Body getBody1() {
        return body1;
    }

    /**
     * Get the second body attached to this joint
     *
     * @return The second body attached to this joint
     */
    public Body getBody2() {
        return body2;
    }

    /**
     * Reconfigure this joint
     *
     * @param b1 The first body attached to this joint
     * @param b2 The second body attached to this joint
     */
    public void set(Body b1, Body b2) {
        body1 = b1;
        body2 = b2;

        Matrix2f rot1 = new Matrix2f(body1.getRotation());
        Matrix2f rot2 = new Matrix2f(body2.getRotation());
        Matrix2f rot1T = rot1.transpose();
        Matrix2f rot2T = rot2.transpose();

        Vector2f a1 = new Vector2f(body2.getPosition());
        a1.Sub(body1.getPosition());
        localAnchor1 = Vector2f.mul(rot1T, a1);
        Vector2f a2 = new Vector2f(body1.getPosition());
        a2.Sub(body2.getPosition());
        localAnchor2 = Vector2f.mul(rot2T, a2);

        accumulatedImpulse.Set(0.0f, 0.0f);
        relaxation = 1.0f;
    }

    /**
     * Precaculate everything and apply initial impulse before the
     * simulation step takes place
     *
     * @param invDT The amount of time the simulation is being stepped by
     */
    public void preStep(float invDT) {
        // Pre-compute anchors, mass matrix, and bias.
        Matrix2f rot1 = new Matrix2f(body1.getRotation());
        Matrix2f rot2 = new Matrix2f(body2.getRotation());

        r1 = Vector2f.mul(rot1, localAnchor1);
        r2 = Vector2f.mul(rot2, localAnchor2);

        // deltaV = deltaV0 + K * impulse
        // invM = [(1/m1 + 1/m2) * eye(2) - skew(r1) * invI1 * skew(r1) - skew(r2) * invI2 * skew(r2)]
        //      = [1/m1+1/m2     0    ] + invI1 * [r1.y*r1.y -r1.x*r1.y] + invI2 * [r1.y*r1.y -r1.x*r1.y]
        //        [    0     1/m1+1/m2]           [-r1.x*r1.y r1.x*r1.x]           [-r1.x*r1.y r1.x*r1.x]
        Matrix2f K1 = new Matrix2f();
        K1.col1.x = body1.getInvMass() + body2.getInvMass();
        K1.col2.x = 0.0f;
        K1.col1.y = 0.0f;
        K1.col2.y = body1.getInvMass() + body2.getInvMass();

        Matrix2f K2 = new Matrix2f();
        K2.col1.x = body1.getInvI() * r1.y * r1.y;
        K2.col2.x = -body1.getInvI() * r1.x * r1.y;
        K2.col1.y = -body1.getInvI() * r1.x * r1.y;
        K2.col2.y = body1.getInvI() * r1.x * r1.x;

        Matrix2f K3 = new Matrix2f();
        K3.col1.x = body2.getInvI() * r2.y * r2.y;
        K3.col2.x = -body2.getInvI() * r2.x * r2.y;
        K3.col1.y = -body2.getInvI() * r2.x * r2.y;
        K3.col2.y = body2.getInvI() * r2.x * r2.x;

        Matrix2f K = Matrix2f.add(Matrix2f.add(K1, K2), K3);
        M = K.Invert();

        Vector2f p1 = new Vector2f(body1.getPosition());
        p1.Add(r1);
        Vector2f p2 = new Vector2f(body2.getPosition());
        p2.Add(r2);
        Vector2f dp = new Vector2f(p2);
        dp.Sub(p1);

        bias = new Vector2f(dp);
        bias.Scale(-0.1f);
        bias.Scale(invDT);

        // Apply accumulated impulse.
        accumulatedImpulse.Scale(relaxation);

        Vector2f accum1 = new Vector2f(accumulatedImpulse);
        accum1.Scale(-body1.getInvMass());
        body1.adjustVelocity(accum1);
        body1.adjustAngularVelocity(-(body1.getInvI() * Vector2f.cross(r1, accumulatedImpulse)));

        Vector2f accum2 = new Vector2f(accumulatedImpulse);
        accum2.Scale(body2.getInvMass());
        body2.adjustVelocity(accum2);
        body2.adjustAngularVelocity(body2.getInvI() * Vector2f.cross(r2, accumulatedImpulse));
    }

    /**
     * Apply the impulse caused by the joint to the bodies attached.
     */
    public void applyImpulse() {
        Vector2f dv = new Vector2f(body2.getVelocity());
        dv.Add(Vector2f.cross(body2.getAngularVelocity(), r2));
        dv.Sub(body1.getVelocity());
        dv.Sub(Vector2f.cross(body1.getAngularVelocity(), r1));
        dv.Scale(-1);
        dv.Add(bias);

        if (dv.LengthSquared() == 0) {
            return;
        }

        Vector2f impulse = Vector2f.mul(M, dv);

        Vector2f delta1 = new Vector2f(impulse);
        delta1.Scale(-body1.getInvMass());
        body1.adjustVelocity(delta1);
        body1.adjustAngularVelocity(-body1.getInvI() * Vector2f.cross(r1, impulse));

        Vector2f delta2 = new Vector2f(impulse);
        delta2.Scale(body2.getInvMass());
        body2.adjustVelocity(delta2);
        body2.adjustAngularVelocity(body2.getInvI() * Vector2f.cross(r2, impulse));

        accumulatedImpulse.Add(impulse);
    }

    /**
     * @see java.lang.Object#hashCode()
     */
    public int hashCode() {
        return id;
    }

    /**
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object other) {
        if (other.getClass() == getClass()) {
            return ((ElasticJoint) other).id == id;
        }

        return false;
    }
}
