/*
 * @(#)FixedAngleJoint.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical;

import abGroup.sgGaming.Engine.Minix2D.math.Matrix2f;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;

/**
 * A joint that will maintain a fixed angle between two bodies
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class FixedAngleJoint implements Joint {

    /** The angle to maintain */
    private float rotateA;
    /** The first body jointed */
    private Body body1;
    /** The second body jointed */
    private Body body2;
    /** Anchor point for first body, on which impulse is going to apply*/
    private Vector2f anchor1;
    /** Anchor point for second body, on which impulse is going to apply*/
    private Vector2f anchor2;
    /** The cached impulse through the calculation to yield correct impulse faster */
    private float accumulateImpulse;
    /** The squared distance of two body*/
    private float dlength2;
    /** Used to calculate the relation ship between impulse and velocity change between body*/
    private float K;
    /** Normalised distance vector*/
    private Vector2f ndp;
    /** Distance Vector*/
    private Vector2f dp;
    /** The normal vector of the impulse direction*/
    private Vector2f n;
    /** R = r1 + d */
    private Vector2f R;

    /**
     * @param body1	The first body to be attached on constraint
     * @param body2 The second body to be attached on constraint
     * @param anchor1 The anchor point on first body
     * @param anchor2 The anchor point on second body
     * @param rotateA The fixed angle on body2 from body1
     */
    public FixedAngleJoint(Body body1, Body body2, Vector2f anchor1,
            Vector2f anchor2, float rotateA) {
        this.body1 = body1;
        this.body2 = body2;
        this.rotateA = rotateA;
        this.anchor1 = anchor1;
        this.anchor2 = anchor2;
    }

    /**
     * @see net.phys2d.raw.Joint#applyImpulse()
     */
    public void applyImpulse() {
        Matrix2f rot1 = new Matrix2f(body1.getRotation());
        Matrix2f rot2 = new Matrix2f(body2.getRotation());
        Vector2f r1 = Vector2f.mul(rot1, anchor1);
        Vector2f r2 = Vector2f.mul(rot2, anchor2);

        Vector2f relativeVelocity = new Vector2f(body2.getVelocity());
        relativeVelocity.Add(Vector2f.cross(r2, body2.getAngularVelocity()));
        relativeVelocity.Sub(body1.getVelocity());
        relativeVelocity.Sub(Vector2f.cross(r1, body1.getAngularVelocity()));

        /*
         * Matrix2f tr1 = new Matrix2f(-body1.getRotation()); relativeVelocity =
         * MathUtil.mul(tr1, relativeVelocity);
         * relativeVelocity.add(MathUtil.mul(tr1, dp));
         */

        float rv = Vector2f.cross(dp, relativeVelocity) / dlength2 - body1.getAngularVelocity();
        rv = 0 - rv;

        float p = rv / K;
        float oldImpulse = accumulateImpulse;
        float newImpulse;

        newImpulse = accumulateImpulse + p;
        p = newImpulse - oldImpulse;

        accumulateImpulse = newImpulse;

        Vector2f impulse = new Vector2f(n);
        impulse.Scale(p);
        if (!body1.isStatic()) {
            Vector2f accum1 = new Vector2f(impulse);
            accum1.Scale(body1.getInvMass());
            body1.adjustVelocity(accum1);
            body1.adjustAngularVelocity((body1.getInvI() * Vector2f.cross(R,
                    impulse)));
        }
        if (!body2.isStatic()) {
            Vector2f accum2 = new Vector2f(impulse);
            accum2.Scale(-body2.getInvMass());
            body2.adjustVelocity(accum2);
            body2.adjustAngularVelocity(-(body2.getInvI() * Vector2f.cross(r2,
                    impulse)));
        }
    }

    /**
     * @see net.phys2d.raw.Joint#getBody1()
     */
    public Body getBody1() {
        return body1;
    }

    /**
     * @see net.phys2d.raw.Joint#getBody2()
     */
    public Body getBody2() {
        return body2;
    }

    /**
     * @see net.phys2d.raw.Joint#preStep(float)
     */
    public void preStep(float invDT) {
        float biasFactor = 0.005f;
        float biasImpulse = 0.0f;
        float RA = body1.getRotation() + rotateA;

        Vector2f VA = new Vector2f((float) Math.cos(RA), (float) Math.sin(RA));

        Matrix2f rot1 = new Matrix2f(body1.getRotation());
        Matrix2f rot2 = new Matrix2f(body2.getRotation());
        Vector2f r1 = Vector2f.mul(rot1, anchor1);
        Vector2f r2 = Vector2f.mul(rot2, anchor2);

        Vector2f p1 = new Vector2f(body1.getPosition());
        p1.Add(r1);
        Vector2f p2 = new Vector2f(body2.getPosition());
        p2.Add(r2);
        dp = new Vector2f(p2);
        dp.Sub(p1);
        dlength2 = dp.LengthSquared();
        ndp = new Vector2f(dp);
        ndp.Normalise();

        R = new Vector2f(r1);
        R.Add(dp);
        // System.out.println(accumulateImpulse);
        Vector2f relativeVelocity = new Vector2f(body2.getVelocity());
        relativeVelocity.Add(Vector2f.cross(r2, body2.getAngularVelocity()));
        relativeVelocity.Sub(body1.getVelocity());
        relativeVelocity.Sub(Vector2f.cross(r1, body1.getAngularVelocity()));

        /*
         * Matrix2f tr1 = new Matrix2f(-body1.getRotation()); relativeVelocity =
         * MathUtil.mul(tr1, relativeVelocity);
         * relativeVelocity.add(MathUtil.mul(tr1, dp));
         */
        // relativeVelocity.add(MathUtil.cross(dp,body1.getAngularVelocity()));
        n = new Vector2f(-ndp.y, ndp.x);
        Vector2f v1 = new Vector2f(n);
        v1.Scale(-body2.getInvMass() - body1.getInvMass());

        Vector2f v2 = Vector2f.cross(Vector2f.cross(r2, n), r2);
        v2.Scale(-body2.getInvI());

        Vector2f v3 = Vector2f.cross(Vector2f.cross(R, n), r1);
        v3.Scale(-body1.getInvI());

        Vector2f K1 = new Vector2f(v1);
        K1.Add(v2);
        K1.Add(v3);

        K = Vector2f.cross(dp, K1) / dlength2 - Vector2f.cross(R, n) * body1.getInvI();



        biasImpulse = biasFactor * Vector2f.cross(ndp, VA) * invDT;

        Vector2f impulse = new Vector2f(n);
        impulse.Scale(accumulateImpulse + biasImpulse);
        if (!body1.isStatic()) {
            Vector2f accum1 = new Vector2f(impulse);
            accum1.Scale(body1.getInvMass());
            body1.adjustVelocity(accum1);
            body1.adjustAngularVelocity((body1.getInvI() * Vector2f.cross(R,
                    impulse)));
        }
        if (!body2.isStatic()) {
            Vector2f accum2 = new Vector2f(impulse);
            accum2.Scale(-body2.getInvMass());
            body2.adjustVelocity(accum2);
            body2.adjustAngularVelocity(-(body2.getInvI() * Vector2f.cross(r2,
                    impulse)));
        }
    }

    /**
     * @see net.phys2d.raw.Joint#setRelaxation(float)
     */
    public void setRelaxation(float relaxation) {
    }

    /**
     * Get the angle maintained between the two bodies
     *
     * @return The angle maintained between the two bodies
     */
    public float getRotateA() {
        return rotateA;
    }

    /**
     * Get the anchor of the joint on the first body
     *
     * @return The anchor of the joint on the first body
     */
    public Vector2f getAnchor1() {
        return anchor1;
    }

    /**
     * Get the anchor of the joint on the second body
     *
     * @return The anchor of the joint on the second body
     */
    public Vector2f getAnchor2() {
        return anchor2;
    }
}
