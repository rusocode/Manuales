/*
 * @(#)implImageBuffer.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl;

import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import abGroup.sgGaming.Engine.Minix2D.device.Image;
import abGroup.sgGaming.Engine.Minix2D.device.ImageBuffer;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug.TypeDebug;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug.TypeDebugChannel;
import java.nio.IntBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.EXTFramebufferObject;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GLContext;
import org.lwjgl.opengl.Pbuffer;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class implImageBuffer implements ImageBuffer {

    /** Diferent types of buffers **/
    private final static int TYPE_NONE = -1;
    private final static int TYPE_PBUFFER = 0;
    private final static int TYPE_FRAMEBUFFER_OBJECT = 1;
    private IntBuffer bufferUtil = BufferUtils.createIntBuffer(1);
    private int bufferType;
    private int renderID, bufferID;
    private Image bufferTexture;
    private int viewportX, viewportY;

    /**
     * Constructor
     *
     * @param width
     * @param height
     * @param viewX
     * @param viewY
     */
    public implImageBuffer(Image image, int viewX, int viewY) {
        bufferType = getBufferSupported();
        bufferTexture = image;
        viewportX = viewX;
        viewportY = viewY;
        if (bufferType == TYPE_NONE) {
            throw new RuntimeException("Buffer capability is not supported in this plataform");
        }
        try {
            createBufferType();
        } catch (Exception ex) {
            Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                    TypeDebug.ERROR,
                    ex.getMessage());
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.ImageBuffer
     */
    public void update() {
        /** FBO Opengl **/
        if (bufferType == TYPE_FRAMEBUFFER_OBJECT) {
            // Flush to the screen
            GL11.glFlush();
            // unbind the frameBuffer
            EXTFramebufferObject.glBindFramebufferEXT(EXTFramebufferObject.GL_FRAMEBUFFER_EXT, 0);
            // restore the atributes
            GL11.glPopAttrib();
            GL11.glMatrixMode(GL11.GL_PROJECTION);
            GL11.glPopMatrix();
            GL11.glMatrixMode(GL11.GL_MODELVIEW);
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.ImageBuffer
     */
    public void start() {
        /** FBO Opengl **/
        if (bufferType == TYPE_FRAMEBUFFER_OBJECT) {
            GL11.glPushAttrib(GL11.GL_VIEWPORT_BIT);
            GL11.glMatrixMode(GL11.GL_PROJECTION);
            GL11.glPushMatrix();
            EXTFramebufferObject.glBindFramebufferEXT(EXTFramebufferObject.GL_FRAMEBUFFER_EXT, bufferID);
            GL11.glViewport(0, 0, viewportX, viewportY);
            GL11.glMatrixMode(GL11.GL_PROJECTION);
            GL11.glLoadIdentity();
            GL11.glOrtho(0, viewportX, 0, viewportY, -100, 100);
            GL11.glMatrixMode(GL11.GL_MODELVIEW);
            GL11.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
            GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
            GL11.glLoadIdentity();
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.ImageBuffer
     */
    public Image getBackingImage() {
        return bufferTexture;
    }


    /**
     * Create the type of buffer.
     */
    private void createBufferType() throws Exception {
        /** FBO Opengl **/
        if (bufferType == TYPE_FRAMEBUFFER_OBJECT) {
            // create the frameObjectID
            EXTFramebufferObject.glGenFramebuffersEXT(bufferUtil);
            bufferID = bufferUtil.get(0);
            // create the render buffer ID
            EXTFramebufferObject.glGenRenderbuffersEXT(bufferUtil);
            renderID = bufferUtil.get(0);
            // Firt bind the frameBuffer
            EXTFramebufferObject.glBindFramebufferEXT(EXTFramebufferObject.GL_FRAMEBUFFER_EXT, bufferID);
            // create The texture Buffer
            EXTFramebufferObject.glFramebufferTexture2DEXT(EXTFramebufferObject.GL_FRAMEBUFFER_EXT,
                    EXTFramebufferObject.GL_COLOR_ATTACHMENT0_EXT,
                    GL11.GL_TEXTURE_2D,
                    bufferTexture.getTextureID(),
                    0);
            // Second bind the render buffer
            EXTFramebufferObject.glBindRenderbufferEXT(EXTFramebufferObject.GL_RENDERBUFFER_EXT, bufferID);
            // initialize depth renderBuffer
            EXTFramebufferObject.glRenderbufferStorageEXT(EXTFramebufferObject.GL_RENDERBUFFER_EXT,
                    GL14.GL_DEPTH_COMPONENT24,
                    bufferTexture.getTextureWidth(),
                    bufferTexture.getTextureHeight());
            // initialize frame renderBuffer
            EXTFramebufferObject.glFramebufferRenderbufferEXT(EXTFramebufferObject.GL_FRAMEBUFFER_EXT,
                    EXTFramebufferObject.GL_DEPTH_ATTACHMENT_EXT,
                    EXTFramebufferObject.GL_RENDERBUFFER_EXT,
                    renderID);
            // check for any error
            //checkErrorFrameBuffer(bufferID);
            // release the frameBuffer
            EXTFramebufferObject.glBindFramebufferEXT(EXTFramebufferObject.GL_FRAMEBUFFER_EXT, 0);
        } /** PBuffer **/
        else if (bufferType == TYPE_PBUFFER) {
        }
    }

    /**
     * Check for errors in the fbo.
     *
     * @param frameBuffer
     */
    private static void checkErrorFrameBuffer(int frameBufferID) {
        // get the frameBufferError
        int frameBuffer = EXTFramebufferObject.glCheckFramebufferStatusEXT(EXTFramebufferObject.GL_FRAMEBUFFER_EXT);
        // print the error
        switch (frameBuffer) {
            case EXTFramebufferObject.GL_FRAMEBUFFER_COMPLETE_EXT:
                break;
            case EXTFramebufferObject.GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT_EXT:
                Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                        TypeDebug.ERROR,
                        String.format("FBO: %d has caused a %s exception", frameBufferID, "GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT_EXT"));

                break;
            case EXTFramebufferObject.GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT_EXT:
                Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                        TypeDebug.ERROR,
                        String.format("FBO: %d has caused a %s exception", frameBufferID, "GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT_EXT"));
                break;
            case EXTFramebufferObject.GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS_EXT:
                Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                        TypeDebug.ERROR,
                        String.format("FBO: %d has caused a %s exception", frameBufferID, "GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS_EXT"));
                break;
            case EXTFramebufferObject.GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER_EXT:
                Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                        TypeDebug.ERROR,
                        String.format("FBO: %d has caused a %s exception", frameBufferID, "GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER_EXT"));
                break;
            case EXTFramebufferObject.GL_FRAMEBUFFER_INCOMPLETE_FORMATS_EXT:
                Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                        TypeDebug.ERROR,
                        String.format("FBO: %d has caused a %s exception", frameBufferID, "GL_FRAMEBUFFER_INCOMPLETE_FORMATS_EXT"));
                break;
            case EXTFramebufferObject.GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER_EXT:
                Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                        TypeDebug.ERROR,
                        String.format("FBO: %d has caused a %s exception", frameBufferID, "GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER_EXT"));
                break;
            default:
                Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                        TypeDebug.ERROR,
                        String.format("FBO: Unexpected reply from glCheckFramebufferStatusEXT: %d", frameBufferID));
        }
    }

    /**
     * @return The type of opengl buffer that support the driver.
     */
    private int getBufferSupported() {
        if (GLContext.getCapabilities().GL_EXT_framebuffer_object) {
            return TYPE_FRAMEBUFFER_OBJECT;

        } else if ((Pbuffer.getCapabilities() & Pbuffer.PBUFFER_SUPPORTED) != 0) {
            return TYPE_PBUFFER;
        }
        // Nothing supported.
        return TYPE_NONE;
    }
}
