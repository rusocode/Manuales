/*
 * @(#)Language.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.util;

import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class Language {
    
    private static final String ID_CURRENT_LANGUANGE = "Setting";
    private static final String ID_UNDEFINED_LANGUAGE = "UndefinedLangID";

    /** This file contain each word of the language. */
    private static Map<String, String> language = new HashMap<String, String>();
    private static Map<String, Map> langList = new HashMap<String, Map>();
    /** Current Language. */
    private static String currentLanguage;

    public static boolean parseOf(XMLElement langXML) {
        XMLElement langNode;

        // For Each Language, Parse.
        for (int i = 0; i < langXML.getChildren().size(); i++) {
            langNode = langXML.getChildren().get(i);
            if (!langNode.getName().equalsIgnoreCase(ID_CURRENT_LANGUANGE)) {
                langList.put(langNode.getName(), parseLanguage(langNode));
            }
        }
        // Set the Setting current.
        setLocale(langXML.getChildrenByName(ID_CURRENT_LANGUANGE).get(0).getContent());

        return true;
    }

    private static Map parseLanguage(XMLElement langXML) {
        Map<String, String> newMap = new HashMap<String, String>();
        XMLElement langNode;

        // For Each Language, Parse.
        for (int i = 0; i < langXML.getChildren().size(); i++) {
            langNode = langXML.getChildren().get(i);
            newMap.put(langNode.getName(), langNode.getContent());
        }
        return newMap;
    }

    public static void setLocale(String languageName) {
        if (langList.containsKey(languageName) == true) {
            currentLanguage = languageName;
            language = langList.get(languageName);
        }
    }

    public static String getCurrentLocale() {
        return currentLanguage;
    }

    public static String[] getAvailableLocale() {
        String[] array = new String[langList.size()];
        Iterator<String> it = langList.keySet().iterator();
        int i = 0;
        while (it.hasNext() == true) {
            array[i] = it.next();
            i++;
        }
        return array;
    }

    public static String getLocaleID(String ID) {
        if (language.containsKey(ID) == false) {
            return ID_UNDEFINED_LANGUAGE;
        } else {
            return language.get(ID);
        }
    }

}
