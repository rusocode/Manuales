/*
 * @(#)Collider.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical.collide;

import abGroup.sgGaming.Engine.Minix2D.physical.Body;
import abGroup.sgGaming.Engine.Minix2D.physical.Contact;

/**
 * The description of any geometry collision resolver. 
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public interface Collider {

    /**
     * Determine is any collisions have occured between the two bodies
     * specified.
     *
     * @param contacts The contacts array to populate with results
     * @param bodyA The first body to check against
     * @param bodyB The second body to check against
     * @return The number of contacts that have been determined and hence
     * populated in the array.
     */
    public int collide(Contact[] contacts, Body bodyA, Body bodyB);
}
