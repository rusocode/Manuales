/*
 * @(#)JPicture.java	1.0 Feb 2, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.m2gui.controls;

import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import abGroup.sgGaming.Engine.Minix2D.device.Color;
import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.device.Image;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Control;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Drawable;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLException;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 2, 2010
 * @since JDK 1.6
 */
public class JPicture extends Control implements Drawable {
        
    /** For Rendering **/
    private String image;
    private int sourceX, sourceY, sourceWidth = 0, sourceHeight = 0;
    private Color color = Color.White;

    /**
     * Constructor
     * 
     * @param x
     * @param y
     */
    public JPicture(int x, int y) {
        super("JPicture");
        setPosition(new Vector2f(x, y));
    }

    /**
     * Constructor
     * 
     * @param element
     * @throws XMLException
     */
    public JPicture(XMLElement element) throws XMLException {
        super("JPicture");
        parse(element);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Control#parse(abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement) 
     */
    @Override
    public void parse(XMLElement element) throws XMLException {
        // Control parse native.
        super.parse(element);
        // JPicture propertys.
        String[] xmlProperty = element.getAttributeNames();
        String currentProperty;
        for( int i = 0; i < xmlProperty.length; i++ ) {
            currentProperty = xmlProperty[i].toUpperCase();
            if( currentProperty.equals("IMAGE") ) {
                setImage( element.getAttribute("Image") );
            } else if( currentProperty.equals("COLOR") ) {
                setColor( Color.parseOf(element.getAttribute("Color")));
            }
        }
    }

    /**
     * Set the JPicture image.
     *
     * @param imageName
     */
    public void setImage(String imageName) {
        image = imageName;
    }

    /**
     * Set the picture source.
     *
     * @param x
     * @param y
     * @param width
     * @param height
     */
    public void setSource(int x, int y, int width, int height) {
        sourceX = x;
        sourceY = y;
        sourceWidth = width;
        sourceHeight = height;
    }

    /**
     * Set the picture color.
     *
     * @param color
     */
    public void setColor( Color color ) {
        this.color = color;
    }

    /**
     * Override the control function to make spatial grow.
     *
     * @param size
     */
    @Override
    public void setSize(Vector2f size) {
        super.setSize(size);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Drawable#Drawable(abGroup.sgGaming.Engine.Minix2D.device.Graphics2D, int, int)
     */
    public void Drawable(Graphics2D g, int x, int y) {
        int destSourceWidth = sourceWidth, destSourceHeight = sourceHeight;

        Image classImage = Runtime.getImageLoader().getImage(image);
        setSize(new Vector2f(classImage.getWidth(), classImage.getHeight()));

        if (sourceWidth == 0 && sourceHeight == 0) {
            destSourceWidth = classImage.getWidth();
            destSourceHeight = classImage.getHeight();
        }

        g.setColor(color);
        g.drawImage(classImage, this.x + x, this.y + y, classImage.getTextureWidth(), classImage.getTextureHeight(), sourceX, sourceY, destSourceWidth, destSourceHeight);
    }
}
