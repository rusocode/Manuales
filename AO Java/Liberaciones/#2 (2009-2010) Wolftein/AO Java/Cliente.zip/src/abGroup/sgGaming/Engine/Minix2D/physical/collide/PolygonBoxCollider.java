/*
 * @(#)PolygonBoxCollider.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical.collide;

import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.physical.Body;
import abGroup.sgGaming.Engine.Minix2D.physical.Contact;
import abGroup.sgGaming.Engine.Minix2D.physical.Shapes.Box;
import abGroup.sgGaming.Engine.Minix2D.physical.Shapes.Polygon;

/**
 * Collide a Convex Polygon with a Box.
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class PolygonBoxCollider extends PolygonPolygonCollider {

    /**
     * @see net.phys2d.raw.collide.Collider#collide(net.phys2d.raw.Contact[], net.phys2d.raw.Body, net.phys2d.raw.Body)
     */
    public int collide(Contact[] contacts, Body bodyA, Body bodyB) {
        Polygon poly = (Polygon) bodyA.getShape();
        Box box = (Box) bodyB.getShape();

        // TODO: this can be optimized using matrix multiplications and moving only one shape
        // specifically the box, because it has fewer vertices.
        Vector2f[] vertsA = poly.getVertices(bodyA.getPosition(), bodyA.getRotation());
        Vector2f[] vertsB = box.getPoints(bodyB.getPosition(), bodyB.getRotation());

        // TODO: use a sweepline that has the smallest projection of the box
        // now we use just an arbitrary one
        Vector2f sweepline = new Vector2f(vertsB[1]);
        sweepline.Sub(vertsB[2]);

        EdgeSweep sweep = new EdgeSweep(sweepline);

        sweep.addVerticesToSweep(true, vertsA);
        sweep.addVerticesToSweep(false, vertsB);

        int[][] collEdgeCands = sweep.getOverlappingEdges();
//		FeaturePair[] featurePairs = getFeaturePairs(contacts.length, vertsA, vertsB, collEdgeCands);
//		return populateContacts(contacts, vertsA, vertsB, featurePairs);

        Intersection[][] intersections = getIntersectionPairs(vertsA, vertsB, collEdgeCands);
        return populateContacts(contacts, vertsA, vertsB, intersections);
    }
}
