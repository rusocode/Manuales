/*
 * @(#)FileSystemStream.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.util.filesystem;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public interface FileSystemStream {

    public String getLocalPath();

    public void create( String path ) throws IOException;

    public byte[] load(String filename ) throws IOException;

    public DataInputStream open(String filename) throws IOException;

    public String[] getFileList( String path );

    public DataOutputStream retrieve(String filename) throws IOException;

    public boolean check(String filename);

    public void delete(String filename);

}
