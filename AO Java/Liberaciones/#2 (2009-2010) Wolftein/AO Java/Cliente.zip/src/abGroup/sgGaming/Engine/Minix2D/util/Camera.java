/*
 * @(#)Camera.java	1.0 Feb 7, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package abGroup.sgGaming.Engine.Minix2D.util;

import abGroup.sgGaming.Engine.Minix2D.device.Canvas;
import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 7, 2010
 * @since
 */
public class Camera implements MXSerializable {

    /** The current camera view **/
    protected Canvas canvas;
    protected int locationX = 0, locationY = 0, locationZ = 0;
    protected int centerX, centerY;
    protected float rotate = 0.0f;
    /** Current Zoom View **/
    protected float zoomX = 1.0f, zoomY = 1.0f;
    protected Vector2f size;

    /**
     * Apply the spatial effect.
     *
     * @param t
     */
    public void applyPreSpatialRender(Graphics2D g, Spatial t) {
        return;
    }

    /**
     * Restore the spatial effect.
     *
     * @param t
     */
    public void applyPostSpatialRender(Graphics2D g, Spatial t) {
        return;
    }

    /**
     * Apply the global effect.
     *
     * @param g
     * @param c
     */
    public void applyRender(Graphics2D g) {
        g.getTransform();
        size = canvas.getSize();
        if (zoomX != 1.0f && zoomY != 1.0f) {
            canvas.setViewport(0, 0, size.x, size.y);
            canvas.setOrtho(0, size.x / zoomX, size.y / zoomY, 0, -100, 100);
        }
        setCenter();
        g.translate(-locationX + centerX, -locationY + centerY, locationZ);
        g.rotate(rotate);
        g.translate(-centerX, -centerY, -locationZ);
    }

    /**
     * Apply the restore global effect.
     *
     * @param g
     * @param c
     */
    public void applyPostRender(Graphics2D g) {
        if (zoomX != 1.0f && zoomY != 1.0f) {
            canvas.setViewport(0, 0, size.x, size.y);
            canvas.setOrtho(0, size.x, size.y, 0, -100, 100);
        }
        g.setTransform();
    }

    /**
     * Calculate the center of the screen.
     *
     * @param c
     */
    private void setCenter() {
        centerX = (int) (locationX + canvas.getSize().x / zoomX / 2.0f);
        centerY = (int) (locationY + canvas.getSize().y / zoomY / 2.0f);
    }

    /**
     * Set the camera canvas.
     *
     * @param c
     */
    public void setCanvas(Canvas c) {
        canvas = c;
    }

    /**
     * Set the camera location.
     *
     * @param x
     * @param y
     * @param z
     */
    public void setLocation(int x, int y, int z) {
        locationX = x;
        locationY = y;
        locationZ = z;
        setCenter();
    }

    /**
     * Move the camera location.
     *
     * @param x
     * @param y
     * @param z
     */
    public void move(int x, int y, int z) {
        setLocation(locationX + x, locationY + y, locationZ + z);
    }

    /**
     * Center the camera on the location.
     *
     * @param x
     * @param y
     */
    public void centerOn(int x, int y) {
        setLocation((int) (-canvas.getSize().x / zoomX) / 2 + x,
                (int) (-canvas.getSize().y / zoomY) / 2 + y, locationZ);
    }

    /**
     * Set the rotation of the camera.
     *
     * @param angle
     */
    public void setRotate(float angle) {
        rotate = angle;
    }

    /**
     * @return The camera rotation
     */
    public float getRotate() {
        return rotate;
    }

    /**
     * @return The camera zoom.
     */
    public float getZoom() {
        return zoomX;
    }

    /**
     * Set the camera zoom pixel.
     *
     * @param zoom
     */
    public void setZoom(float zoom) {
        zoom = Math.round(zoom * 1000.0f) / 1000.0f;
        if (zoom > -1.0f && zoom < 1.0f) {
            return;
        } else if (zoom < 0.0f) {
            zoom = 1.0f / zoom;
        }
        zoom = Math.abs(zoom);

        zoomX = zoom;
        zoomY = zoom;
        centerOn(centerX, centerY);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.util.MXSerializable
     */
    public void save(DataOutputStream out) throws IOException {
        out.writeInt(locationX);
        out.writeInt(locationY);
        out.writeInt(locationZ);
        out.writeInt(centerX);
        out.writeInt(centerY);
        out.writeFloat(rotate);
        out.writeFloat(zoomX);
        out.writeFloat(zoomY);
        size.save(out);
    }
}
