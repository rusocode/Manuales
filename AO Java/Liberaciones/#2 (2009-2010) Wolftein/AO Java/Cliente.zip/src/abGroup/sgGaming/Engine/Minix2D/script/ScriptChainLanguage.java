/*
 * @(#)ScriptChainLanguage.java	1.0 May 27, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.script;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,May 27, 2010
 * @since
 */
public class ScriptChainLanguage implements ScriptChain<String,String> {

    Pattern patter;

    public ScriptChainLanguage( String regex ) {
        patter = Pattern.compile( regex );
    }

    public String getScriptName() {
        return "Language Script";
    }

    public String getScriptValue(String value) {
        boolean found = false;
        String regExp = value;
        // Find the regex expression
        Matcher matcher = patter.matcher( value );
        // While we found
        System.out.println( patter.pattern() + " " + patter.quote(patter.pattern()) );
        while( matcher.find() ) {
            System.out.println( matcher.group() );
        }
        return regExp;
    }

}
