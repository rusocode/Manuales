//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.Client.Foundation.Space;

import abGroup.sgGaming.Minix2D.Networking.Message.Message;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * This message indicate the selection of a character in the client for enter in the world.
 *
 * @author Agustin L. Alvarez
 */
public class vpSelectCharacterMessage implements Message {
    
    /** Message ID implementation **/
    public final static int ID = 3;
    
    /** Character index selected **/
    private byte pkSelected;
    
    /**
     * <Client> Constructor
     * 
     * @param index The index that the client select.
     */
    public vpSelectCharacterMessage( byte index ) {
        pkSelected = index;
    }
    
    /**
     * @see abGroup.sgGaming.Minix2D.Networking.Message.Message
     */
    public short getID() {
        return ID;
    }
    /**
     * @see abGroup.sgGaming.Minix2D.Networking.Message.Message
     */
    public void encode(DataOutputStream dout) throws IOException {
        dout.writeByte(pkSelected);
    }
    /**
     * @see abGroup.sgGaming.Minix2D.Networking.Message.Message
     */
    public void decode(DataInputStream din) throws IOException {
        pkSelected = din.readByte();
    }

    /**
     * @return The selected index.
     */
    public byte getSelectedCharacter() {
        return pkSelected;
    }

}
