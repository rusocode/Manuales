/*
 * @(#)AngleJoint.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical;

import abGroup.sgGaming.Engine.Minix2D.math.Matrix2f;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;

/**
 * A joint that constrains the angle two bodies can be at in relation to each other.
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class AngleJoint implements Joint {
    /**The higher angle bound in the angle constraint*/
    private float rotateA;
    /**The lower angle bound in the angle constraint*/
    private float rotateB;
    /**The first body in the constraint*/
    private Body body1;
    /**The second body in the constraint*/
    private Body body2;
    /** Anchor point for first body, on which impulse is going to apply*/
    private Vector2f anchor1;
    /** Anchor point for second body, on which impulse is going to apply*/
    private Vector2f anchor2;
    /** The cached impulse through the calculation to yield correct impulse faster */
    private float accumulateImpulse;
    /** The target angular velocity after bounce on either side*/
    private float restituteAngular;
    /** Indication on which side the constraint is violated*/
    private int bounceSide;
    /** The squared distance of two body*/
    private float dlength2;
    /** Used to calculate the relation ship between impulse and velocity change between body*/
    private float K;
    /** Normalised distance vector*/
    private Vector2f ndp;
    /** Distance Vector*/
    private Vector2f dp;
    /** The normal vector of the impulse direction*/
    private Vector2f n;
    /** for bounceSide to indicate bounce on lower side*/
    private final int BOUNCE_LOWER = -1;
    /** for bounceSide to indicate bounce on no side*/
    private final int BOUNCE_NONE = 0;
    /** for bounceSide to indicate bounce on higher side*/
    private final int BOUNCE_HIGHER = 1;
    /** The restitution constant when angle bounce on either side*/
    float restitution;
    /** R = r1 + d */
    private Vector2f R;

    /**
     * Create a new angle joint
     *
     * @param body1	The first body that is attached on the constraint
     * @param body2 The second body that is attached on the constraint
     * @param anchor1 The anchor point on first body
     * @param anchor2 The anchor point on second body
     * @param rotateA The higher angle bound for constraint
     * @param rotateB The lower angle bound for constraint
     */
    public AngleJoint(Body body1, Body body2, Vector2f anchor1,
            Vector2f anchor2, float rotateA, float rotateB) {
        this(body1, body2, anchor1, anchor2, rotateA, rotateB, 0);
    }

    /**
     * Create a new angle joint
     *
     * @param body1	The first body that is attached on the constraint
     * @param body2 The second body that is attached on the constraint
     * @param anchor1 The anchor point on first body
     * @param anchor2 The anchor point on second body
     * @param rotateA The higher angle bound for constraint
     * @param rotateB The lower angle bound for constraint
     * @param restitution The restitution when body bounce on either side
     */
    public AngleJoint(Body body1, Body body2, Vector2f anchor1,
            Vector2f anchor2, float rotateA, float rotateB, float restitution) {
        this.body1 = body1;
        this.body2 = body2;
        this.rotateA = rotateA;
        this.rotateB = rotateB;
        this.anchor1 = anchor1;
        this.anchor2 = anchor2;
        this.restitution = restitution;
    }

    /**
     * @see net.phys2d.raw.Joint#applyImpulse()
     */
    public void applyImpulse() {
        if (bounceSide == BOUNCE_NONE) {
            return;
        }
        Matrix2f rot1 = new Matrix2f(body1.getRotation());
        Matrix2f rot2 = new Matrix2f(body2.getRotation());
        Vector2f r1 = Vector2f.mul(rot1, anchor1);
        Vector2f r2 = Vector2f.mul(rot2, anchor2);

        Vector2f relativeVelocity = new Vector2f(body2.getVelocity());
        relativeVelocity.Add(Vector2f.cross(r2, body2.getAngularVelocity()));
        relativeVelocity.Sub(body1.getVelocity());
        relativeVelocity.Sub(Vector2f.cross(r1, body1.getAngularVelocity()));

        /*
         * Matrix2f tr1 = new Matrix2f(-body1.getRotation()); relativeVelocity =
         * MathUtil.mul(tr1, relativeVelocity);
         * relativeVelocity.add(MathUtil.mul(tr1, dp));
         */

        float rv = Vector2f.cross(dp, relativeVelocity) / dlength2 - body1.getAngularVelocity();
        rv = restituteAngular - rv;

        float p = rv / K;
        float oldImpulse = accumulateImpulse;
        float newImpulse;

        if (bounceSide == BOUNCE_HIGHER) {
            newImpulse = accumulateImpulse + p > 0.0f ? accumulateImpulse + p
                    : 0.0f;
            p = newImpulse - oldImpulse;
        } else {
            newImpulse = accumulateImpulse + p < 0.0f ? accumulateImpulse + p
                    : 0.0f;
            p = newImpulse - oldImpulse;
        }
        accumulateImpulse = newImpulse;

        Vector2f impulse = new Vector2f(n);
        impulse.Scale(p);
        if (!body1.isStatic()) {
            Vector2f accum1 = new Vector2f(impulse);
            accum1.Scale(body1.getInvMass());
            body1.adjustVelocity(accum1);
            body1.adjustAngularVelocity((body1.getInvI() * Vector2f.cross(R,
                    impulse)));
        }
        if (!body2.isStatic()) {
            Vector2f accum2 = new Vector2f(impulse);
            accum2.Scale(-body2.getInvMass());
            body2.adjustVelocity(accum2);
            body2.adjustAngularVelocity(-(body2.getInvI() * Vector2f.cross(r2,
                    impulse)));
        }
    }

    /**
     * @see net.phys2d.raw.Joint#getBody1()
     */
    public Body getBody1() {
        return body1;
    }

    /**
     * @see net.phys2d.raw.Joint#getBody2()
     */
    public Body getBody2() {
        return body2;
    }

    /**
     * @see net.phys2d.raw.Joint#preStep(float)
     */
    public void preStep(float invDT) {
        float biasFactor = 0.005f;
        float biasImpulse = 0.0f;
        float RA = body1.getRotation() + rotateA;
        float RB = body1.getRotation() + rotateB;

        Vector2f VA = new Vector2f((float) Math.cos(RA), (float) Math.sin(RA));
        Vector2f VB = new Vector2f((float) Math.cos(RB), (float) Math.sin(RB));

        Matrix2f rot1 = new Matrix2f(body1.getRotation());
        Matrix2f rot2 = new Matrix2f(body2.getRotation());
        Vector2f r1 = Vector2f.mul(rot1, anchor1);
        Vector2f r2 = Vector2f.mul(rot2, anchor2);

        Vector2f p1 = new Vector2f(body1.getPosition());
        p1.Add(r1);
        Vector2f p2 = new Vector2f(body2.getPosition());
        p2.Add(r2);
        dp = new Vector2f(p2);
        dp.Sub(p1);
        dlength2 = dp.LengthSquared();
        ndp = new Vector2f(dp);
        ndp.Normalise();

        R = new Vector2f(r1);
        R.Add(dp);
        // System.out.println(accumulateImpulse);
        Vector2f relativeVelocity = new Vector2f(body2.getVelocity());
        relativeVelocity.Add(Vector2f.cross(r2, body2.getAngularVelocity()));
        relativeVelocity.Sub(body1.getVelocity());
        relativeVelocity.Sub(Vector2f.cross(r1, body1.getAngularVelocity()));

        /*
         * Matrix2f tr1 = new Matrix2f(-body1.getRotation()); relativeVelocity =
         * MathUtil.mul(tr1, relativeVelocity);
         * relativeVelocity.add(MathUtil.mul(tr1, dp));
         */
        // relativeVelocity.add(MathUtil.cross(dp,body1.getAngularVelocity()));
        n = new Vector2f(-ndp.y, ndp.x);
        Vector2f v1 = new Vector2f(n);
        v1.Scale(-body2.getInvMass() - body1.getInvMass());

        Vector2f v2 = Vector2f.cross(Vector2f.cross(r2, n), r2);
        v2.Scale(-body2.getInvI());

        Vector2f v3 = Vector2f.cross(Vector2f.cross(R, n), r1);
        v3.Scale(-body1.getInvI());

        Vector2f K1 = new Vector2f(v1);
        K1.Add(v2);
        K1.Add(v3);

        K = Vector2f.cross(dp, K1) / dlength2 - Vector2f.cross(R, n) * body1.getInvI();

        restituteAngular = -restitution * (Vector2f.cross(dp, relativeVelocity) / dlength2 - body1.getAngularVelocity());

        if (Vector2f.cross(ndp, VA) > 0) {
            // collide on A side
            if (bounceSide != BOUNCE_LOWER) {
                accumulateImpulse = 0;
            }
            biasImpulse = biasFactor * Vector2f.cross(ndp, VA) * invDT;
            bounceSide = BOUNCE_LOWER;
            if (restituteAngular < 0) {
                restituteAngular = 0;
            }
        } else if (Vector2f.cross(VB, ndp) > 0) {
            // collide on B side
            if (bounceSide != BOUNCE_HIGHER) {
                accumulateImpulse = 0;
            }
            biasImpulse = -biasFactor * Vector2f.cross(VB, ndp) * invDT;
            bounceSide = BOUNCE_HIGHER;
            if (restituteAngular > 0) {
                restituteAngular = 0;
            }
        } else {
            accumulateImpulse = 0;
            biasImpulse = 0.0f;
            bounceSide = BOUNCE_NONE;
        }
        restituteAngular += biasImpulse;

        Vector2f impulse = new Vector2f(n);
        impulse.Scale(accumulateImpulse);
        if (!body1.isStatic()) {
            Vector2f accum1 = new Vector2f(impulse);
            accum1.Scale(body1.getInvMass());
            body1.adjustVelocity(accum1);
            body1.adjustAngularVelocity((body1.getInvI() * Vector2f.cross(R,
                    impulse)));
        }
        if (!body2.isStatic()) {
            Vector2f accum2 = new Vector2f(impulse);
            accum2.Scale(-body2.getInvMass());
            body2.adjustVelocity(accum2);
            body2.adjustAngularVelocity(-(body2.getInvI() * Vector2f.cross(r2,
                    impulse)));
        }
    }

    /**
     * @see net.phys2d.raw.Joint#setRelaxation(float)
     */
    public void setRelaxation(float relaxation) {
    }

    /**
     * Get the upper angle bound
     *
     * @return The upper angle bound
     */
    public float getRotateA() {
        return rotateA;
    }

    /**
     * Get the lower angle bound
     *
     * @return The lower angle bound
     */
    public float getRotateB() {
        return rotateB;
    }

    /**
     * Get the anchor of the joint on the first body
     *
     * @return The anchor of the joint on the first body
     */
    public Vector2f getAnchor1() {
        return anchor1;
    }

    /**
     * Get the anchor of the joint on the second body
     *
     * @return The anchor of the joint on the second body
     */
    public Vector2f getAnchor2() {
        return anchor2;
    }

}
