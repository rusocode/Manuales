/*
 * @(#)ThreadContext.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.util.thread;

import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug.TypeDebug;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug.TypeDebugChannel;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class ThreadContext {

    /** The java thread **/
    protected Thread javaThread;

    public ThreadContext(Runnable func) {
        javaThread = new Thread(func);
    }

    public ThreadContext(String name, Runnable func) {
        javaThread = new Thread(func, name);
    }

    public void start() {
        javaThread.start();
    }

    public static void sleep(int time) {
        try {
            Thread.sleep(time);
        } catch (InterruptedException ex) {
            Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                    TypeDebug.ERROR,
                    String.format("ThreadContext@sleep Exception on thread %d/%s", Thread.currentThread().getId(), Thread.currentThread().getName()));
        }
    }
}
