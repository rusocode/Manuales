/*
 * @(#)PhysicalSpatial.java	1.0 Feb 11, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D_X.util;

import abGroup.sgGaming.Engine.Minix2D.physical.Body;
import abGroup.sgGaming.Engine.Minix2D.util.Spatial;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 11, 2010
 * @since
 */
public class PhysicalSpatial extends Spatial {

    /** Physical Property **/
    protected Body body;


    /**
     * Constructor
     *
     * @param imageFilename
     * @param x
     * @param y
     * @param z
     * @param g
     */
    public PhysicalSpatial(String imageFilename, int x, int y, int z, Body g ) {
        super(imageFilename,x,y,z);
    }

    /**
     * Set the physical body.
     *
     * @param g
     */
    public void setPhysicalBody( Body g ) {
        body = g;
    }

    /**
     * @return The body of the spatial
     */
    public Body getPhysicalBody() {
        return body;
    }

}
