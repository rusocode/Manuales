/*
 * @(#)Vector2f.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.math;

import abGroup.sgGaming.Engine.Minix2D.util.MXSerializable;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.StringTokenizer;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class Vector2f implements MXSerializable {

    /**
     * The x component of this vector
     */
    public float x;
    /**
     * The y component of this vector
     */
    public float y;

    /**
     * Create an empty vector
     */
    public Vector2f() {
    }

    /**
     * Get the X component of this vector
     *
     * @return The X component of this vector
     */
    public float GetX() {
        return x;
    }

    /**
     * Get the Y component of this vector
     *
     * @return The Y component of this vector
     */
    public float GetY() {
        return y;
    }

    /**
     * Create a new vector based on another
     *
     * @param other The other vector to copy into this one
     */
    public Vector2f(Vector2f other) {
        this(other.GetX(), other.GetY());
    }

    /**
     * Create a new vector
     *
     * @param x The x component to assign
     * @param y The y component to assign
     */
    public Vector2f(float x, float y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Set the value of this vector
     *
     * @param other The values to set into the vector
     */
    public void Set(Vector2f other) {
        Set(other.GetX(), other.GetY());
    }

    /**
     * Get the dot product of this vector and another
     *
     * @param other The other vector to dot against
     * @return The dot product of the two vectors
     */
    public float Dot(Vector2f other) {
        return (x * other.GetX()) + (y * other.GetY());
    }

    /**
     * Set the values in this vector
     *
     * @param x The x component to set
     * @param y The y component to set
     */
    public void Set(float x, float y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Negate this vector
     *
     * @return A copy of this vector negated
     */
    public Vector2f Negate() {
        return new Vector2f(-x, -y);
    }

    /**
     * Add a vector to this vector
     *
     * @param v The vector to add
     */
    public void Add(Vector2f v) {
        x += v.GetX();
        y += v.GetY();
    }

    /**
     * Subtract a vector from this vector
     *
     * @param v The vector subtract
     */
    public void Sub(Vector2f v) {
        x -= v.GetX();
        y -= v.GetY();
    }

    /**
     * Scale this vector by a value
     *
     * @param a The value to scale this vector by
     */
    public void Scale(float a) {
        x *= a;
        y *= a;
    }

    /**
     * Normalise the vector
     *
     */
    public void Normalise() {
        float l = length();

        if (l == 0) {
            return;
        }

        x /= l;
        y /= l;
    }

    /**
     * The length of the vector squared
     *
     * @return The length of the vector squared
     */
    public float LengthSquared() {
        return (x * x) + (y * y);
    }

    /**
     * Get the length of this vector
     *
     * @return The length of this vector
     */
    public float length() {
        return (float) Math.sqrt(LengthSquared());
    }

    /**
     * Project this vector onto another
     *
     * @param b The vector to project onto
     * @param result The projected vector
     */
    public void ProjectOntoUnit(Vector2f b, Vector2f result) {
        float dp = b.Dot(this);

        result.x = dp * b.GetX();
        result.y = dp * b.GetY();
    }

    /**
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "[Vec " + x + "," + y + " (" + length() + ")]";
    }

    /**
     * Get the distance from this point to another
     *
     * @param other The other point we're measuring to
     * @return The distance to the other point
     */
    public float Distance(Vector2f other) {
        return (float) Math.sqrt(DistanceSquared(other));
    }

    /**
     * Get the distance squared from this point to another
     *
     * @param other The other point we're measuring to
     * @return The distance to the other point
     */
    public float DistanceSquared(Vector2f other) {
        float dx = other.GetX() - GetX();
        float dy = other.GetY() - GetY();

        return (dx * dx) + (dy * dy);
    }

    /**
     * Compare two vectors allowing for a (small) error as indicated by the delta.
     * Note that the delta is used for the vector's components separately, i.e.
     * any other vector that is contained in the square box with sides 2*delta and this
     * vector at the center is considered equal.
     *
     * @param other The other vector to compare this one to
     * @param delta The allowed error
     * @return True iff this vector is equal to other, with a tolerance defined by delta
     */
    public boolean EqualsDelta(Vector2f other, float delta) {
        return (other.GetX() - delta < x &&
                other.GetX() + delta > x &&
                other.GetY() - delta < y &&
                other.GetY() + delta > y);

    }

    /**
     * Make a vector absolute
     *
     * @param a The vector to make absolute
     * @return A newly created result vector
     */
    public static Vector2f abs(Vector2f a) {
        return new Vector2f(Math.abs(a.x), Math.abs(a.y));
    }

    /**
     * Multiply a matrix by a vector
     *
     * @param A The matrix to be multiplied
     * @param v The vector to multiple by
     * @return A newly created vector containing the resultant vector
     */
    public static Vector2f mul(Matrix2f A, Vector2f v) {
        return new Vector2f(A.col1.x * v.GetX() + A.col2.x * v.GetY(), A.col1.y * v.GetX() + A.col2.y * v.GetY());
    }

    /**
     * Scale a vector by a given value
     *
     * @param a The vector to be scaled
     * @param scale The amount to scale the vector by
     * @return A newly created vector - a scaled version of the new vector
     */
    public static Vector2f scale(Vector2f a, float scale) {
        Vector2f temp = new Vector2f(a);
        temp.Scale(scale);

        return temp;
    }

    /**
     * Subtract one vector from another
     *
     * @param a The vector to be subtracted from
     * @param b The vector to subtract
     * @return A newly created containing the result
     */
    public static Vector2f sub(Vector2f a, Vector2f b) {
        Vector2f temp = new Vector2f(a);
        temp.Sub(b);

        return temp;
    }

    /**
     * Find the cross product of two vectors
     *
     * @param a The first vector
     * @param b The second vector
     * @return The cross product of the two vectors
     */
    public static float cross(Vector2f a, Vector2f b) {
        return a.x * b.y - a.y * b.x;
    }

    /**
     * Find the cross product of a vector and a float
     *
     * @param s The scalar float
     * @param a The vector to fidn the cross of
     * @return A newly created resultant vector
     */
    public static Vector2f cross(float s, Vector2f a) {
        return new Vector2f(-s * a.y, s * a.x);
    }

    /**
     * Find the cross product of a vector and a float
     *
     * @param s The scalar float
     * @param a The vector to fidn the cross of
     * @return A newly created resultant vector
     */
    public static Vector2f cross(Vector2f a, float s) {
        return new Vector2f(s * a.y, -s * a.x);
    }

    /**
     * Get the normal of a line x y (or edge).
     * When standing on x facing y, the normal will point
     * to the left.
     *
     * @param x startingpoint of the line
     * @param y endpoint of the line
     * @return a (normalised) normal
     */
    public static Vector2f getNormal(Vector2f x, Vector2f y) {
        Vector2f normal = new Vector2f(y);
        normal.Sub(x);

        normal = new Vector2f(normal.y, -normal.x);
        normal.Normalise();

        return normal;
    }

    /**
     * Parse a float 2D Vector from a xmllist.
     *
     * @param element
     * @return
     */
    public static Vector2f parseOf( XMLElement element ) {
        return null;
    }

    /**
     * parse a float 2D vector from a string.
     *
     * @param line
     * @return
     */
    public static Vector2f parseOf(String line) {
        StringTokenizer parser = new StringTokenizer(line, ",");
        if (parser.countTokens() != 2) {
            throw new RuntimeException("Error parsing a Vector2f, invalid data.");
        }

        return new Vector2f(Float.parseFloat(parser.nextToken()), Float.parseFloat(parser.nextToken()));
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.util.MXSerializable
     */
    public void save(DataOutputStream out) throws IOException {
        out.writeFloat(x);
        out.writeFloat(y);
    }
}
