/*
 * @(#)Recorder.java	1.0 Feb 12, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D_X.device;

import java.util.ArrayList;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 12, 2010
 * @since
 */
public class Recorder {

    private String filename;
    private boolean status;
    private ArrayList<RecordFrame> frames;
    
    /**
     * Constructor
     *
     * @param filename
     */
    public Recorder( String filename ) {
        this.filename = filename;
    }

    /**
     * Set the status of the recorded.
     *
     * @param on
     */
    public void setStatus(boolean on ) {
        status = on;
    }

    /**
     * This function is called each frame.
     */
    public void onApplicationFrame( ) {

    }

}
