/*
 * @(#)ConvexPolygon.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical.Shapes;

import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;

/**
 * Class representing a convex and closed polygon as a list of vertices
 * in counterclockwise order. Convexity is maintained by a check in the
 * constructor after which the polygon becomes immutable.
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class ConvexPolygon extends Polygon implements DynamicShape {

    /** Construct the convex polygon with a list of vertices
     * sorted in counterclockwise order.
     * Note that all the vector values will be copied.
     *
     * Throws an exception when too few vertices are given (< 3)
     * and when the supplied vertices are not convex.
     * Polygons with area = 0, will be reported as non-convex too.
     *
     * @param vertices Vertices sorted in counterclockwise order
     */
    public ConvexPolygon(Vector2f[] vertices) {
        if (vertices.length < 3) {
            throw new IllegalArgumentException("A polygon can not have fewer than 3 edges!");
        }

        this.vertices = new Vector2f[vertices.length];

        for (int i = 0; i < vertices.length; i++) {
            this.vertices[i] = new Vector2f(vertices[i]);
        }

        if (!super.isConvex()) {
            throw new IllegalArgumentException("The supplied vertices do not represent a convex polygon!");
        }

        float r = computeBoundingCircleRadius();
        this.bounds = new AABox(r * 2, r * 2);
        this.area = computeArea();
        this.centroid = computeCentroid();
    }

    /**
     * Because convexness is checked at construction
     * we can always return true here.
     * @see Polygon#isConvex()
     */
    public boolean isConvex() {
        return true;
    }

    /**
     * Test whether or not the point p is in this polygon in O(n),
     * where n is the number of vertices in this polygon.
     *
     * @param p The point to be tested for inclusion in this polygon
     * @return true iff the p is in this polygon (not on a border)
     */
    public boolean contains(Vector2f p) {
        // p is in the polygon if it is left of all the edges
        int l = vertices.length;
        for (int i = 0; i < vertices.length; i++) {
            Vector2f x = vertices[i];
            Vector2f y = vertices[(i + 1) % l];
            Vector2f z = p;

            // does the 3d cross product point up or down?
            if ((z.x - x.x) * (y.y - x.y) - (y.x - x.x) * (z.y - x.y) >= 0) {
                return false;
            }
        }

        return true;
    }

    /**
     * Get point on this polygon's hull that is closest to p.
     *
     * TODO: make this thing return a negative value when it is contained in the polygon
     *
     * @param p The point to search the closest point for
     * @return the nearest point on this vertex' hull
     */
    public Vector2f getNearestPoint(Vector2f p) {
        // TODO: this can be done with a kind of binary search
        float r = Float.MAX_VALUE;
        float l;
        Vector2f v;
        int m = -1;

        for (int i = 0; i < vertices.length; i++) {
            v = new Vector2f(vertices[i]);
            v.Sub(p);
            l = v.x * v.x + v.y * v.y;

            if (l < r) {
                r = l;
                m = i;
            }
        }

        // the closest point could be on one of the closest point's edges
        // this happens when the angle between v[m-1]-v[m] and p-v[m] is
        // smaller than 90 degrees, same for v[m+1]-v[m]
        int length = vertices.length;
        Vector2f pm = new Vector2f(p);
        pm.Sub(vertices[m]);
        Vector2f l1 = new Vector2f(vertices[(m - 1 + length) % length]);
        l1.Sub(vertices[m]);
        Vector2f l2 = new Vector2f(vertices[(m + 1) % length]);
        l2.Sub(vertices[m]);

        Vector2f normal;
        if (pm.Dot(l1) > 0) {
            normal = Vector2f.getNormal(vertices[(m - 1 + length) % length], vertices[m]);
        } else if (pm.Dot(l2) > 0) {
            normal = Vector2f.getNormal(vertices[m], vertices[(m + 1) % length]);
        } else {
            return vertices[m];
        }

        normal.Scale(-pm.Dot(normal));
        normal.Add(p);
        return normal;
    }

    /**
     * @see net.phys2d.raw.shapes.Shape#getSurfaceFactor()
     */
    public float getSurfaceFactor() {
        // TODO: return the real surface factor
        return getArea();
    }

}
