//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.CSprite;

import abGroup.sgGaming.Games.Nylox.Client.Engine.Manager.SpriteDataClass;
import abGroup.sgGaming.Minix2D.Foundation.Singleton;
import abGroup.sgGaming.Minix2D.Renderer.Texture;
import abGroup.sgGaming.Minix2D.Util.Tokenizer;
import java.util.ArrayList;

/**
 * <class>SpriteParse</class> parse each sprite data given. This module has
 * a followed standart.
 *
 * @author Agustin L. Alvarez
 */
public class SpriteParser {

    /**
     * Current Parser index.
     */
    private static int pkCurrent = 0;
    /**
     * List of parser file.
     */
    private static String[] pkList;
    /**
     * Our Calculated Sprites.
     */
    private static ArrayList<SpriteDataClass> pkSpriteList = new ArrayList<SpriteDataClass>();
    /**
     * Our SubType Sprites.
     */
    private static ArrayList<int[]> pkSpriteBody = new ArrayList<int[]>( );
    private static ArrayList<int[]> pkSpriteHead = new ArrayList<int[]>( );
    private static ArrayList<int[]> pkSpriteHand = new ArrayList<int[]>( );

    /**
     * Parse the given Sprite list.
     *
     * @param List
     */
    public static void Parser( String[] List ) {
        pkList = List;
    }

    /**
     * Start parsing the next file.
     *
     * @return The Current index.
     */
    public static int Next( ) {
        if( ParseElement( pkCurrent ) == true )
            pkCurrent++;
        // Return the current parsed index.
        return pkCurrent;
    }

    /**
     * @return If the parse has been finished
     */
    public static boolean Finish( ) {
        return (pkCurrent == pkList.length);
    }

    /**
     * Parse the current index.
     * 
     * @param index
     * @return
     */
    private static boolean ParseElement( int index ) {
        boolean bNotContinue = false;
        // Get the Name of the path.
        String element = pkList[index];
        SpriteDataClass baseSprite, childSprite;
        // Parse the Directory Header.
        String imageName = element.substring( element.lastIndexOf("/") + 1 );
        String rowString = element.substring( element.indexOf("//") + 2, element.lastIndexOf("/") );
        int[] rowSize = new int[] { Integer.valueOf( Tokenizer.Tokenize( rowString, 1, "_" ) ),
                                    Integer.valueOf( Tokenizer.Tokenize( rowString, 2, "_" ) ),
                                    Integer.valueOf( Tokenizer.Tokenize( rowString, 3, "_" ) ),
                                    Integer.valueOf( Tokenizer.Tokenize( rowString, 4, "_" ) ),
                                    Integer.valueOf( Tokenizer.Tokenize( rowString, 5, "_" ) ) };
        // Load the Texture for parsing dimension
        Texture tex = Singleton.GetDevice().LoadImage(element.replaceAll("//", "/"));
        // Parse the Sprite Dimension of Height.
        int ElementHeight = tex.GetImageHeight( ) / rowSize[4];
        int ElementWidth  = 0;
        int ElementFrame  = 0;
        // Create the Base Sprite and add to the database
        baseSprite = CreateSprite( imageName, 0, 0, tex.GetImageWidth(), tex.GetTextureHeight(), (rowSize[0] + rowSize[1] + rowSize[2] + rowSize[3]) );
        pkSpriteList.add(baseSprite);
        // For Each Row, Parse the sprite.
        for( int i = 0; i < rowSize[4]; i++ ) {
            // Calculate the animation Width of the row
            ElementWidth = tex.GetImageWidth() / rowSize[i];
            // Check for same texture.
            if (i == 0) {
                if (rowSize[0] == 1) {
                    bNotContinue = true;
                } else {
                    bNotContinue = false;
                }
            } else {
                bNotContinue = false;
            }
            // For Each Animation Create a Sprite.
            if (bNotContinue == false) {
                for (int j = 0; j < rowSize[i]; j++) {
                    // Create the child animation sprite.
                    childSprite = CreateSprite(imageName + "#" + ElementFrame , j * ElementWidth, i * ElementHeight, ElementWidth, ElementHeight, 0);
                    // Add to the list.
                    pkSpriteList.add(childSprite);
                    // Add the animation frame to the base Sprite
                    baseSprite.pkSprite[ElementFrame] = pkSpriteList.size() -1;
                    ElementFrame++;
                }
            }
        }
        // Parse the subType
        ParseSubType( element, baseSprite, rowSize );
        return true;
    }

    /**
     * Parse the subtype of the element, like Head,Body,Weapon.
     * 
     * @param element
     * @param base
     */
    private static void ParseSubType( String element, SpriteDataClass base, int row[] ) {
        // Convert to upper string.
        String upperElement = element.toUpperCase();
        // Check what type of subtype is.
        if( upperElement.indexOf("BODY") != -1 || upperElement.indexOf("ARMOR") != -1 ) {
            // Find the offset for the body
            int offsetX = 0, offsetY = 0;
            // Check for the Y of the Head.
            if( upperElement.indexOf("@T") != -1 ) { // Tall
                offsetY = -20;
            } else if( upperElement.indexOf("@M") != -1 ) { // Medium/Normal
                offsetY = -11;
            } else if( upperElement.indexOf("@S") != -1 ) { // Small
                offsetY = -2;
            }
            // Check for the X of the Head.
            if( upperElement.indexOf("@L") != -1 ) {    // Left
                offsetX = -18;
            } else if( upperElement.indexOf("@R") != -1 ) { // Right
                offsetX = 18;
            } else {
                offsetX = 32 / 2 - 13;
            }
            // With the Body and armor, we just need to store each Body/Armor
            // of each world Direction and the head offset.
            pkSpriteBody.add( new int[] { base.pkSprite[row[0]],
                                          base.pkSprite[0],
                                          base.pkSprite[row[0]+row[1]],
                                          base.pkSprite[row[0]+row[1]+row[2]],
                                          offsetX, offsetY } );
        } else if( upperElement.indexOf("HEAD") != -1 || upperElement.indexOf("HELMET") != -1 ) {
            // We the head and helmet, we just need to store each Head/Helmet
            // of each World Direction (NORTH,EAST,WEST,SOUTH)
            pkSpriteHead.add( new int[] { base.pkSprite[0],
                                          base.pkSprite[3],
                                          base.pkSprite[2],
                                          base.pkSprite[1] } );
        } else if( upperElement.indexOf("SHIELD") != -1 || upperElement.indexOf("WEAPON") != -1 ) {
            // We the shield and weapon, we just need to store each Shield/Weapon
            // of each World Direction (NORTH,EAST,WEST,SOUTH)
            pkSpriteHand.add( new int[] { base.pkSprite[0],
                                          base.pkSprite[1],
                                          base.pkSprite[2],
                                          base.pkSprite[3] } );
        }
        //TODO: Animation
    }

    /**
     * Create a sprite structure.
     *
     * @param filename
     * @param sourceX
     * @param sourceY
     * @param pixelWidth
     * @param pixelHeight
     * @param animCount
     * @return
     */
    private static SpriteDataClass CreateSprite( String filename, int sourceX, int sourceY, int pixelWidth, int pixelHeight, int animCount ) {
        SpriteDataClass spriteData = new SpriteDataClass();
        spriteData.pkFilename = filename;
        spriteData.pkSourceX = (short) sourceX;
        spriteData.pkSourceY = (short) sourceY;
        spriteData.pkSourceWidth = (short) pixelWidth;
        spriteData.pkSourceHeight = (short) pixelHeight;
        spriteData.pkSprite = new int[animCount];
        return spriteData;
    }

    /**
     * Get the sprite given his index.
     *
     * @param index
     * @return
     */
    public static String GetSpriteImage( int index ) {
        if( index < pkList.length && index >= 0 )
            return pkList[index].replaceAll("//", "/");
        return null;
    }

    /**
     * @return The sprite count
     */
    public static int GetSpriteCount( ) {
        return pkSpriteList.size();
    }

    /**
     * @return The sprite list parsed.
     */
    public static SpriteDataClass[] GetSpriteList() {
        SpriteDataClass[] spriteList = new SpriteDataClass[ pkSpriteList.size() ];
        for( int i = 0; i < spriteList.length; i++ )
            spriteList[i] = pkSpriteList.get(i);
        return spriteList;
    }

    /**
     * @return The sprite head list parsed.
     */
    public static int[][] GetBodyList() {
        int[][] bodyList = new int[ pkSpriteBody.size() ][];
        for( int i = 0; i < bodyList.length; i++ )
            bodyList[i] = pkSpriteBody.get(i);
        return bodyList;
    }

    /**
     * @return The sprite head list parsed.
     */
    public static int[][] GetHeadList() {
        int[][] headList = new int[ pkSpriteHead.size() ][];
        for( int i = 0; i < headList.length; i++ )
            headList[i] = pkSpriteHead.get(i);
        return headList;
    }

    /**
     * @return The sprite head list parsed.
     */
    public static int[][] GetHandList() {
        int[][] handList = new int[ pkSpriteHand.size() ][];
        for( int i = 0; i < handList.length; i++ )
            handList[i] = pkSpriteHand.get(i);
        return handList;
    }

}

