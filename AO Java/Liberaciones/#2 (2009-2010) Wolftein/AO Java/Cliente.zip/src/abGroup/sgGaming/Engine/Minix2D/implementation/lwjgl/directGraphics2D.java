/*
 * @(#)directGraphics2D.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl;

import abGroup.sgGaming.Engine.Minix2D.device.Color;
import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.device.Image;
import abGroup.sgGaming.Engine.Minix2D.device.Shape;
import org.lwjgl.opengl.ARBImaging;
import org.lwjgl.opengl.ARBMultisample;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class directGraphics2D extends Graphics2D {

    /**
     * Constructor
     */
    public directGraphics2D() {
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void setHintGraphics(GraphicsHint hint, Object value) {
        // Multisample hint.
        if (hint == GraphicsHint.MULTISAMPLING) {
            if ((Integer) value == 0) {
                GL11.glShadeModel(GL11.GL_FLAT);
                setOpenglProperty(GL11.GL_POINT_SMOOTH, false);
                setOpenglProperty(GL11.GL_LINE_SMOOTH, false);
                setOpenglProperty(GL11.GL_POLYGON_SMOOTH, false);
                setOpenglProperty(ARBMultisample.GL_MULTISAMPLE_ARB, false);
            } else if ((Integer) value == 2) {
                GL11.glShadeModel(GL11.GL_SMOOTH);
                setOpenglProperty(GL11.GL_POINT_SMOOTH, true);
                setOpenglProperty(GL11.GL_LINE_SMOOTH, false);
                setOpenglProperty(GL11.GL_POLYGON_SMOOTH, false);
                setOpenglProperty(ARBMultisample.GL_MULTISAMPLE_ARB, false);
            } else if ((Integer) value == 4) {
                GL11.glShadeModel(GL11.GL_SMOOTH);
                setOpenglProperty(GL11.GL_POINT_SMOOTH, true);
                setOpenglProperty(GL11.GL_LINE_SMOOTH, true);
                setOpenglProperty(GL11.GL_POLYGON_SMOOTH, true);
                setOpenglProperty(ARBMultisample.GL_MULTISAMPLE_ARB, false);
            } else if ((Integer) value == 8) {
                GL11.glShadeModel(GL11.GL_SMOOTH);
                setOpenglProperty(GL11.GL_POINT_SMOOTH, true);
                setOpenglProperty(GL11.GL_LINE_SMOOTH, true);
                setOpenglProperty(GL11.GL_POLYGON_SMOOTH, true);
                setOpenglProperty(ARBMultisample.GL_MULTISAMPLE_ARB, true);
            }
        } else if (hint == GraphicsHint.LINE_WIDTH) {
            GL11.glLineWidth((Float) value);
        }
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void setDepthBuffer(boolean value) {
        depthBuffer = value;
        if (value == true) {
            GL11.glEnable(GL11.GL_DEPTH_TEST);
        } else {
            GL11.glDisable(GL11.GL_DEPTH_TEST);
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void setAlphaBlending(AlphaBlending alphaType) {
        switch (alphaType) {
            case NONE:
                GL11.glDisable(GL11.GL_BLEND);
                break;
            case SOURCE_ALPHA:
                GL11.glEnable(GL11.GL_BLEND);
                GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
                break;
            case DESTINATION_ALPHA:
                GL11.glEnable(GL11.GL_BLEND);
                GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
                break;
            case MULTI_BLEND_ALPHA:
                GL11.glEnable(GL11.GL_BLEND);
                GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_SRC_COLOR);
                break;
            case ADD_BLEND_EQUATION:
                ARBImaging.glBlendEquation(org.lwjgl.opengl.ARBImaging.GL_FUNC_ADD);
                break;
            case SUBSTRACT_BLEND_EQUATION:
                ARBImaging.glBlendEquation(org.lwjgl.opengl.ARBImaging.GL_FUNC_SUBTRACT);
                break;
            case SUBSTRACT_REVERSE_BLEND_EQUATION:
                ARBImaging.glBlendEquation(org.lwjgl.opengl.ARBImaging.GL_FUNC_REVERSE_SUBTRACT);
                break;
        }
        this.alphaBlending = alphaType;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void setColor(Color color) {
        GL11.glColor4f(color.colorArray[0], color.colorArray[1], color.colorArray[2], color.colorArray[3]);
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void drawPoint(int x, int y) {
        // set the texture mode off.
        setTextureMode(false);
        // render the point into the opengl driver.
        GL11.glBegin(GL11.GL_POINTS);
        GL11.glVertex2f(x, y);
        GL11.glEnd();
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void drawLine(int x, int y, int width, int height) {
        // set the texture mode off.
        setTextureMode(false);
        // render the line into the opengl drive.
        GL11.glBegin(GL11.GL_LINES);
        GL11.glVertex2f(x, y);
        GL11.glVertex2f(width, height);
        GL11.glEnd();
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void drawRect(int x, int y, int width, int height) {
        // set the texture mode off.
        setTextureMode(false);
        // render the rectangle into the opengl drive.
        GL11.glBegin(GL11.GL_LINE_STRIP);
        GL11.glVertex2f(x, y);
        GL11.glVertex2f(x + width, y);
        GL11.glVertex2f(x + width, y + height);
        GL11.glVertex2f(x, y + height);
        GL11.glVertex2f(x, y);
        GL11.glEnd();
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void drawOval(int x, int y, int width, int height) {
        // set the texture mode off.
        setTextureMode(false);
        // render the rectangle into the oval drive.
        // Render the Circle.
        float centerX, centerY;
        double pheta, angle;
        angle = 2 * Math.PI / (width*height*Math.PI);
        GL11.glBegin(GL11.GL_LINE_LOOP);
        for (pheta = 0.0f; pheta < 2 * Math.PI; pheta += angle) {
            centerX = width / 2 * (float) Math.cos(pheta);
            centerY = height / 2 * (float) Math.sin(pheta);
            GL11.glVertex2f( centerX + x, centerY + y );
        }
        GL11.glEnd();
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void drawImage(Image image, int x, int y) {
        drawImage( image, x, y, image.getTextureWidth(), image.getTextureHeight(), 0, 0, image.getWidth(), image.getHeight() );
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void drawImage(Image image, int x, int y, float w, float h) {
        drawImage( image, x, y, w, h, 0, 0, image.getWidth(), image.getHeight());
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void drawImage(Image image, int x, int y, float w, float h, float sx, float sy, float sw, float sh) {
        setTextureMode( true );
        // Get the texture property
        int imageWidth = image.getWidth(), imageHeight = image.getHeight();
        // Bind the Texture for rendering.
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, image.getTextureID());
        // Generate Texture Mapping
        float minX = (sx / imageWidth) * 1.0f;
        float minY = (sy / imageHeight) * 1.0f;
        float maxX = (sw - 1.0f) / imageWidth * 1.0f;
        float maxY = (sh - 1.0f) / imageHeight * 1.0f;
        // Direct Rendering to the opengl driver.
        GL11.glBegin(GL11.GL_TRIANGLE_STRIP);
        GL11.glTexCoord2f(minX, minY);
        GL11.glVertex2f(x, y);
        GL11.glTexCoord2f(minX, maxY);
        GL11.glVertex2f(x, y + h);
        GL11.glTexCoord2f(maxX, minY);
        GL11.glVertex2f(x + w, y);
        GL11.glTexCoord2f(maxX, maxY);
        GL11.glVertex2f(x + w, y + h);
        GL11.glEnd();
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void drawFont(Image image, int x, int y, float w, float h, float sx, float sy, float sw, float sh) {
        setTextureMode( true );
        // Get the texture property
        int imageWidth = image.getTextureWidth(), imageHeight = image.getTextureHeight();
        // Bind the Texture for rendering.
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, image.getTextureID());
        // Generate Texture Mapping
        float minX = sx / imageWidth * 1.0f;
        float minY = sy / imageHeight * 1.0f;
        float maxX = (sw - 1.0f) / imageWidth * 1.0f;
        float maxY = (sh - 1.0f) / imageHeight * 1.0f;
        // Direct Rendering to the opengl driver.
        GL11.glBegin(GL11.GL_TRIANGLE_STRIP);
        GL11.glTexCoord2f(minX, maxY);
        GL11.glVertex2f(x, y);
        GL11.glTexCoord2f(minX, minY);
        GL11.glVertex2f(x, h);
        GL11.glTexCoord2f(maxX, maxY);
        GL11.glVertex2f(w, y);
        GL11.glTexCoord2f(maxX, minY);
        GL11.glVertex2f(w, h);
        GL11.glEnd();
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void scale(double x, double y) {
        GL11.glScaled(x,y, 0.0f);
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void rotate(double theta) {
        GL11.glRotatef((float) theta, 0.0f, 0.0f, 1.0f);
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void rotate(double theta, double x, double y) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void setTransform() {
        GL11.glPopMatrix();
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void getTransform() {
        GL11.glPushMatrix();
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void translate(int x, int y, int z) {
        GL11.glTranslatef(x, y, z);
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void translate(double rx, double ry, double rz) {
        GL11.glTranslated(rx, ry, rz);
    }

    private void setTextureMode(boolean value) {
        setOpenglProperty(GL11.GL_TEXTURE_2D,value);
    }

    private void setOpenglProperty( int property, boolean value ) {
        if (value) {
            GL11.glEnable(property);
        } else {
            GL11.glDisable(property);
        }
    }

    @Override
    public void setClip(int x, int y, int width, int height) {
        setOpenglProperty( GL11.GL_SCISSOR_TEST, true );
        GL11.glScissor(x, y, width, height);
    }

    @Override
    public void setClip( Shape shape ) {
        setOpenglProperty( GL11.GL_SCISSOR_TEST, (shape != null ? true : false) );
        if( shape != null ) {

        }
    }

    @Override
    public void setTextureStage(int TextureStage, Image image) {
        GL13.glActiveTexture( GL13.GL_TEXTURE0 + TextureStage );
        GL11.glBindTexture( GL11.GL_TEXTURE_2D, (image != null) ? image.getTextureID() : 0 );
    }
}
