/*
 * @(#)SoundInput.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.soundmanager;

import abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager.soundFormat;
import java.nio.ByteBuffer;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public interface SoundInput {

    public ByteBuffer getSoundData();

    public soundFormat getSoundFormat();

    public int getSoundSamples();

    public void dispose();
}
