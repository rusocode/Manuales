/*
 * @(#)ControlManager.java	1.0 Feb 2, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.m2gui;

import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.input.Keyboard;
import abGroup.sgGaming.Engine.Minix2D.input.Keyboard.KeyboardEvent;
import abGroup.sgGaming.Engine.Minix2D.input.Keyboard.enumKeyboardKey;
import abGroup.sgGaming.Engine.Minix2D.input.KeyboardListener;
import abGroup.sgGaming.Engine.Minix2D.input.Mouse.MOUSE_BUTTON_EVENT;
import abGroup.sgGaming.Engine.Minix2D.input.Mouse.MouseButton;
import abGroup.sgGaming.Engine.Minix2D.input.MouseListener;
import abGroup.sgGaming.Engine.Minix2D.m2gui.controls.JButton;
import abGroup.sgGaming.Engine.Minix2D.m2gui.controls.JLabel;
import abGroup.sgGaming.Engine.Minix2D.m2gui.controls.JPicture;
import abGroup.sgGaming.Engine.Minix2D.m2gui.controls.JPopup;
import abGroup.sgGaming.Engine.Minix2D.m2gui.controls.JScreen;
import abGroup.sgGaming.Engine.Minix2D.m2gui.controls.JTextbox;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLException;
import java.util.ArrayList;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 2, 2010
 * @since JDK 1.6
 */
public class ControlManager implements KeyboardListener, MouseListener {
    /**
     * layer elements the root elements of all elements in this screen.
     */
    private ArrayList<Control> pkElementList = new ArrayList<Control>();
    /**
     * element that has the focus.
     */
    private Control pkElementFocus;
    /**
     * hover element.
     */
    private Control pkElementHover;
    /**
     * DragAndDrop element.
     */
    private Control pkElementDragAndDrop;
    /**
     * Lockeable element.
     */
    private Control pkElementLockeable;
    private boolean pkElementLocked;
    /**
     * Last Keys/Mouse
     */
    private int iMouseMotionX, iMouseMotionY;
    private int iMousePositionX, iMousePositionY;
    private boolean bMouseButtonCurrentLeft, bMouseButtonCurrentRight;
    private boolean bMouseButtonLeft, bMouseButtonRight;
    /**
     * Key List
     */
    private ArrayList<Integer> pkKeyNumber = new ArrayList<Integer>();
    private ArrayList<KeyboardEvent> pkKeyType = new ArrayList<KeyboardEvent>();
    private Graphics2D render;
    private Keyboard keyboard;

    /**
     * Constructor
     *
     * @param g
     * @param k
     */
    public ControlManager(Graphics2D g, Keyboard k) {
        render = g;
        keyboard = k;
        pkElementFocus = null;
        pkElementHover = null;
        pkElementDragAndDrop = null;
        iMouseMotionX = iMouseMotionY = 0;
        iMousePositionX = iMousePositionY = 0;
        bMouseButtonLeft = bMouseButtonRight = false;
        bMouseButtonCurrentLeft = bMouseButtonCurrentRight = false;
    }

    // <editor-fold defaultstate="collapsed" desc="XML">
    public void Parse(XMLElement element) throws XMLException {
        // Get the amount of controls.
        int amountControl = element.getChildren().size();
        // Control Property Line
        XMLElement xmlControl;
        String ControlType;
        Control ControlParse = null;
        // Parse each Control
        for (int i = 0; i < amountControl; i++) {
            // Get The Control to parse
            xmlControl = element.getChildren().get(i);
            // Get the name of the control type
            ControlType = xmlControl.getName().toUpperCase();
            // Check the Type of Control
            if (ControlType.equals("JBUTTON") == true) {
                ControlParse = new JButton(xmlControl);
            } else if (ControlType.equals("JPICTURE") == true) {
                ControlParse = new JPicture(xmlControl);
            } else if (ControlType.equals("JLABEL") == true) {
                ControlParse = new JLabel(xmlControl);
            } else if (ControlType.equals("JSCREEN") == true) {
                ControlParse = new JScreen(xmlControl);
            } else if (ControlType.equals("JTEXTBOX") == true) {
                ControlParse = new JTextbox(xmlControl);
            } else if (ControlType.equals("JPOPUP") == true) {
                ControlParse = new JPopup(xmlControl);
            } else {
                ControlParse = null;
            }
            // Add to the System.
            if (ControlParse != null) {
                add(ControlParse);
            }
        }
    }

    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Control Add / Remove / Retrieve / Task">
    /**
     * Add a Control to the layer
     */
    public synchronized void add(Control Control) {
        pkElementList.add(Control);
    }

    /**
     * Remove a Control from the layer
     */
    public synchronized void remove(Control Control) {
        pkElementList.remove(Control);
    }

    /**
     * Remove all the controls.
     */
    public void remove() {
        for (int i = 0; i < pkElementList.size(); i++) {
            remove(pkElementList.get(i));
        }
    }

    /**
     * Get the control with the name.
     *
     * @param ControlName
     * @return
     */
    public Control getControl(String ControlName) {
        // Check on the current list.
        for (int i = 0; i < pkElementList.size(); i++) {
            if (pkElementList.get(i).name.equalsIgnoreCase(ControlName) == true) {
                return pkElementList.get(i);
            }
        }
        return null;
    }

    /**
     * @return The current hover control.
     */
    public Control getControlHover() {
        return pkElementHover;
    }

    /**
     * Make the job of adding and deleting controls
     */
    public void TaskElementList() {
        pkElementLocked = (pkElementLockeable != null ? ((Lockeable)pkElementLockeable).isLocked() : false );
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Control ToFront / Find">
    /**
     * Push control to back, equivalents toFront o zOrder
     * @param Control
     */
    private void controlToFront(Control theControl) {
        pkElementList.remove(theControl);

        int size = pkElementList.size();
        Control[] Comp = new Control[pkElementList.size()];

        pkElementList.toArray(Comp);
        pkElementList.clear();

        for (int I = 0; I < size; I++) {
            pkElementList.add(Comp[I]);
        }
        pkElementList.add(theControl);
    }

    /**
     * Loop though all elements from the last to the first
     * and return what element it's on that position
     * that it's interactive and it's enabled
     *
     * @param PositionX
     * @param PositionY
     * @return
     */
    public Control controlFind(int iX, int iY, boolean eventControl) {
        Control Comp;
        int loopFind = pkElementList.size();

        while (loopFind > 0) {
            Comp = pkElementList.get(loopFind - 1);
            if (Comp.checkIntersect(new Vector2f(iX,iY)) && Comp.enabled && (eventControl == true ? Comp instanceof Eventable : true)
                && (pkElementLocked == true ? Comp instanceof Lockeable : true) ) {
                return Comp;
            }
            loopFind--;
        }
        return null;
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Mouse Task">
    /**
     * @see abGroup.sgGaming.Minix2D.Input.MouseListener
     */
    public boolean mouseMove(int dX, int dY, int rX, int rY) {
        // Do the Mouse task event.
        boolean bReturnVar = TaskElementMouse(dX, dY, rX, rY);
        // set the mouse position property
        iMousePositionX = dX;
        iMousePositionY = dY;
        iMouseMotionX = rX;
        iMouseMotionY = rY;
        // set the Current Buttons
        bMouseButtonLeft = bMouseButtonCurrentLeft;
        bMouseButtonRight = bMouseButtonCurrentRight;
        // Return
        return bReturnVar;
    }

    /**
     * @see abGroup.sgGaming.Minix2D.Input.MouseListener
     */
    public boolean mouseButton(MouseButton button, MOUSE_BUTTON_EVENT event) {
        // set the mouse button property left
        if (button == MouseButton.BUTTON_LEFT && event == MOUSE_BUTTON_EVENT.MOUSE_PRESS) {
            bMouseButtonCurrentLeft = true;
        } // set the mouse button property right
        else if (button == MouseButton.BUTTON_LEFT && event == MOUSE_BUTTON_EVENT.MOUSE_RELEASE) {
            bMouseButtonCurrentLeft = false;
        } // set the mouse button property right
        else if (button == MouseButton.BUTTON_RIGHT && event == MOUSE_BUTTON_EVENT.MOUSE_PRESS) {
            bMouseButtonCurrentRight = true;
        } // set the mouse button property right
        else if (button == MouseButton.BUTTON_RIGHT && event == MOUSE_BUTTON_EVENT.MOUSE_RELEASE) {
            bMouseButtonCurrentRight = false;
        }
        // if there is a control in the position, then we doesnt continue
        // parsing the mouse button event.
        return TaskElementMouseClick(bMouseButtonCurrentLeft, bMouseButtonCurrentRight);
    }

    /**
     * @see abGroup.sgGaming.Minix2D.Input.MouseListener
     */
    public boolean mouseWheel(int WheelNumber) {
        if (pkElementFocus == null || pkElementFocus instanceof Mouseable == false) {
            return false;
        }
        // Call the mouse wheel implementation
        ((Mouseable) pkElementFocus).mouseWheel(WheelNumber);
        return true;
    }

    /**
     * Make the task mouse click.
     *
     * @param bLeftMouse
     * @param bRightMouse
     * @return
     */
    private boolean TaskElementMouseClick(boolean bLeftMouse, boolean bRightMouse) {
        boolean retValue = true;
        // process all function that it's related
        // to the element hover, Click, MouseOver, Focus
        if (pkElementHover != null) {
            // Check if the last mouse hitted was a left, and this is a left
            // and a control was drag it on, then continue draggin on
            if (bLeftMouse == true) {
                // if we are upong an element, and the mouse click left and it's clickable then
                if (pkElementHover instanceof Mouseable && bMouseButtonLeft == false ) {
                    // Push this control to from
                    controlToFront(pkElementHover);
                    // Call the effect Function
                    ((Mouseable) pkElementHover).mouseButton(MouseButton.BUTTON_LEFT);
                    // Check if the element it's focusable and it's not the already focuseabled
                    if ((pkElementFocus != pkElementHover)) {
                        // The element Focus lost the focus
                        if (pkElementFocus != null) {
                            ((Focuseable) pkElementFocus).focus(false);
                        }

                        // if the element it's focuseable then
                        if (pkElementHover instanceof Focuseable) {
                            // The hover element gain the focus
                            if (((Focuseable) pkElementHover).focus(true) == true) // if the Hover Element Accept the focus, then set it
                            {
                                pkElementFocus = pkElementHover;
                            }
                        }
                    }
                } // if the element support drag and drop
                // and the last button was true, then means
                // that the user wants to move the Element
                // to another location
                Control spotControl = controlFind(iMousePositionX, iMousePositionY, true);
                if (spotControl instanceof Dragable && bMouseButtonLeft == false && pkElementDragAndDrop == null) {
                    // Push this control to from
                    controlToFront(spotControl);
                    // set the current to dragAndDrop
                    pkElementDragAndDrop = spotControl;
                }
            } // if there was no click but there is an hover then
            // check if there was an draganddrop then finish
            // dragging
            else if (pkElementDragAndDrop != null) {
                pkElementDragAndDrop = null;
            }
        } // Calculate Click on the fly, that's mean
        // that if there was one, then the object focused
        // lost his focus, and also dragAndDrop stop
        else {
            retValue = false;
            // If there was an click and there was an focusedElement
            // then lost the focus
            if (bLeftMouse == true && pkElementFocus != null) {
                ((Focuseable) pkElementFocus).focus(false);
                pkElementFocus = null;
            }
            // if there was no click and the DragAndDrop continue
            // then finished
            if (bLeftMouse == false && pkElementDragAndDrop != null) {
                pkElementDragAndDrop = null;
            }
        }
        return retValue;
    }

    /**
     * Do the Task of the Mouse.
     *
     * @param bLeftMouse
     * @param bRightMouse
     * @param iX
     * @param iY
     * @param iRelativeX
     * @param iRelativeY
     */
    private boolean TaskElementMouse(int iX, int iY, int iRelativeX, int iRelativeY) {
        // Return variable
        boolean bReturnVar = true;
        // process all function that it's related
        // to find the current hover, onMouseEnter and onMouseExit
        Control spotControl = controlFind(iX, iY, true);
        // if there was an control on that coordiantes then check some
        // mosue related function like onMouseEnter
        if (spotControl != null) {
            // if it's not the elementHover that it was before then
            if (spotControl != pkElementHover) {
                // if the spotControl accept MouseRegion then
                // call onRegionIn
                if (spotControl instanceof Regionable) {
                    // Run the MouseRegion
                    ((Regionable) spotControl).Enter();
                }
                // if there was an elementHover, then out of region!
                if (pkElementHover != null) {
                    //if the elementHover have the effect Mouse Region
                    //then call onRegionOut
                    if (pkElementHover instanceof Regionable) // Run the MouseRegion
                    {
                        ((Regionable) pkElementHover).Exit();
                    }
                }
                // set the new Control Hover
                pkElementHover = spotControl;
            }
        } // if there was an element and now nothing
        else {
            // was an element hover before?
            if (pkElementHover != null) {
                //if the elementHover have the effect Mouse Region
                //then call onRegionOut
                if (pkElementHover instanceof Regionable) // Run the MouseRegion
                {
                    ((Regionable) pkElementHover).Exit();
                }
                // set the Element Hover to null
                // there`s nothing more to do
                pkElementHover = null;
            }
            // the function doesn't do anything
            bReturnVar = false;
        }
        // process all function that it's related
        // to the element hover, Click, MouseOver, Focus
        if (pkElementHover != null) {
            // if the mouse it's moved, upon the hover element
            // then it's mousemovement
            if (((iMouseMotionX != iRelativeX) || (iMouseMotionY != iRelativeY)) &&
                    pkElementHover instanceof Mouseable) {
                // Call The Effect Function
                ((Mouseable) pkElementHover).mouseMove(iX - pkElementHover.x, iY - pkElementHover.y, iRelativeX, iRelativeY);
            }
        }
        // Drag and Drop
        if( pkElementDragAndDrop != null && ((iMouseMotionX != iRelativeX) || (iMouseMotionY != iRelativeY)) ) {
            // Call The Effect Function
            ((Dragable) pkElementDragAndDrop).dragEvent(iRelativeX, iRelativeY);
        }
        // Return
        return bReturnVar;
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Render Task">
    /**
     * This job does the actually render of
     * all elementes in this gui system,
     * it render from the first to the last
     */
    public void TaskElementRender() {
        Control Element;
        int loopFind = pkElementList.size();
        // Loop thought each element
        // and if it's rendeable then
        // render it
        while (loopFind > 0) {
            // Get the current element
            Element = pkElementList.get(pkElementList.size() - loopFind);
            // check if it's renderable
            // and if it does, then call the
            // renderEffect
            if (Element instanceof Drawable && Element.enabled) {
                ((Drawable) Element).Drawable(render, 0, 0);
            }
            // get another element
            loopFind--;
        }
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Keyboard Task">
    /**
     * @see abGroup.sgGaming.Minix2D.Input.KeyboardListener
     */
    public boolean keyDown(enumKeyboardKey key) {
        // not continue if we dont have to do anything.
        if (pkElementFocus == null || pkElementFocus instanceof Keyable == false || (pkElementLockeable != pkElementFocus && pkElementLocked == true)) {
            return true;
        }
        // Call the function
        ((Keyable) pkElementFocus).keyDown(key, keyboard );
        // not continue parsing
        return false;
    }

    /**
     * @see abGroup.sgGaming.Minix2D.Input.KeyboardListener
     */
    public boolean keyRelease(enumKeyboardKey key) {
        // not continue if we dont have to do anything.
        if (pkElementFocus == null || pkElementFocus instanceof Keyable == false || (pkElementLockeable != pkElementFocus && pkElementLocked == true)) {
            return true;
        }
        // Call the function
        ((Keyable) pkElementFocus).keyRelease(key, keyboard);
        // not continue parsing
        return false;
    }

    /**
     * @see abGroup.sgGaming.Minix2D.Input.KeyboardListener
     */
    public boolean keyPress(enumKeyboardKey key) {
        // not continue if we dont have to do anything.
        if (pkElementFocus == null || pkElementFocus instanceof Keyable == false || (pkElementLockeable != pkElementFocus && pkElementLocked == true)) {
            return true;
        }
        // Call the function
        ((Keyable) pkElementFocus).keyPress(key, keyboard);
        // not continue parsing
        return false;
    }
    // </editor-fold>

    /**
     * Create a Lockeable
     *
     * @param c
     */
    public void SetLock(Control f) {
        if (f instanceof Lockeable) {
            // Set the Current Element
            pkElementLockeable = f;
            // Add to the Control List.
            add(f);
            // Set the Locked Function
            pkElementLocked = Boolean.TRUE;
        }
    }
}
