//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.Client.Engine.Entitys;

import abGroup.sgGaming.Games.Nylox.Client.Engine.Entity;
import abGroup.sgGaming.Games.Nylox.Client.Engine.Manager.Sprite;
import abGroup.sgGaming.Games.Nylox.Client.Engine.Manager.Sprite.SpriteAnimationType;
import abGroup.sgGaming.Games.Nylox.Client.Engine.Manager.SpriteDataClass;
import abGroup.sgGaming.Games.Nylox.Client.Engine.Manager.SpriteManager;
import abGroup.sgGaming.Minix2D.Renderer.Render2D;

/**
 * Define an character entity.
 *
 * @author Agustin L. Alvarez
 */
public class EntityCharacter extends Entity {

    /** Entity Direction Types **/
    protected final static int ENTITY_MAX_DIRECTION = 4;

    /** Entity Head Sprite List **/
    protected Sprite[] pkHeadSprite;
    /** Entity Body Sprite List **/
    protected Sprite[] pkBodySprite;
    protected int[]    pkBodyOffset;
    /** Entity Movement **/
    protected boolean  pkMovement;

    /**
     * Constructor
     *
     * @param name
     * @param x
     * @param y
     */
    public EntityCharacter( String name, int x, int y ) {
        // Constructor of <br>Entity</br>
        super( name, 2, x,  y);
        // This entity is animated
        this.setAnimated(true);
        // Create the Sprite list.
        pkHeadSprite = new Sprite[ENTITY_MAX_DIRECTION];
        pkBodySprite = new Sprite[ENTITY_MAX_DIRECTION];
    }

    /**
     * Set the character head.
     *
     * @param index Number of the head.
     */
    public void setHead(int index) {
        // get the head data.
        int[] headData = SpriteManager.getHead(index);
        // Load each head sprite.
        for (int i = 0; i < ENTITY_MAX_DIRECTION; i++) {
            // Create the sprite.
            pkHeadSprite[i] = new Sprite(headData[i], SpriteAnimationType.Loop);
        }
        // Set default Sprite Entity.
        this.setSprite(0, pkHeadSprite[0]  );
    }

    /**
     * Set the character body.
     *
     * @param index Number of the body
     */
    public void setBody(int index) {
        // get the head data.
        int[] bodyData = SpriteManager.getBody(index);
        // Base Body it's always the second -1 frame.
        int baseBody = bodyData[1] - 1;
        SpriteDataClass baseBodySprite = SpriteManager.pkSprite.pkSprite[baseBody];
        // Load each head sprite.
        for (int i = 0; i < ENTITY_MAX_DIRECTION; i++) {
            // Create the sprite.
            pkBodySprite[i] = new Sprite(baseBody, SpriteAnimationType.Loop);
            pkBodySprite[i].endAnimation();
            // Animation Start and End Frame.
            pkBodySprite[i].setFrameStart( (baseBodySprite.pkSprite.length / ENTITY_MAX_DIRECTION) * i );
            pkBodySprite[i].setFrameLimit( (baseBodySprite.pkSprite.length / ENTITY_MAX_DIRECTION) );
        }
        // Load the offsets
        pkBodyOffset = new int[2];
        pkBodyOffset[0] = bodyData[ENTITY_MAX_DIRECTION];
        pkBodyOffset[1] = bodyData[ENTITY_MAX_DIRECTION + 1];
        // Set default Sprite Entity.
        this.setSprite(1, pkBodySprite[0] );
        this.setSpritePosition(0, pkBodyOffset[0], pkBodyOffset[1] );
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.Entity#moveEntity(int, int)
     */
    @Override
    public boolean moveEntity( int x, int y ) {
        // Does the entity move it self?
        if( super.moveEntity(x, y) == false ) {
            return false;
        }
        pkMovement = true;
        // Check what type of sprite direction made.
        int id = pkHeading.ordinal();
        Sprite[] spriteList = new Sprite[] { pkHeadSprite[id], pkBodySprite[id] };
        // Start the animation of each part.
        pkBodySprite[id].startAnimation();
        // Set the new sprite direction.
        this.setSprite(spriteList);
        return true;
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.Entity#Render(abGroup.sgGaming.Minix2D.Renderer.Render2D, int, int)
     */
    @Override
    public void Render(Render2D g, int startTileX, int startTileY) {
        // Made the entity render.
        super.Render(g,startTileX,startTileY);
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.Entity#Logical(float)
     */
    @Override
    public void Logical(float timeDelta) {
        // Made the entity logical.
        super.Logical(timeDelta);
        // Stop the animation of all the character entity.
        if( canMove() == true && pkMovement == true ) {
            this.getSprite(1).endAnimation();
            pkMovement = false;
        }
    }
}
