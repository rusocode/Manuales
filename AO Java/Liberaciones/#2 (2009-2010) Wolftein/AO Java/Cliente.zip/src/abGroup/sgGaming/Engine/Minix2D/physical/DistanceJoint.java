/*
 * @(#)DistanceJoint.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical;

import abGroup.sgGaming.Engine.Minix2D.math.Matrix2f;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;

/**
 * A joint that constrains the distance that two bodies can be from each other
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class DistanceJoint implements Joint {

    /** The cached impulse through the calculation to yield correct impulse faster */
    protected float accumulatedImpulse;
    /** Anchor point for first body, on which impulse is going to apply*/
    protected Vector2f anchor1;
    /** Anchor point for second body, on which impulse is going to apply*/
    protected Vector2f anchor2;
    /** The caculated bias */
    protected float bias;
    /** The first body in this joint */
    protected Body body1;
    /** The second bodu in this joint */
    protected Body body2;
    /** The distance between the bodies */
    private float distant;
    /** Distance Vector*/
    protected Vector2f dp;
    /** The matrix for applying impulse */
    protected Matrix2f M;
    /** The rotation of the first body */
    protected Vector2f r1;
    /** The rotation of the second body */
    protected Vector2f r2;
    /** The scalar */
    protected float sc;

    /**
     * @param body1	The first body to be attached on constraint
     * @param body2 The second body to be attached on constraint
     * @param anchor1 The anchor point on first body
     * @param anchor2 The anchor point on second body
     * @param distant The fixed distance that is going to keep between two bodies
     */
    public DistanceJoint(Body body1, Body body2, Vector2f anchor1,
            Vector2f anchor2, float distant) {
        this.body1 = body1;
        this.body2 = body2;
        this.anchor1 = anchor1;
        this.anchor2 = anchor2;
        this.distant = distant * distant;
    }

    /**
     * @see net.phys2d.raw.Joint#applyImpulse()
     */
    public void applyImpulse() {
        Vector2f dv = new Vector2f(body2.getVelocity());
        dv.Add(Vector2f.cross(body2.getAngularVelocity(), r2));
        dv.Sub(body1.getVelocity());
        dv.Sub(Vector2f.cross(body1.getAngularVelocity(), r1));

        float ju = -dv.Dot(dp) + bias;
        float p = ju / sc;

        Vector2f impulse = new Vector2f(dp);
        impulse.Scale(p);

        if (!body1.isStatic()) {
            Vector2f accum1 = new Vector2f(impulse);
            accum1.Scale(-body1.getInvMass());
            body1.adjustVelocity(accum1);
            body1.adjustAngularVelocity(-(body1.getInvI() * Vector2f.cross(r1,
                    impulse)));
        }

        if (!body2.isStatic()) {
            Vector2f accum2 = new Vector2f(impulse);
            accum2.Scale(body2.getInvMass());
            body2.adjustVelocity(accum2);
            body2.adjustAngularVelocity(body2.getInvI() * Vector2f.cross(r2, impulse));
        }

        accumulatedImpulse += p;
    }

    /**
     * Get the anchor of the joint on the first body
     *
     * @return The anchor of the joint on the first body
     */
    public Vector2f getAnchor1() {
        return anchor1;
    }

    /**
     * Get the anchor of the joint on the second body
     *
     * @return The anchor of the joint on the second body
     */
    public Vector2f getAnchor2() {
        return anchor2;
    }

    /**
     * @see net.phys2d.raw.Joint#getBody1()
     */
    public Body getBody1() {
        return body1;
    }

    /**
     * @see net.phys2d.raw.Joint#getBody2()
     */
    public Body getBody2() {
        return body2;
    }

    /**
     * @see net.phys2d.raw.Joint#preStep(float)
     */
    public void preStep(float invDT) {
        Matrix2f rot1 = new Matrix2f(body1.getRotation());
        Matrix2f rot2 = new Matrix2f(body2.getRotation());
        r1 = Vector2f.mul(rot1, anchor1);
        r2 = Vector2f.mul(rot2, anchor2);

        Matrix2f K1 = new Matrix2f();
        K1.col1.x = body1.getInvMass() + body2.getInvMass();
        K1.col2.x = 0.0f;
        K1.col1.y = 0.0f;
        K1.col2.y = body1.getInvMass() + body2.getInvMass();

        Matrix2f K2 = new Matrix2f();
        K2.col1.x = body1.getInvI() * r1.y * r1.y;
        K2.col2.x = -body1.getInvI() * r1.x * r1.y;
        K2.col1.y = -body1.getInvI() * r1.x * r1.y;
        K2.col2.y = body1.getInvI() * r1.x * r1.x;

        Matrix2f K3 = new Matrix2f();
        K3.col1.x = body2.getInvI() * r2.y * r2.y;
        K3.col2.x = -body2.getInvI() * r2.x * r2.y;
        K3.col1.y = -body2.getInvI() * r2.x * r2.y;
        K3.col2.y = body2.getInvI() * r2.x * r2.x;

        Matrix2f K = Matrix2f.add(Matrix2f.add(K1, K2), K3);

        Vector2f p1 = new Vector2f(body1.getPosition());
        p1.Add(r1);
        Vector2f p2 = new Vector2f(body2.getPosition());
        p2.Add(r2);
        dp = new Vector2f(p2);
        dp.Sub(p1);

        float biasFactor = 0.3f;
        bias = biasFactor * (-dp.LengthSquared() + distant);

        dp.Normalise();

        sc = Vector2f.mul(K, dp).Dot(dp);

        Vector2f impulse = new Vector2f(dp);
        impulse.Scale(accumulatedImpulse);

        if (!body1.isStatic()) {
            Vector2f accum1 = new Vector2f(impulse);
            accum1.Scale(-body1.getInvMass());
            body1.adjustVelocity(accum1);
            body1.adjustAngularVelocity(-(body1.getInvI() * Vector2f.cross(r1,
                    impulse)));
        }

        if (!body2.isStatic()) {
            Vector2f accum2 = new Vector2f(impulse);
            accum2.Scale(body2.getInvMass());
            body2.adjustVelocity(accum2);
            body2.adjustAngularVelocity(body2.getInvI() * Vector2f.cross(r2, impulse));
        }
    }

    /**
     * @see net.phys2d.raw.Joint#setRelaxation(float)
     */
    public void setRelaxation(float relaxation) {
    }
}
