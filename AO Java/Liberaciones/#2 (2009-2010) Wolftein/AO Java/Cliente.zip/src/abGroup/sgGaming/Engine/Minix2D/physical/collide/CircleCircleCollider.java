/*
 * @(#)CircleCircleCollider.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical.collide;

import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.physical.Body;
import abGroup.sgGaming.Engine.Minix2D.physical.Contact;
import abGroup.sgGaming.Engine.Minix2D.physical.Shapes.Circle;

/**
 * A collider for circle 2 circle collisions
 * 
 * The create() method is used as a factory just in case this 
 * class becomes stateful eventually.
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public strictfp class CircleCircleCollider implements Collider {

    /**
     * @see net.phys2d.raw.collide.Collider#collide(net.phys2d.raw.Contact[], net.phys2d.raw.Body, net.phys2d.raw.Body)
     */
    public int collide(Contact[] contacts, Body bodyA, Body bodyB) {
        float x1 = bodyA.getPosition().GetX();
        float y1 = bodyA.getPosition().GetY();
        float x2 = bodyB.getPosition().GetX();
        float y2 = bodyB.getPosition().GetY();

        boolean touches = bodyA.getShape().getBounds().touches(x1, y1, bodyB.getShape().getBounds(), x2, y2);
        if (!touches) {
            return 0;
        }

        Circle circleA = (Circle) bodyA.getShape();
        Circle circleB = (Circle) bodyB.getShape();

        touches = circleA.touches(x1, y1, circleB, x2, y2);
        if (!touches) {
            return 0;
        }

        Vector2f normal = Vector2f.sub(bodyB.getPosition(), bodyA.getPosition());
        float sep = (circleA.getRadius() + circleB.getRadius()) - normal.length();

        normal.Normalise();
        Vector2f pt = Vector2f.scale(normal, circleA.getRadius());
        pt.Add(bodyA.getPosition());

        contacts[0].setSeparation(-sep);
        contacts[0].setPosition(pt);
        contacts[0].setNormal(normal);

        FeaturePair fp = new FeaturePair();
        contacts[0].setFeature(fp);

        return 1;
    }
}
