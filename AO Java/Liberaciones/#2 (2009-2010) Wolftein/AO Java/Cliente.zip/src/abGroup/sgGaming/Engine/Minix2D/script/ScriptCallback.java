/*
 * @(#)ScriptCallback.java	1.0 May 26, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.script;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,May 26, 2010
 * @since
 */
public interface ScriptCallback {

    public Object eval(String line);

    public String getHeader();

    public boolean isPresent();

    public boolean isRegisterType();

    public String getRegisterName();

    public String getRegisterPack();

    public String getRegisterSource();

    public String getName();

}
