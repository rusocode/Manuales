/*
 * @(#)implMouse.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl;

import abGroup.sgGaming.Engine.Minix2D.input.Mouse;
import org.lwjgl.LWJGLException;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class implMouse extends Mouse {

    /**
     * Constructor
     *
     * @param Height
     */
    public implMouse(int Height) {
        super(Height);
        Create();
        SetCursorVisible(true);
    }

    /**
     * @see abGroup.sgGaming.Minix2D.Input.Mouse
     */
    public void SetCursorVisible(boolean Value) {
        // Set the mouse Grab motion
        org.lwjgl.input.Mouse.setGrabbed(!Value);
        try {
            // if itÂ´s visible then set the default cursor
            if (Value) {
                org.lwjgl.input.Mouse.setNativeCursor(implMouseCursor.cursor);
            } else {
                org.lwjgl.input.Mouse.setNativeCursor(null);
            }
        } catch (Exception ex) {
           throw new RuntimeException("LWJGLMouse#SetCursorVisible Exception");
        }
    }

    /**
     * @see abGroup.sgGaming.Minix2D.Input.Mouse
     */
    public boolean isCursorVisible() {
        return org.lwjgl.input.Mouse.getNativeCursor() != null;
    }

    /**
     * @see abGroup.sgGaming.Minix2D.Input.Mouse
     */
    protected void implEvent() {
        Create( );
        // check if the mouse is grabbed
        boolean grabbed = org.lwjgl.input.Mouse.isGrabbed();
        // Poll the mouse
        org.lwjgl.input.Mouse.poll();
        // Make the action
        if (grabbed == true) {
            mouseRelativeX = org.lwjgl.input.Mouse.getDX();
            mouseRelativeY = org.lwjgl.input.Mouse.getDY();
            mouseX = org.lwjgl.input.Mouse.getX();
            mouseY = -org.lwjgl.input.Mouse.getY() + iWindowHeight;
        } // Not Grabbed
        else {
            mouseX = org.lwjgl.input.Mouse.getX();
            mouseY = -org.lwjgl.input.Mouse.getY() + iWindowHeight;
            mouseRelativeX = mouseX - lastMouseX;
            mouseRelativeY = mouseY - lastMouseY;
            lastMouseX = mouseX;
            lastMouseY = mouseY;
        }
        // Calculate the Mouse Wheel if it has
        mouseWheel = org.lwjgl.input.Mouse.getDWheel();
        mouseWheelRotation += mouseWheel;
        // Calculate the Mouse Buttons
        while (org.lwjgl.input.Mouse.next()) {
            // get the button pressed
            int buttonPressed = org.lwjgl.input.Mouse.getEventButton();
            // does itÃ‚Â´s pressed?
            boolean pressButton = buttonPressed >= 0 && org.lwjgl.input.Mouse.getEventButtonState();
            // set the state
            if (buttonPressed >= 0) {
                setButtonState(buttonPressed, pressButton);
            }
            // Wheel
            int wheelDelta = org.lwjgl.input.Mouse.getEventDWheel();
            // Movement
            int xDelta = org.lwjgl.input.Mouse.getEventDX();
            int yDelta = org.lwjgl.input.Mouse.getEventDY();
            // Fire the IRQ Mouse
            if (buttonPressed >= 0) {
                raiseEventButton(buttonPressed);
            }
            if (wheelDelta != 0) {
                raiseEventWheel(wheelDelta);
            }
            if (xDelta != 0 || yDelta != 0) {
                raiseEventMovement();
            }
        }
    }

    /**
     * Create the Detail
     */
    private void Create( ) {
        try {
            if( org.lwjgl.input.Mouse.isCreated() == false ) {
                org.lwjgl.input.Mouse.create();
            }
        } catch (LWJGLException ex) {
            throw new RuntimeException("LWJGLMouse#Create Exception");
        }
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        org.lwjgl.input.Mouse.destroy();
    }

}
