//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.Client.Engine;

import abGroup.sgGaming.Games.Nylox.Client.Engine.Manager.Sprite;
import abGroup.sgGaming.Minix2D.Renderer.Render2D;
import abGroup.sgGaming.Minix2D.Util.Color;

/**
 * Define the type of the entity/object that has an world foundation.
 *
 * @author Agustin L. Alvarez
 */
public abstract class Entity {

    /** Max Speed Movement **/
    protected final static float ENTITY_SPEED_MOVEMENT_MAX = 1024.0f;
    protected final static float ENTITY_SPEED_MOVEMENT_DEFAULT = 520.0f;

    /** Scrolling px (2,25f per frame at 60 frame ) **/
    protected final static float ENTITY_SCROLL_PER_FRAME = 1.25f;

    /** Entity Heading **/
    public static enum enumEntityHeading {
        // Normal four direction of a 2D game.
        SOUTH,
        NORTH,
        WEST,
        EAST,
        // None Heading
        NONE,
        // Normal four+ direction of isometric game.
        NORTH_WEST,
        NORTH_EAST,
        SOUTH_WEST,
        SOUTH_EAST
    };

    /** Name of the entity **/
    protected String pkName;

    /** Entity Speed Variable **/
    protected float pkSpeedMovement = ENTITY_SPEED_MOVEMENT_DEFAULT;

    /** This are the sprite that make the entity renderable **/
    protected Sprite[] pkEntityRender;
    protected int[][]  pkEntityRenderPosition;

    /** Entity TILE position **/
    protected int pkTilePositionX, pkTilePositionY;
    protected enumEntityHeading pkHeading;

    /** Entity Property **/
    protected boolean pkCenter, pkAnimated;
    protected float   pkTimePassed;
    protected float   pkScale = 1.0f, pkRotation = 0.0f;
    protected Color   pkColor;

    /** Entity visibility **/
    protected boolean pkVisible;

    /** Entity scrolling **/
    protected float   pkScrollX, pkScrollY;
    protected boolean pkScrollDirectionTopX, pkScrollDirectionTopY;

    /**
     * Constructor.
     *
     * @param name The name of the entity.
     * @param size The amount of sprite that has the entity.
     */
    public Entity( String name, int size ) {
        pkName = name;
        pkEntityRender = new Sprite[size];
        pkEntityRenderPosition = new int[size][2];
    }

    /**
     * Constructor
     *
     * @param name The name of the entity.
     * @param size The amount of sprite that has the entity.
     * @param x the started position x of the entity tile.
     * @param y the started position y of the entity tile.
     */
    public Entity( String name, int size, int x, int y ) {
        this(name,size);
        pkTilePositionX = x;
        pkTilePositionY = y;
    }

    /**
     * Construct the sprite list of the entity.
     *
     * @param spriteList List of sprite for renderer.
     */
    public void setSprite( Sprite[] spriteList ) {
        pkEntityRender = spriteList;
    }

    /**
     * Set a sprite in the sprite list of the entity.
     *
     * @param index The index of the sprite.
     * @param sprite The sprite data for the entity.
     */
    public void setSprite( int index, Sprite sprite ) {
        pkEntityRender[index] = sprite;
    }

    /**
     * Set a sprite part of the entity position.
     *
     * @param index The index of the sprite.
     * @param x The position x of the sprite.
     * @param y The position y of the sprite.
     */
    public void setSpritePosition( int index, int x, int y ) {
        pkEntityRenderPosition[index][0] = x;
        pkEntityRenderPosition[index][1] = y;
    }

    /**
     * Set the property animated of the entity.
     *
     * @param value TRUE or FALSE
     */
    public void setAnimated( boolean value ) {
        pkAnimated = value;
    }

    /**
     * Set the property center of the entity.
     *
     * @param value TRUE or FALSE
     */
    public void setCenter( boolean value ) {
        pkCenter = value;
    }

    /**
     * Set the visibility of the entity.
     *
     * @param value TRUE or FALSE
     */
    public void setVisible( boolean value ) {
        pkVisible = value;
    }

    /**
     * Set the scale of the entity.
     *
     * @param scale
     */
    public void setSize(float scale) {
        pkScale = scale;
        for (int i = 0; i < pkEntityRender.length; i++) {
            pkEntityRender[i].setScale(scale);
        }
    }

    /**
     * Set the rotation of the entity.
     * 
     * @param angle
     */
    public void setRotation( float angle ) {
        pkRotation = angle;
        for (int i = 0; i < pkEntityRender.length; i++) {
            pkEntityRender[i].setRotation(angle);
        }
    }

    /**
     * Set the color of the entity.
     *
     * @param c
     */
    public void setColor( Color c ) {
        pkColor = c;
        for (int i = 0; i < pkEntityRender.length; i++) {
            pkEntityRender[i].setColor(c);
        }
    }

    /**
     * Set the entity movement speed.
     *
     * @param value
     */
    public void setMovementSpeed( float value ) {
        if( value > ENTITY_SPEED_MOVEMENT_MAX ) { value = ENTITY_SPEED_MOVEMENT_MAX; }
        pkSpeedMovement = value;
    }

    /**
     * @return The position x of the character
     */
    public int getPositionX() {
        return pkTilePositionX;
    }

    /**
     * @return The position y of the character
     */
    public int getPositionY() {
        return pkTilePositionY;
    }

    /**
     * Return a sprite renderer of this entity.
     *
     * @param index
     * @return
     */
    public Sprite getSprite( int index ) {
        return pkEntityRender[index];
    }

    /**
     * @return If the character can move.
     */
    public boolean canMove() {
        return pkScrollX == 0 && pkScrollY == 0;
    }

    /**
     * @return The entity scrolling x
     */
    public float getScrollX() {
        return pkScrollX;
    }

    /**
     * @return The entity scrolling y
     */
    public float getScrollY() {
        return pkScrollY;
    }

    /**
     * Move the entity to a tile position.
     *
     * @param x Position x of a tile.
     * @param y Position y of a tile.
     * @return TRUE if we move the entity.
     */
    public boolean moveEntity( int x, int y ) {
        // The entity can be move only if it's not already moving.
        if( canMove() ) {
            findEntityScrollDirection(x,y);
            pkTilePositionX += x;
            pkTilePositionY += y;
            return true;
        }
        return false;
    }

    /**
     * Find the scrolling variables.
     * @param x
     * @param y
     */
    protected void findEntityScrollDirection(int x, int y) {
        pkHeading = enumEntityHeading.NONE;
        // Make the positions diference.
        int dirX = (pkTilePositionX+x) - pkTilePositionX;
        int dirY = (pkTilePositionY+y) - pkTilePositionY;
        // Check for the Direction.
        if( dirY == -1 ) { pkScrollDirectionTopY = true; pkScrollY = 32; pkHeading = enumEntityHeading.NORTH; }
        else if( dirY == 1 ) { pkScrollDirectionTopY = false; pkScrollY = -32; pkHeading = enumEntityHeading.SOUTH; }
        if( dirX == -1 ) { pkScrollDirectionTopX = true; pkScrollX = 32;
            pkHeading = (pkHeading == enumEntityHeading.NONE ? enumEntityHeading.WEST :
                         pkHeading == enumEntityHeading.NORTH ? enumEntityHeading.NORTH_WEST : enumEntityHeading.SOUTH_WEST );
        }
        else if( dirX == 1 ) { pkScrollDirectionTopX = false; pkScrollX = -32;
            pkHeading = (pkHeading == enumEntityHeading.NONE ? enumEntityHeading.EAST :
                         pkHeading == enumEntityHeading.NORTH ? enumEntityHeading.NORTH_EAST : enumEntityHeading.SOUTH_EAST );
        }
    }

    /**
     * @return The entity heading.
     */
    public enumEntityHeading getHeading() {
        return pkHeading;
    }

    /**
     * Entity render function. This function render all the entity sprites.
     *
     * @param g The render callback
     * @param timeDelta Time passed.
     * @param startTileX From where it's start the render.
     * @param startTileY From where it's start the render.
     */
    public void Render(Render2D g, int startTileX, int startTileY) {
        // Render only if it's visible
        if (pkVisible == false) {
            // render all the entity sprites.
            for (int i = 0; i < pkEntityRender.length; i++) {
                pkEntityRender[i].Render(g,
                        (int)((pkTilePositionX - startTileX) * 32 + pkScrollX + pkEntityRenderPosition[i][0] * pkScale),
                        (int)((pkTilePositionY - startTileY) * 32 + pkScrollY + pkEntityRenderPosition[i][1] * pkScale),
                        pkTimePassed,
                        pkAnimated,
                        pkCenter);
            }   
        }
    }

    /**
     * Entity logical function. This function make the entity logical.
     *
     * @param timeDelta
     */
    public void Logical(float timeDelta) {
        pkTimePassed = timeDelta;
        // Make the scrolling entity
        if (pkScrollX != 0) {
            if (pkScrollDirectionTopX == true) {
                pkScrollX -= (pkSpeedMovement * ENTITY_SCROLL_PER_FRAME) / ENTITY_SPEED_MOVEMENT_MAX;
                if (pkScrollX < 0) {
                    pkScrollX = 0;
                }
            } else {
                pkScrollX += (pkSpeedMovement * ENTITY_SCROLL_PER_FRAME) / ENTITY_SPEED_MOVEMENT_MAX;
                if (pkScrollX > 0) {
                    pkScrollX = 0;
                }
            }
        }
        if (pkScrollY != 0) {
            if (pkScrollDirectionTopY == true) {
                pkScrollY -= (pkSpeedMovement * ENTITY_SCROLL_PER_FRAME) / ENTITY_SPEED_MOVEMENT_MAX;
                if (pkScrollY < 0) {
                    pkScrollY = 0;
                }
            } else {
                pkScrollY += (pkSpeedMovement * ENTITY_SCROLL_PER_FRAME) / ENTITY_SPEED_MOVEMENT_MAX;
                if (pkScrollY > 0) {
                    pkScrollY = 0;
                }
            }
        }
    }

}
