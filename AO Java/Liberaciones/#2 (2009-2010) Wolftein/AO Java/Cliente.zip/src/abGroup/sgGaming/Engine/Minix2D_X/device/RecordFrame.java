/*
 * @(#)RecordFrame.java	1.0 Feb 12, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D_X.device;

import abGroup.sgGaming.Engine.Minix2D.util.Camera;
import abGroup.sgGaming.Engine.Minix2D.util.MXSerializable;
import abGroup.sgGaming.Engine.Minix2D.util.SpatialGroup;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.BitSet;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 12, 2010
 * @since
 */
public class RecordFrame implements MXSerializable {

    /** Context **/
    private final static int CAMERA_CHANGE = 0;

    protected Camera camara;
    protected ArrayList<SpatialGroup> spatialGroup;

    protected BitSet changeContex;



    public void save( DataOutputStream out ) throws IOException {

    }

}
