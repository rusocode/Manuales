/*
 * @(#)Evaluator.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.script;

import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug.TypeDebug;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug.TypeDebugChannel;
import java.util.ArrayList;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import org.apache.bsf.BSFManager;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class Evaluator {

    protected static BSFManager manager;
    protected static ScriptEngine engine;
    protected static ArrayList<ScriptCallback> list = new ArrayList<ScriptCallback>();

    /**
     * initialize the evaluator instance statical.
     */
    public static void initialize() {
        // add into the list
        list.add( new ScriptCallbackRuby() );
        // register each type
        for( int i = 0; i < list.size(); i++ ) {
            ScriptCallback sc = list.get(i);
            if( sc.isRegisterType() ) {
                BSFManager.registerScriptingEngine( sc.getRegisterName(), sc.getRegisterSource(), new String[] { sc.getRegisterPack() } );
            }
        }
        // create the Manager
        manager = new BSFManager();
    }

    /**
     * Evaluate the expressions.
     *
     * @param sourceLine
     * @return
     */
    public static Object eval(String sourceLine) {
        for( int i = 0; i < list.size(); i++ ) {
            ScriptCallback sc = list.get(i);

            // Header equal and script available
            if( sourceLine.toUpperCase().startsWith( sc.getHeader() ) && sc.isPresent() ) {
                // Take out the header
                sourceLine = sourceLine.substring( sc.getHeader().length() );
                // Evaluate if there is no evaluator
                if( sc.isRegisterType() )
                    try {
                        return engine.eval( sourceLine );
                    } catch( ScriptException ex ) {
                        return null;
                    }
                else
                    return sc.eval(sourceLine);
            }

        }
        return sourceLine;
    }

    /**
     * Set the file where to load the ruby functions.
     *
     * @param filename
     */
    public static void source(String filename) {
        try {
            for( int i = 0; i < list.size(); i++ ) {
                ScriptCallback sc = list.get(i);
                if( sc.isPresent() ) {
                    engine = new ScriptEngineManager().getEngineByName( sc.getName() );
                    engine.eval(convertFileToString(filename));
                }
            }
        } catch (ScriptException ex) {
            Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                    TypeDebug.ERROR,
                    "Setting the script manager");
        }
    }

    /**
     * Create a variable within the script context.
     *
     * @param varName
     * @param value
     */
    public static void put(String varName, Object value) {
        engine.put(varName, value);
    }

    /**
     * Execute an expression.
     *
     * @param sourceFile
     * @param lineNumber
     * @param columnNumber
     * @param dataEvaluate
     */
    private static String convertFileToString(String Filename) {
        byte[] data = Runtime.getClassLoader().getResource(Filename);
        String str = "";
        for (int i = 0; i < data.length; i++) {
            str += (char) data[i];
        }
        return str;
    }
}
