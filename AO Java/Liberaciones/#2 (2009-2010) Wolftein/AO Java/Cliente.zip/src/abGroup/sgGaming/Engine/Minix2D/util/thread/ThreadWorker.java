/*
 * @(#)ThreadWorker.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.util.thread;

import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug.TypeDebug;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug.TypeDebugChannel;
import java.util.LinkedList;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class ThreadWorker {

    private final int nThreads;
    private final PoolWorker[] threads;
    private final LinkedList queue;

    public ThreadWorker(int nThreads) {
        this.nThreads = nThreads;
        queue = new LinkedList();
        threads = new PoolWorker[nThreads];

        for (int i = 0; i < nThreads; i++) {
            threads[i] = new PoolWorker();
            threads[i].start();
        }
    }

    public void execute(Runnable r) {
        synchronized (queue) {
            queue.addLast(r);
            queue.notify();
        }
    }

    private class PoolWorker extends Thread {

        public void run() {
            Runnable r;

            while (true) {
                synchronized (queue) {
                    while (queue.isEmpty()) {
                        try {
                            queue.wait();
                        } catch (InterruptedException ex) {
                            // Never Cached.
                        }
                    }

                    r = (Runnable) queue.removeFirst();
                }

                // If we don't catch RuntimeException,
                // the pool could leak threads
                try {
                    r.run();
                } catch (RuntimeException e) {
                    Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                            TypeDebug.ERROR,
                            String.format("PoolWorker@%d:%s produce a Exception: %s", this.getId(), this.getName(), e.getMessage()));
                }
            }
        }
    }
}
