/*
 * @(#)SoundInputOgg.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.soundmanager;

import abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager.soundFormat;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class SoundInputOgg implements SoundInput {

    private ByteBuffer data;
    private soundFormat format;
    private int samplerate;

    /**
     * Creates a new WaveData
     *
     * @param data actual wavedata
     * @param format format of wave data
     * @param samplerate sample rate of data
     */
    private SoundInputOgg(ByteBuffer data, soundFormat format, int samplerate) {
        this.data = data;
        this.format = format;
        this.samplerate = samplerate;
    }

    /**
     * Creates a WaveData container from the specified bytes
     *
     * @param buffer array of bytes containing the complete wave file
     * @return WaveData containing data, or null if a failure occured
     */
    public static SoundInputOgg create(byte[] buffer) {
        try {
            return create(new BufferedInputStream(new ByteArrayInputStream(buffer)));
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Creates a WaveData container from the specified ByetBuffer.
     * If the buffer is backed by an array, it will be used directly,
     * else the contents of the buffer will be copied using get(byte[]).
     *
     * @param buffer ByteBuffer containing sound file
     * @return WaveData containing data, or null if a failure occured
     */
    public static SoundInputOgg create(ByteBuffer buffer) {
        try {
            byte[] bytes = null;

            if (buffer.hasArray()) {
                bytes = buffer.array();
            } else {
                bytes = new byte[buffer.capacity()];
                buffer.get(bytes);
            }
            return create(bytes);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Creates a WaveData container from the specified stream
     *
     * @param ais AudioInputStream to read from
     * @return WaveData containing data, or null if a failure occured
     */
    public static SoundInputOgg create(InputStream input) throws IOException {
        ByteArrayOutputStream dataout = new ByteArrayOutputStream();


        OggInputStream oggInput = new OggInputStream(input);

        boolean done = false;
        while (!oggInput.atEnd()) {
            dataout.write(oggInput.read());
        }
        byte[] data = dataout.toByteArray();
        ByteBuffer BufferData = ByteBuffer.allocateDirect(data.length);
        BufferData.put(data);
        BufferData.rewind();

        return new SoundInputOgg(BufferData, soundFormat.STEREO16, oggInput.getRate());
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundInput
     */
    public ByteBuffer getSoundData() {
        return data;
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundInput
     */
    public soundFormat getSoundFormat() {
        return format;
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundInput
     */
    public int getSoundSamples() {
        return samplerate;
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundInput
     */
    public void dispose() {
        data.clear();
    }

}
