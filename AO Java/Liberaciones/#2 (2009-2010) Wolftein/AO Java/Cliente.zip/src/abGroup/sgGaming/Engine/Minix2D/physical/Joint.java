/*
 * @(#)Joint.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical;

/**
 * A joint connecting two bodies
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public interface Joint {

    /**
     * Set the relaxtion value on this joint. This value determines
     * how loose the joint will be
     *
     * @param relaxation The relaxation value
     */
    public abstract void setRelaxation(float relaxation);

    /**
     * Get the first body attached to this joint
     *
     * @return The first body attached to this joint
     */
    public abstract Body getBody1();

    /**
     * Get the second body attached to this joint
     *
     * @return The second body attached to this joint
     */
    public abstract Body getBody2();

    /**
     * Apply the impulse caused by the joint to the bodies attached.
     */
    void applyImpulse();

    /**
     * Precaculate everything and apply initial impulse before the
     * simulation step takes place
     *
     * @param invDT The amount of time the simulation is being stepped by
     */
    void preStep(float invDT);
}
