//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.CSprite;

import abGroup.sgGaming.Minix2D.Util.FileSystem.BinaryStream;
import abGroup.sgGaming.Minix2D.Util.FileSystem.Resource;
import java.util.ArrayList;

/**
 * <class>SpriteSearch</class> Look every sprite within the recursive directory.
 *
 * @author Agustin L. Alvarez
 */
public class SpriteSearch {

    /**
     * List of Files
     */
    private static ArrayList<String> pkList = new ArrayList<String>();

    /**
     * Make the recursive search and find all sprite files.
     *
     * @param Directory
     */
    public static void Search(String Directory) {
        // Get the Binary Stream.
        BinaryStream foo = Resource.GetBinaryStream(Directory);
        // Retrieve all filenames in the root.
        RecursiveSearch(foo, Directory);
    }

    /**
     * Recursive find directory.
     *
     * @param foo
     * @param Directory
     */
    public static void RecursiveSearch(BinaryStream foo, String Directory) {
        // Retrieve all the files.
        String[] baseSearch = foo.GetFileList(Directory);
        // Keep Looking if we have an directory
        for (int i = 0; i < baseSearch.length; i++) {
            if (baseSearch[i].indexOf(".") != -1) {
                // Add the file to the list.
                pkList.add(Directory + "/" + baseSearch[i]);
            } else {
                // Make the recursive again.
                RecursiveSearch(foo, Directory + "/" + baseSearch[i]);
            }
        }
    }

    /**
     * @return The sprite list.
     */
    public static String[] GetSpriteList() {
        String[] spriteList = new String[pkList.size()];
        for (int i = 0; i < spriteList.length; i++) {
            spriteList[i] = pkList.get(i);
        }
        return spriteList;
    }

}
