/*
 * @(#)BaseApplication.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.kernel;

import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.device.Canvas;
import abGroup.sgGaming.Engine.Minix2D.device.DeviceListener;
import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.device.ImageBuffer;
import abGroup.sgGaming.Engine.Minix2D.device.ImageLoader;
import abGroup.sgGaming.Engine.Minix2D.device.RuntimeHelp;
import abGroup.sgGaming.Engine.Minix2D.device.Shader;
import abGroup.sgGaming.Engine.Minix2D.input.Keyboard;
import abGroup.sgGaming.Engine.Minix2D.input.KeyboardListener;
import abGroup.sgGaming.Engine.Minix2D.input.Mouse;
import abGroup.sgGaming.Engine.Minix2D.input.MouseListener;
import abGroup.sgGaming.Engine.Minix2D.m2gui.ControlManager;
import abGroup.sgGaming.Engine.Minix2D.physical.Strategies.QuadSpaceStrategy;
import abGroup.sgGaming.Engine.Minix2D.physical.World;
import abGroup.sgGaming.Engine.Minix2D.script.Evaluator;
import abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundClip;
import abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager;
import abGroup.sgGaming.Engine.Minix2D.util.Camera;
import abGroup.sgGaming.Engine.Minix2D.util.SpatialGroup;
import abGroup.sgGaming.Engine.Minix2D.util.Timer;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug.TypeDebug;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug.TypeDebugChannel;
import abGroup.sgGaming.Engine.Minix2D.util.thread.ThreadContext;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLException;
import java.applet.Applet;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class BaseApplication implements Runnable {

    /** The time that take the engine to make the gc **/
    protected final static int DEFAULT_JAVA_TASK = 60000;
    protected final static int DEFAULT_PHYSICAL_STEP = 10;

    /** Default implementation **/
    protected final static String DEFAULT_TEXTURE = "Default.png";
    protected final static int DEFAULT_SOUND_SIZE = 100;

    public static enum Library {
        LWJGL,
        JAVA
    };

    /** Application base objects **/
    protected Library appLibrary;
    protected Canvas appCanvas;
    protected Graphics2D appGraphics;
    protected SoundManager appSound;
    protected ImageLoader appLoader;
    protected Keyboard appKeyboard;
    protected Mouse appMouse;
    protected ControlManager appControl;
    protected World appPhysical;
    protected Camera appCamera;
    protected ArrayList<SpatialGroup> appRenderSpatial;
    protected ThreadContext appLogicalThread;
    protected RuntimeHelp appHelper;

    /** Application misc **/
    protected Timer appLogicalTimer;
    protected Timer appFpsTimer;
    protected long appFpsTime;
    protected long appFpsCounter;
    protected float appFps;
    protected boolean appPhysicalWorld;

    /** Application property **/
    protected boolean appRunning;
    protected boolean appActive;
    protected long appTime;
    protected boolean appSingleThread = true;

    /** Application listener **/
    protected DeviceListener appDeviceListener;

    /**
     * Constructor of a base application.
     *
     * @param library
     * @param title
     * @param size
     * @param fullscreen
     * @param pixelformat
     */
    public BaseApplication(Library library, Applet app, java.awt.Canvas parent, String title, Vector2f size, boolean fullscreen, boolean pixelformat) {
        Runtime.createRuntime(app);
        createLibraryFactory(library, parent, title, size, fullscreen, pixelformat);
        // Create the gui control manager
        appControl = new ControlManager(appGraphics, appKeyboard);
        setKeyboardListener(appControl);
        setMouseListener(appControl);
        // Create misc objects.
        appRenderSpatial = new ArrayList<SpatialGroup>();
        appLogicalTimer = new Timer();
        appFpsTimer = new Timer();
        appPhysical = new World(new Vector2f(0.0f, 1.0f), DEFAULT_PHYSICAL_STEP, new QuadSpaceStrategy(20, 5));
        appCamera = new Camera();
        appCamera.setCanvas(appCanvas);
        // Runtime objects will use this engine loader.
        Runtime.provideImageLoader(appLoader);
        Runtime.vmKernel = this;
    }

    /**
     * Constructor of a base application.
     *
     * @param library
     * @param title
     * @param size
     * @param fullscreen
     * @param pixelformat
     */
    public BaseApplication(Library library, String title, Vector2f size, boolean fullscreen, boolean pixelformat) {
        this(library, null, null, title, size, fullscreen, pixelformat);
    }

    /**
     * Set the running state of the application.
     *
     * @param value
     */
    public void setRun( boolean value ) {
        appRunning = value;
    }

    /**
     * Set the application device listener.
     * 
     * @param listener
     */
    public void setDeviceListener( DeviceListener listener ) {
        appDeviceListener = listener;
    }

    /**
     * Add a keyboard listener into the engine.
     *
     * @param g
     */
    public void setKeyboardListener( KeyboardListener g ) {
        appKeyboard.AddListener(g);
    }

    /**
     * Add a mouse listener into the engine.
     * 
     * @param g
     */
    public void setMouseListener( MouseListener g ) {
        appMouse.AddListener(g);
    }

    /**
     * Set the application camera.
     *
     * @param c
     */
    public void setCamera( Camera c ) {
        appCamera = c;
        appCamera.setCanvas(appCanvas);
    }

    /**
     * @return The application frames per second.
     */
    public float getApplicationFrames() {
        return appFps;
    }

    /**
     * Set the physical world status.
     *
     * @param value
     */
    public void setPhysicalWorld( boolean value ) {
        appPhysicalWorld = value;
    }

    /**
     * Set the physical gravity.
     *
     * @param grav
     */
    public void setPhysicalGravity( Vector2f grav ) {
        appPhysical.setGravity(grav.x, grav.y);
    }

    /**
     * @return The physical world attached to this engine.
     */
    public World getPhysicalWorld() {
        return appPhysical;
    }

    /**
     * @return The application class loader for image io.
     */
    public ImageLoader getClassImageLoader() {
        return appLoader;
    }

    /**
     * @return The application graphics2D class.
     */
    public Graphics2D getGraphics() {
        return appGraphics;
    }

    public RuntimeHelp getHelper() {
        return appHelper;
    }

    /**
     * Create an application sound clip
     * 
     * @param filename
     * @return
     */
    public SoundClip getSoundClip( String filename ) {
        return new SoundClip( appSound, filename );
    }

    /**
     * @return The control manager of the engine
     */
    public ControlManager getControlManager() {
        return appControl;
    }

    /**
     * Add a spatial into the list.
     *
     * @param t
     */
    public synchronized void addSpatialGroup( SpatialGroup t ) {
        appRenderSpatial.add(t);
    }

    /**
     * Remove a spatial from the list.
     *
     * @param t
     */
    public synchronized void removeSpatialGroup( SpatialGroup t ) {
        appRenderSpatial.remove(t);
    }

    /**
     * Load Control in the control manager
     *
     * @param element
     */
    public void getControl(XMLElement element ) {
        try {
            appControl.Parse(element);
        } catch (XMLException ex) {
            Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                    TypeDebug.ERROR,
                    "Couldn't load the control from the xmlelement");
        }
    }

    /**
     * Create the buffer implementation.
     *
     * @param width
     * @param height
     * @param vx
     * @param vy
     * @return
     */
    public ImageBuffer createBuffer(int width, int height, int vx, int vy) {
        if (appLibrary == Library.LWJGL) {
            return (ImageBuffer) new abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl.implImageBuffer(appLoader.createImage(width, height),
                    vy, vy);
        }
        throw new RuntimeException("This library doesn't support buffers");
    }

    /**
     * Create the shader implementation.
     *
     * @param name
     * @param vertex
     * @param fragment
     * @return
     */
    public Shader createShader(String name, String vertex, String fragment) {
        if (appLibrary == Library.LWJGL) {
            try {
                return (Shader) new abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl.implShader(name, vertex, fragment);
            } catch (IOException ex) {
                Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                        TypeDebug.ERROR,
                        "Couldn't load the shader files");
            }
        }
        throw new RuntimeException("This library doesn't support shaders");
    }

    /**
     * @see java.lang.Runnable#run()
     */
    public void run() {
        // callback of initializing the device.
        appDeviceListener.Initialize(appCanvas);
        // Create logical Thread
        if( !appSingleThread ) { // Only for multicpu
            appLogicalThread = new ThreadContext("MinixLogical", LogicalThreadRunnable);
            appLogicalThread.start();
        }
        appSingleThread = true;
        // While the application is running.
        while (appRunning) {
            // Made the rendering pass.
            appActive = renderLoopCallback();
            // Made the image loader pass.
            appLoader.checkLoaderObservers();
            // Run if it's single thread.
            if( appSingleThread ) {
                LogicalThreadRunnable.run();
            }
            // Calculate the engine fps
            calculateFPS();
        }
        // Destroy
        destroyLibraryFactor();
    }

    private boolean renderLoopCallback( ) {
        // check for close request.
        if( appCanvas.closeRequest() ) {
            appRunning = !appDeviceListener.closeRequest();
        }
        // check for screen rendering.
        if( appCanvas.isVisible() ) {
            // render the canvas.
            appCanvas.clearBuffer();
            // Render camera
            appCamera.applyRender(appGraphics);
            // Render Spatial list with camera.
            Iterator<SpatialGroup> it = appRenderSpatial.iterator();
            while( it.hasNext() ) {
                // Don't render spatial that are outside the screen camera.
                // Todo:!
                SpatialGroup t = it.next();
                // Render the spatial group.
                t.render(appGraphics,appCamera);
            }
            // End rendering the camera.
            appCamera.applyPostRender(appGraphics);
            // Render the user callback
            appDeviceListener.Render(appGraphics);
            // Render the gui
            appControl.TaskElementRender();
            // End rendering
            appCanvas.updateScreen();
        } else {
            appCanvas.processMessage();
            return false;
        }
        return appCanvas.isActive();
    }

    /**
     * Logical Thread Runnable.
     */
    private final Runnable LogicalThreadRunnable = new Runnable() {
        public void run() {
            long loopTimer;
            // While the application is running.
            do {
               loopTimer = Timer.getMillisecondTime();
                // Calculate the elapsed time.
                // and call the logical callback.
                appDeviceListener.Logical(appLogicalTimer.getElapsedTime());
                // make the physical steps.
                if (appPhysicalWorld) {
                    appPhysical.step();
                }
                // make the input handle.
                if (appActive) {
                    appMouse.irqEvent();
                    appKeyboard.irqEvent();
                } else /** Reset the input because we are outside the window **/
                {
                    appMouse.Reset();
                    appKeyboard.Reset();
                }
                // Make the gui events.
                appControl.TaskElementList();
                // Make some Java cleanup.
                appTime += (Timer.getMillisecondTime() - loopTimer);
                if (appTime >= DEFAULT_JAVA_TASK) {
                    appTime = 0;
                    java.lang.Runtime.getRuntime().gc();
                }
            } while( appRunning && !appSingleThread );
        }
    };

    /**
     * Calculate the frames per second.
     */
    private void calculateFPS() {
        appFpsTime += appFpsTimer.getElapsedTime();
        appFpsCounter++;
        if( appFpsTime >= Timer.TIMER_RESOLUTION ) {
            appFps = (appFpsCounter); // calculate the .????
            appFpsTime = appFpsCounter = 0;
        }
    }

    /**
     * Create the library, with a factory of libraries.
     *
     * @param library
     * @param title
     * @param size
     * @param fullscreen
     * @param pixelformat
     */
    private void createLibraryFactory( Library library, java.awt.Canvas parent, String title, Vector2f size, boolean fullscreen, boolean pixelformat ) {
        appLibrary = library;
        // create static methods
        Evaluator.initialize();
        switch( library ) {
            case LWJGL: // LWJGL implementation(Opengl)... www.lwjgl.org
                appCanvas = new abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl.implCanvas(parent, title, size, fullscreen, false, pixelformat);
                appGraphics = new abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl.directGraphics2D();
                appSound = new abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl.implSoundManager(DEFAULT_SOUND_SIZE);
                appLoader = new abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl.implImageLoader(DEFAULT_TEXTURE);
                appKeyboard = new abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl.implKeyboard();
                appMouse = new abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl.implMouse( (int) appCanvas.getSize().y);
                appHelper = new abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl.implRuntime();
                break;
        }
    }

    private void destroyLibraryFactor() {
        appCanvas = null;
        appGraphics = null;
        appSound = null;
        appLoader = null;
        appKeyboard = null;
        appMouse = null;
        appHelper = null;
        java.lang.Runtime.getRuntime().gc();
        Runtime.vmKernel = null;
    }

}
