/*
 * @(#)JArray.java	1.0 Feb 2, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.m2gui.controls;

import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Control;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 2, 2010
 * @since JDK 1.6
 */
public class JArray extends Control {

    /** List of controls **/
    private ArrayList<Control> list;

    /**
     * Constructor
     *
     * @param c
     */
    public JArray(Control[] c) {
        super("JArray");
        add(c);
    }

    /**
     * Constructor
     *
     * @param ex
     * @throws XMLException
     */
    public JArray(XMLElement element) throws XMLException {
        super("JArray");
        parse(element);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Control#parse(abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement)
     */
    @Override
    public void parse(XMLElement element) throws XMLException {
        // Control parse native.
        super.parse(element);
        // JPicture propertys.
        String[] xmlProperty = element.getAttributeNames();
        String currentProperty;
        for (int i = 0; i < xmlProperty.length; i++) {
            currentProperty = xmlProperty[i].toUpperCase();
            if (currentProperty.equals("CHILD")) {
                StringTokenizer f = new StringTokenizer(element.getAttribute("Child"), ",");
                Control[] c = new Control[f.countTokens()];
                for (int j = 0; j < f.countTokens(); j++) {
                    c[j] = (JPopup) Runtime.getKernel().getControlManager().getControl(f.nextToken());
                }
                add(c);
            }
        }
    }

    /**
     * Add a control into the array.
     *
     * @param c
     */
    public void add(Control c) {
        list.add(c);
    }

    /**
     * Add an array of control into the array.
     *
     * @param c
     */
    public void add(Control[] c) {
        for (int i = 0; i < c.length; i++) {
            add(c[i]);
        }
    }

    /**
     * Remove a control from the list.
     *
     * @param c
     */
    public void remove(Control c) {
        list.remove(c);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Control
     */
    @Override
    public void setEnable(boolean value) {
        super.setEnable(value);
        Iterator<Control> it = list.iterator();
        while (it.hasNext()) {
            it.next().setEnable(value);
        }
    }
}
