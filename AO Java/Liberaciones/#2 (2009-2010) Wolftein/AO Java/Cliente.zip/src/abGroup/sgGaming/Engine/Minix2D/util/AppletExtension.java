/*
 * @(#)AppletExtension.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package abGroup.sgGaming.Engine.Minix2D.util;

import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import abGroup.sgGaming.Engine.Minix2D.device.DeviceListener;
import abGroup.sgGaming.Engine.Minix2D.device.Image;
import abGroup.sgGaming.Engine.Minix2D.kernel.BaseApplication;
import abGroup.sgGaming.Engine.Minix2D.kernel.BaseApplication.Library;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Color;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public strictfp abstract class AppletExtension extends Applet implements Runnable {

    protected BaseApplication pkEngine;
    protected Canvas pkParent;
    protected Thread pkThread;
    protected boolean pkAppletApplication = false;

    public AppletExtension() {
        start();
    }

	/**
	 * @see java.applet.EntryApplet#start()
	 */
    @Override
	public void start() {
		pkThread = new Thread( this );
        pkThread.setPriority(Thread.NORM_PRIORITY);
        pkThread.setName("appletThread");
		pkThread.start();
	}


	/**
	 * @see java.applet.EntryApplet#stop()
	 */
    @Override
	public void stop() {
        pkEngine.setRun(false);
	}

	/**
	 * @see java.applet.EntryApplet#init()
	 */
    @Override
	public void init() {
        pkAppletApplication = true;
        Vector2f vectorSize = getAppletSize();
        this.setForeground( Color.BLACK );
        this.setVisible( true );
        this.setLayout( new BorderLayout( ) );
        pkParent = new Canvas( ) {
            @Override
            public final void removeNotify( ) {
                super.removeNotify();
            }
        };
        pkParent.setSize( (int)vectorSize.x, (int)vectorSize.y );
        this.add( pkParent );
        pkParent.setFocusable( true );
        pkParent.requestFocus( );
        pkParent.setIgnoreRepaint( true );
        pkParent.setVisible( true );
	}

	/**
	 * @see java.applet.EntryApplet#run()
	 */
    public void run() {
        createEngineObject();
    }

    protected Image getImage(String name) {
        return Runtime.getImageLoader().getImage(name);
    }

    private void createEngineObject() {
        if (pkAppletApplication == true) {
            pkEngine = new BaseApplication(Library.LWJGL,
                    this,
                    pkParent,
                    getAppletName(),
                    getAppletSize(),
                    getAppletFullscreen(),
                    getAppletQuality());
        } else {
            pkEngine = new BaseApplication(Library.LWJGL,
                    getAppletName(),
                    getAppletSize(),
                    getAppletFullscreen(),
                    getAppletQuality());
        }
        pkEngine.setDeviceListener(getAppletListener());
        pkEngine.setRun(true);
        pkEngine.run();
    }

    protected abstract DeviceListener getAppletListener();
    protected abstract boolean getAppletQuality();
    protected abstract boolean getAppletFullscreen();
    protected abstract String getAppletName();
    protected abstract Vector2f getAppletSize();
}
