/*
 * @(#)ArbiterList.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical;

import java.util.ArrayList;

/**
 * A typed list of <code>Arbiter</code>
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class ArbiterList {
    /** The elements in the list */
    private ArrayList elements = new ArrayList();

    /**
     * Create an empty list
     */
    ArbiterList() {
    }

    /**
     * Add an arbiter to the list
     *
     * @param arbiter The arbiter to add
     */
    void add(Arbiter arbiter) {
        elements.add(arbiter);
    }

    /**
     * Get the size of the list
     *
     * @return The number of elements in the list
     */
    public int size() {
        return elements.size();
    }

    /**
     * Return the index of a particular arbiter in the list
     *
     * @param arbiter The arbiter to search for
     * @return The index of -1 if not found
     */
    public int indexOf(Arbiter arbiter) {
        return elements.indexOf(arbiter);
    }

    /**
     * Remove an abiter from the list
     *
     * @param arbiter The arbiter ot remove from the list
     */
    void remove(Arbiter arbiter) {
        if (!elements.contains(arbiter)) {
            return;
        }
        elements.set(elements.indexOf(arbiter), elements.get(elements.size() - 1));
        elements.remove(elements.size() - 1);
    }

    /**
     * Get an arbiter at a specified index
     *
     * @param i The index of arbiter to retrieve
     * @return The arbiter at the specified index
     */
    public Arbiter get(int i) {
        return (Arbiter) elements.get(i);
    }

    /**
     * Remove all the elements from the list
     */
    public void clear() {
        elements.clear();
    }

    /**
     * Check if an arbiter is contained within a list
     *
     * @param arb The arbiter to check for
     * @return True if the arbiter is in the list
     */
    public boolean contains(Arbiter arb) {
        return elements.contains(arb);
    }
}
