/*
 * @(#)TCPServer.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.network.Transport;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class TCPServer implements TransportServer {

    /** The socket channel on which we're accepting connections */
    private ServerSocketChannel serverChannel;
    /** A selector to wait on this server and any channels it recieves */
    private Selector selector;
    /** The next id to give out */
    private short nextID = 1;

    /**
     * Create a new server binding on all interfaces with the given port
     *
     * @param port The port on which to bind
     * @throws IOException Indicates a failure to bind to the port or
     * configure the resulting socket
     */
    public TCPServer(int port) throws IOException {
        selector = Selector.open();

        serverChannel = ServerSocketChannel.open();
        serverChannel.socket().bind(new InetSocketAddress("0.0.0.0", port));
        serverChannel.configureBlocking(false);

        serverChannel.register(selector, SelectionKey.OP_ACCEPT);
    }

    public TransportChannel accept() throws IOException {
        SocketChannel channel = serverChannel.accept();
        if (channel != null) {
            channel.configureBlocking(false);
            channel.register(selector, SelectionKey.OP_READ);

            TCPChannel tcp = new TCPChannel(channel, nextID);
            nextID++;
            return tcp;
        }

        return null;
    }

    public void close() throws IOException {
        serverChannel.close();
    }

    public void waitForActivity() throws IOException {
        selector.selectedKeys().clear();

        int keys = selector.select();
    }

    public boolean waitForActivity(int timeout) throws IOException {
        selector.selectedKeys().clear();

        return selector.select(timeout) != 0;
    }
}