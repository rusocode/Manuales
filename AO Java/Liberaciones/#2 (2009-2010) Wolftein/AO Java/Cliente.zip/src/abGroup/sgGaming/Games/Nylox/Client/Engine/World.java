//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.Client.Engine;

import abGroup.sgGaming.Games.Nylox.Client.Engine.Manager.Sprite;
import abGroup.sgGaming.Games.Nylox.Client.Engine.Manager.Sprite.SpriteAnimationType;
import abGroup.sgGaming.Minix2D.Foundation.Singleton;
import abGroup.sgGaming.Minix2D.Networking.Message.Message;
import abGroup.sgGaming.Minix2D.Renderer.Buffer;
import abGroup.sgGaming.Minix2D.Renderer.Render2D;
import abGroup.sgGaming.Minix2D.Util.FileSystem.Resource;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Define a world map of the game foundation
 *
 * @author Agustin L. Alvarez
 */
public class World {

    /** Renderer Constant **/
    protected final static int RENDER_OFFSCREEN_TILE = 15; // 10x10 offscreen renderer.

    /** Constant that indicate the cell flag at the load time **/
    protected final static int FLAG_LOAD_VALID = 2^0,
                               FLAG_LOAD_BLOCK = 2^1;

    /** This represent a world tile **/
    public class WorldTileClass implements Cloneable {
        public Sprite[]  pkTile = new Sprite[5];
        public Entity    pkCharacter;
        public Entity    pkItem;
        public boolean   pkBlocked;
        public Trigger   pkTrigger;

        @Override
        public Object clone() {
            WorldTileClass f = new WorldTileClass();
            f.pkTile = pkTile;
            f.pkCharacter = pkCharacter;
            f.pkItem = pkItem;
            f.pkBlocked = pkBlocked;
            f.pkTrigger = pkTrigger;
            return f;
        }
    }
    /** This is the map property **/
    protected String pkVersion, pkName, pkMusic;

    /** This is global map of the current game **/
    public WorldTileClass[][] pkWorldTile;
    /** General variables **/
    protected ArrayList<Trigger> pkExecuteTrigger = new ArrayList<Trigger>();
    protected boolean pkShowItemGround;
    /** Mapped character id **/
    protected HashMap<Integer,Character> pkCharacter = new HashMap<Integer,Character>();

    /** Renderer Buffers **/
    protected int pkRenderViewX, pkRenderViewY;
    protected float  pkRenderTime;
    protected Buffer[] pkRenderBuffer;

    /**
     * Load a world map from a source.
     *
     * @param name The name of the map to load.
     * @return TRUE if we load succesfull./
     */
    public boolean loadWorldMap( String name ) throws IOException {
        byte mapFlag = 0;
        // Open the map file.
        DataInputStream in = Resource.Open( name );
        // Load the map property.
        pkVersion = in.readUTF();
        pkName    = in.readUTF();
        pkMusic   = in.readUTF();
        // Load each map tile.
        pkWorldTile = new WorldTileClass[in.readInt()][in.readInt()];
        for( int x = 0; x < pkWorldTile.length; x++ ) {
            for(int y = 0; y < pkWorldTile[x].length; y++ ) {
                // Read the flag that contain information related to the cell
                // this flags make the map contain less information with just
                // only one more byte in each cell.
                mapFlag = in.readByte();
                // Always check if we need to allocate the cell
                if ((mapFlag | FLAG_LOAD_VALID) > 0) {
                    // Allocate the cell in the memory
                    pkWorldTile[x][y] = new WorldTileClass();
                    // Set the blocked function of the cell
                    pkWorldTile[x][y].pkBlocked = ((mapFlag | FLAG_LOAD_BLOCK) > 0);
                    // Check for each tile.
                    pkWorldTile[x][y].pkTile = new Sprite[7];
                    for( int i = 0; i < pkWorldTile[x][y].pkTile.length; i++ ) {
                        // That tile contain TILE information.
                        if( in.readBoolean() == true ) {
                            pkWorldTile[x][y].pkTile[i] = new Sprite( in.readInt(), SpriteAnimationType.Loop );
                        }
                    }
                    // Load the trigger
                    // Todo Trigger load.
                }
            }
        }
        // Create the buffers for the render (only once)
        createWorldBuffer();
        return false;
    }

    /**
     * Create the world buffers.
     */
    protected void createWorldBuffer() {
        if (pkRenderBuffer == null) {
            pkRenderBuffer = new Buffer[4];
            for (int i = 0; i < pkRenderBuffer.length; i++) {
                pkRenderBuffer[i] = Singleton.GetDevice().CreateBuffer(pkRenderViewX * 32 * 2, pkRenderViewY * 32 * 2, pkRenderViewX * 32 * 2, pkRenderViewY * 32 * 2);
            }
        }
    }

    /**
     * Return min or max value of a value.
     * 
     * @param min
     * @param value
     * @param max
     * @return
     */
    protected int getBoundNumber( int min, int value, int max) {
        if (value < min) {
            return min;
        } else if( value > max ) {
            return max;
        }
        return value;
    }

    /**
     * Reset all the world variables.
     */
    public void resetWorld( ) {
        pkWorldTile = null;
        pkCharacter.clear();
    }

    /**
     * Set if we need to render the name of the item in the ground.
     * 
     * @param value
     */
    public void setItemGroundVisible( boolean value ) {
        pkShowItemGround = value;
    }

    /**
     * Set the world view client.

     * @param width
     * @param height
     */
    public void setWorldView( int width, int height ) {
        pkRenderViewX = (width / 32) / 2;
        pkRenderViewY = ((height+1) / 32) / 2;
    }

    /**
     * Execute a trigger of a tile position.
     *
     * @param x
     * @param y
     */
    public void executeTrigger(int x, int y) {
        // execute valid trigger.
        if (pkWorldTile[x][y] != null) {
            // Does the tile contain a trigger?
            if (pkWorldTile[x][y].pkTrigger != null) {
                // Check for not same trigger executing.
                if (pkExecuteTrigger.contains(pkWorldTile[x][y].pkTrigger) == false) {
                    pkExecuteTrigger.add(pkWorldTile[x][y].pkTrigger);
                }
            }
        }
    }

    /**
     * Render the game world map and all of his entity without buffer optimization
     * but supported by all.
     *
     * @param g
     * @param x
     * @param y
     * @param scrollX
     * @param scrollY
     */
    public void Render(Render2D g, int x, int y, float scrollX, float scrollY ) {
        // get the min and max position for render.
        int renderTileMinX = x - pkRenderViewX - RENDER_OFFSCREEN_TILE;
        int renderTileMinY = y - pkRenderViewY - RENDER_OFFSCREEN_TILE;
        int renderTileMaxX = x + pkRenderViewX + RENDER_OFFSCREEN_TILE;
        int renderTileMaxY = y + pkRenderViewY + RENDER_OFFSCREEN_TILE;
        // get the tile bound.
        int renderTileMinBoundX = getBoundNumber(0, renderTileMinX, pkWorldTile.length);
        int renderTileMinBoundY = getBoundNumber(0, renderTileMinY, pkWorldTile[0].length);
        int renderTileMaxBoundX = getBoundNumber(0, renderTileMaxX, pkWorldTile.length);
        int renderTileMaxBoundY = getBoundNumber(0, renderTileMaxY, pkWorldTile[0].length);
        int renderTileStartScreenX = (renderTileMinX >= 0 ? 0 : (-renderTileMinX) * 32 ) - (RENDER_OFFSCREEN_TILE * 32);
        int renderTileStartScreenY = (renderTileMinY >= 0 ? 0 : (-renderTileMinY) * 32 ) - (RENDER_OFFSCREEN_TILE * 32);
        // Start the rendering of the screen.
        for (int j = renderTileMinBoundX; j < renderTileMaxBoundX; j++) {
            // Render(X0..Y0..Yn..X1..Y0..Yn..Xn..Yn)
            for (int k = renderTileMinBoundY; k < renderTileMaxBoundY; k++) {
                // Only render if it's valid
                if (pkWorldTile[j][k] != null) {
                    // Layer[0][Floor]
                    if (pkWorldTile[j][k].pkTile[0] != null) {
                        pkWorldTile[j][k].pkTile[0].Render(g,
                                (int) ((j-renderTileMinBoundX) * 32 + scrollX) + renderTileStartScreenX,
                                (int) ((k-renderTileMinBoundY) * 32 + scrollY) + renderTileStartScreenY,
                                pkRenderTime,
                                true,
                                false);
                    }
                }
            }
        }
        // Layer[1][Doods/items]
        for (int j = renderTileMinBoundX; j < renderTileMaxBoundX; j++) {
            // Render(X0..Y0..Yn..X1..Y0..Yn..Xn..Yn)
            for (int k = renderTileMinBoundY; k < renderTileMaxBoundY; k++) {
                // Only render if it's valid
                if (pkWorldTile[j][k] != null) {
                    if (pkWorldTile[j][k].pkTile[1] != null) {
                        pkWorldTile[j][k].pkTile[1].Render(g,
                                (int) ((j - renderTileMinBoundX) * 32 + scrollX) + renderTileStartScreenX,
                                (int) ((k - renderTileMinBoundY) * 32 + scrollY) + renderTileStartScreenY,
                                pkRenderTime,
                                true,
                                true);
                    }
                    if (pkWorldTile[j][k].pkTile[2] != null) {
                        pkWorldTile[j][k].pkTile[2].Render(g,
                                (int) ((j - renderTileMinBoundX) * 32 + scrollX) + renderTileStartScreenX,
                                (int) ((k - renderTileMinBoundY) * 32 + scrollY) + renderTileStartScreenY,
                                pkRenderTime,
                                true,
                                true);
                    }
                }
            }
        }
        // Layer[2][Character]
        for (int j = renderTileMinBoundX; j < renderTileMaxBoundX; j++) {
            // Render(X0..Y0..Yn..X1..Y0..Yn..Xn..Yn)
            for (int k = renderTileMinBoundY; k < renderTileMaxBoundY; k++) {
                // Only render if it's valid
                if (pkWorldTile[j][k] != null) {
                    if (pkWorldTile[j][k].pkCharacter != null) {
                        pkWorldTile[j][k].pkCharacter.Render(g, renderTileMinBoundX, renderTileMinBoundY);
                    }
                }
            }
        }
        // Layer[3][House/Roof]
        for (int j = renderTileMinBoundX; j < renderTileMaxBoundX; j++) {
            // Render(X0..Y0..Yn..X1..Y0..Yn..Xn..Yn)
            for (int k = renderTileMinBoundY; k < renderTileMaxBoundY; k++) {
                // Only render if it's valid
                if (pkWorldTile[j][k] != null) {
                    if (pkWorldTile[j][k].pkTile[3] != null) {
                        pkWorldTile[j][k].pkTile[3].Render(g,
                                (int) ((j - renderTileMinBoundX) * 32 + scrollX) + renderTileStartScreenX,
                                (int) ((k - renderTileMinBoundY) * 32 + scrollY) + renderTileStartScreenY,
                                pkRenderTime,
                                false,
                                true);
                    }
                    if (pkWorldTile[j][k].pkTile[4] != null) {
                        pkWorldTile[j][k].pkTile[4].Render(g,
                                (int) ((j - renderTileMinBoundX) * 32 + scrollX) + renderTileStartScreenX,
                                (int) ((k - renderTileMinBoundY) * 32 + scrollY) + renderTileStartScreenY,
                                pkRenderTime,
                                false,
                                true);
                    }
                }
            }
        }
    }

    /**
     * Render the game world map and all of his entity without buffer optimization
     * but supported by all.
     *
     * [NOTE]: Z from 100.0f - 97.0f
     *
     * @param g
     * @param x
     * @param y
     * @param scrollX
     * @param scrollY
     */
    public void RenderWithZ(Render2D g, int x, int y, float scrollX, float scrollY) {
        // get the min and max position for render.
        int renderTileMinX = x - pkRenderViewX - RENDER_OFFSCREEN_TILE;
        int renderTileMinY = y - pkRenderViewY - RENDER_OFFSCREEN_TILE;
        int renderTileMaxX = x + pkRenderViewX + RENDER_OFFSCREEN_TILE;
        int renderTileMaxY = y + pkRenderViewY + RENDER_OFFSCREEN_TILE;
        // get the tile bound.
        int renderTileMinBoundX = getBoundNumber(0, renderTileMinX, pkWorldTile.length);
        int renderTileMinBoundY = getBoundNumber(0, renderTileMinY, pkWorldTile[0].length);
        int renderTileMaxBoundX = getBoundNumber(0, renderTileMaxX, pkWorldTile.length);
        int renderTileMaxBoundY = getBoundNumber(0, renderTileMaxY, pkWorldTile[0].length);
        int renderTileStartScreenX = (renderTileMinX >= 0 ? 0 : (-renderTileMinX) * 32) - (RENDER_OFFSCREEN_TILE * 32);
        int renderTileStartScreenY = (renderTileMinY >= 0 ? 0 : (-renderTileMinY) * 32) - (RENDER_OFFSCREEN_TILE * 32);
        // Start the rendering of the screen.
        for (int j = renderTileMinBoundX; j < renderTileMaxBoundX; j++) {
            // Render(X0..Y0..Yn..X1..Y0..Yn..Xn..Yn)
            for (int k = renderTileMinBoundY; k < renderTileMaxBoundY; k++) {
                // Only render if it's valid
                if (pkWorldTile[j][k] != null) {
                    // Layer[0][Floor]
                    if (pkWorldTile[j][k].pkTile[0] != null) {
                        g.setFarLocation(100.0f);
                        pkWorldTile[j][k].pkTile[0].Render(g,
                                (int) ((j - renderTileMinBoundX) * 32 + scrollX) + renderTileStartScreenX,
                                (int) ((k - renderTileMinBoundY) * 32 + scrollY) + renderTileStartScreenY,
                                pkRenderTime,
                                true,
                                false);
                    }
                    // Layer[1][Doods/items]
                    g.setFarLocation(99.0f);
                    if (pkWorldTile[j][k].pkTile[1] != null) {
                        pkWorldTile[j][k].pkTile[1].Render(g,
                                (int) ((j - renderTileMinBoundX) * 32 + scrollX) + renderTileStartScreenX,
                                (int) ((k - renderTileMinBoundY) * 32 + scrollY) + renderTileStartScreenY,
                                pkRenderTime,
                                true,
                                true);
                    }
                    if (pkWorldTile[j][k].pkTile[2] != null) {
                        pkWorldTile[j][k].pkTile[2].Render(g,
                                (int) ((j - renderTileMinBoundX) * 32 + scrollX) + renderTileStartScreenX,
                                (int) ((k - renderTileMinBoundY) * 32 + scrollY) + renderTileStartScreenY,
                                pkRenderTime,
                                true,
                                true);
                    }
                    // Layer[2][Character]
                    if (pkWorldTile[j][k].pkCharacter != null) {
                        g.setFarLocation(98.0f);
                        pkWorldTile[j][k].pkCharacter.Render(g, renderTileMinBoundX, renderTileMinBoundY);
                    }
                    // Layer[3][House/Roof]
                    g.setFarLocation(97.0f);
                    if (pkWorldTile[j][k].pkTile[3] != null) {
                        pkWorldTile[j][k].pkTile[3].Render(g,
                                (int) ((j - renderTileMinBoundX) * 32 + scrollX) + renderTileStartScreenX,
                                (int) ((k - renderTileMinBoundY) * 32 + scrollY) + renderTileStartScreenY,
                                pkRenderTime,
                                false,
                                true);
                    }
                    if (pkWorldTile[j][k].pkTile[4] != null) {
                        pkWorldTile[j][k].pkTile[4].Render(g,
                                (int) ((j - renderTileMinBoundX) * 32 + scrollX) + renderTileStartScreenX,
                                (int) ((k - renderTileMinBoundY) * 32 + scrollY) + renderTileStartScreenY,
                                pkRenderTime,
                                false,
                                true);
                    }
                }
            }
        }
    }

    /**
     * Do the logical of the game world map and all of his entity.
     *
     * @param timeDelta
     */
    public void Logical(float timeDelta) {
        pkRenderTime = timeDelta;
        // execute all the trigger.
        for (int i = 0; i < pkExecuteTrigger.size(); i++) {
            pkExecuteTrigger.get(i).Logical();
            // End the trigger.
            if (pkExecuteTrigger.get(i).isFinish() == true) {
                pkExecuteTrigger.remove(i);
            }
        }
    }

    /**
     * Do the message network parsing of the game world.
     *
     * @param msg
     */
    public void MessageNetwork( Message msg ) {

    }
}
