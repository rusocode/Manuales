//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.Client.Foundation.Space;

import abGroup.sgGaming.Minix2D.Networking.Message.Message;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * This message indicate the login of the character in the world.
 *
 * @author Agustin L. Alvarez
 */
public class vpEnterCharacterMessage implements Message {

    /** Variables of the character sended **/
    public class CharacterLoginClass {
        public String  pkName, pkClanName;
        public int     pkLookBody, pkLookHead;
        public int     pkGold;
        public byte[]  pkStat = new byte[5];
        public int[][] pkStatus = new int[5][3];
        public short   pkPositionX, pkPositionY, pkPositionMap;
    }

    /** Message ID implementation **/
    public final static int ID = 6;

    /** Message variable **/
    protected CharacterLoginClass pkVariable;

    /**
     * <Client> Constructor
     */
    public vpEnterCharacterMessage( ) {
        pkVariable = new CharacterLoginClass( );
    }


    /**
     * @see abGroup.sgGaming.Minix2D.Networking.Message.Message
     */
    public short getID() {
        return ID;
    }
    /**
     * @see abGroup.sgGaming.Minix2D.Networking.Message.Message
     */
    public void encode(DataOutputStream dout) throws IOException {
        dout.writeUTF( pkVariable.pkName );
        dout.writeUTF( pkVariable.pkClanName );
        dout.writeInt( pkVariable.pkLookBody );
        dout.writeInt( pkVariable.pkLookHead );
        dout.writeByte( pkVariable.pkStat[0] );
        dout.writeByte( pkVariable.pkStat[1] );
        dout.writeByte( pkVariable.pkStat[2] );
        dout.writeByte( pkVariable.pkStat[3] );
        dout.writeByte( pkVariable.pkStat[4] );
        for( int i = 0; i < pkVariable.pkStatus.length; i++ ) {
            dout.writeInt( pkVariable.pkStatus[i][0]);
            dout.writeInt( pkVariable.pkStatus[i][1]);
            dout.writeInt( pkVariable.pkStatus[i][2]);
        }
        dout.writeShort( pkVariable.pkPositionX );
        dout.writeShort( pkVariable.pkPositionY );
        dout.writeShort( pkVariable.pkPositionMap );
    }
    /**
     * @see abGroup.sgGaming.Minix2D.Networking.Message.Message
     */
    public void decode(DataInputStream din) throws IOException {
        pkVariable.pkName = din.readUTF();
        pkVariable.pkClanName = din.readUTF();
        pkVariable.pkLookBody = din.readInt();
        pkVariable.pkLookHead = din.readInt();
        pkVariable.pkStat[0]  = din.readByte();
        pkVariable.pkStat[1]  = din.readByte();
        pkVariable.pkStat[2]  = din.readByte();
        pkVariable.pkStat[3]  = din.readByte();
        pkVariable.pkStat[4]  = din.readByte();
        for( int i = 0; i < pkVariable.pkStatus.length; i++ ) {
            pkVariable.pkStatus[i][0] = din.readInt();
            pkVariable.pkStatus[i][1] = din.readInt();
            pkVariable.pkStatus[i][2] = din.readInt();
        }
        pkVariable.pkPositionX = din.readShort();
        pkVariable.pkPositionY = din.readShort();
        pkVariable.pkPositionMap = din.readShort();
    }

    /**
     * @return The data of our character.
     */
    public CharacterLoginClass getCharacterData() {
        return pkVariable;
    }

}
