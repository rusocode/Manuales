/*
 * @(#)vertexGraphics2D.java	1.0 Feb 7, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl;

import abGroup.sgGaming.Engine.Minix2D.device.Color;
import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.device.Image;
import abGroup.sgGaming.Engine.Minix2D.device.Shape;
import java.nio.FloatBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.ARBImaging;
import org.lwjgl.opengl.ARBMultisample;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 7, 2010
 * @since
 */
public class vertexGraphics2D extends Graphics2D {

    /** Current Color/Vertex/Texture **/
    private FloatBuffer crrColor, crrVertex, crrTexture;

    /**
     * Constructor
     */
    public vertexGraphics2D() {
        GL11.glEnableClientState(GL11.GL_VERTEX_ARRAY);
        GL11.glEnableClientState(GL11.GL_COLOR_ARRAY);
        GL11.glEnableClientState(GL11.GL_TEXTURE_COORD_ARRAY);
        crrColor = BufferUtils.createFloatBuffer(4 * 4);
        crrVertex = BufferUtils.createFloatBuffer(4 * 2);
        crrTexture = BufferUtils.createFloatBuffer(4 * 2);
    }

    /**
     * @see java.lang.Object#finalize()
     */
    @Override
    public void finalize() throws Throwable {
        super.finalize();
        GL11.glDisableClientState(GL11.GL_VERTEX_ARRAY);
        GL11.glDisableClientState(GL11.GL_COLOR_ARRAY);
        GL11.glDisableClientState(GL11.GL_TEXTURE_COORD_ARRAY);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void setHintGraphics(GraphicsHint hint, Object value) {
        Boolean valBoolean;
        Float valFloat;
        switch (hint) {
            case SHADING:
                valBoolean = (Boolean) value;
                GL11.glShadeModel((valBoolean == true ? GL11.GL_SMOOTH : GL11.GL_FLAT));
                break;
            case MULTISAMPLING:
                valBoolean = (Boolean) value;
                setOpenglProperty(ARBMultisample.GL_MULTISAMPLE_ARB, valBoolean);
                setOpenglProperty(GL11.GL_POINT_SMOOTH, valBoolean);
                setOpenglProperty(GL11.GL_LINE_SMOOTH, valBoolean);
                setOpenglProperty(GL11.GL_POLYGON_SMOOTH, valBoolean);

                break;
            case LINE_WIDTH:
                valFloat = (Float) value;
                GL11.glLineWidth(valFloat);
                break;
        }
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void setDepthBuffer(boolean value) {
        depthBuffer = value;
        if (value == true) {
            GL11.glEnable(GL11.GL_DEPTH_TEST);
        } else {
            GL11.glDisable(GL11.GL_DEPTH_TEST);
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void setAlphaBlending(AlphaBlending alphaType) {
        switch (alphaType) {
            case NONE:
                GL11.glDisable(GL11.GL_BLEND);
                break;
            case SOURCE_ALPHA:
                GL11.glEnable(GL11.GL_BLEND);
                GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
                break;
            case DESTINATION_ALPHA:
                GL11.glEnable(GL11.GL_BLEND);
                GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
                break;
            case MULTI_BLEND_ALPHA:
                GL11.glEnable(GL11.GL_BLEND);
                GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_SRC_COLOR);
                break;
            case ADD_BLEND_EQUATION:
                ARBImaging.glBlendEquation(org.lwjgl.opengl.ARBImaging.GL_FUNC_ADD);
                break;
            case SUBSTRACT_BLEND_EQUATION:
                ARBImaging.glBlendEquation(org.lwjgl.opengl.ARBImaging.GL_FUNC_SUBTRACT);
                break;
            case SUBSTRACT_REVERSE_BLEND_EQUATION:
                ARBImaging.glBlendEquation(org.lwjgl.opengl.ARBImaging.GL_FUNC_REVERSE_SUBTRACT);
                break;
        }
        this.alphaBlending = alphaType;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void setColor(Color color) {
        crrColor.put(new float[]{color.colorArray[0], color.colorArray[1], color.colorArray[2], color.colorArray[3],
                    color.colorArray[0], color.colorArray[1], color.colorArray[2], color.colorArray[3],
                    color.colorArray[0], color.colorArray[1], color.colorArray[2], color.colorArray[3],
                    color.colorArray[0], color.colorArray[1], color.colorArray[2], color.colorArray[3]}).flip();
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void drawPoint(int x, int y) {

    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void drawLine(int x, int y, int width, int height) {

    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void drawRect(int x, int y, int width, int height) {

    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void drawOval(int x, int y, int width, int height) {

    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void drawImage(Image image, int x, int y) {
        drawImage( image, x, y, image.getTextureWidth(), image.getTextureHeight(), 0, 0, image.getWidth(), image.getHeight() );
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void drawImage(Image image, int x, int y, float w, float h) {
        drawImage( image, x, y, w, h, 0, 0, image.getWidth(), image.getHeight());
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void drawImage(Image image, int x, int y, float w, float h, float sx, float sy, float sw, float sh) {
        setTextureMode( true );
        // Get the texture property
        int imageWidth = image.getWidth(), imageHeight = image.getHeight();
        // Bind the Texture for rendering.
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, image.getTextureID());
        // Generate Texture Mapping
        float minX = (sx / imageWidth) * 1.0f;
        float minY = (sy / imageHeight) * 1.0f;
        float maxX = (sw - 1.0f) / imageWidth * 1.0f;
        float maxY = (sh - 1.0f) / imageHeight * 1.0f;
        // Vertex Rendering to the opengl driver.
        crrVertex.put( new float[] {x, y, x, y+h, x+w, y, x+w, y+h } ).flip();
        crrTexture.put( new float[] { minX, minY, minX, maxY, maxX, minY, maxX, maxY } ).flip();
        GL11.glVertexPointer(2, 0, crrVertex);
        GL11.glTexCoordPointer(2, 0, crrTexture);
        GL11.glColorPointer(4, 0, crrColor);
        GL11.glDrawArrays(GL11.GL_TRIANGLE_STRIP, 0, 4);
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void drawFont(Image image, int x, int y, float w, float h, float sx, float sy, float sw, float sh) {
        setTextureMode( true );
        // Get the texture property
        int imageWidth = image.getTextureWidth(), imageHeight = image.getTextureHeight();
        // Bind the Texture for rendering.
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, image.getTextureID());
        // Generate Texture Mapping
        float minX = (sx / imageWidth) * 1.0f;
        float minY = (sy / imageHeight) * 1.0f;
        float maxX = (sw - 1.0f) / imageWidth * 1.0f;
        float maxY = (sh - 1.0f) / imageHeight * 1.0f;
        // Vertex Rendering to the opengl driver.
        crrVertex.put( new float[] {x,y,x,h,w,y,w,h } ).flip();
        crrTexture.put( new float[] { minX, maxY, minX, minY, maxX, maxY, maxX, minY } ).flip();
        GL11.glVertexPointer(2, 0, crrVertex);
        GL11.glTexCoordPointer(2, 0, crrTexture);
        GL11.glColorPointer(4, 0, crrColor);
        GL11.glDrawArrays(GL11.GL_TRIANGLE_STRIP, 0, 4);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void scale(double x, double y) {
        GL11.glScaled(x,y, 0.0f);
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void rotate(double theta) {
        GL11.glRotatef((float) theta, 0.0f, 0.0f, 1.0f);
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void rotate(double theta, double x, double y) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void setTransform() {
        GL11.glPopMatrix();
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void getTransform() {
        GL11.glPushMatrix();
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void translate(int x, int y, int z) {
        GL11.glTranslatef(x, y, z);
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Graphics2D
     */
    @Override
    public void translate(double rx, double ry, double rz) {
        GL11.glTranslated(rx, ry, rz);
    }

    @Override
    public void setClip(int x, int y, int width, int height) {
    }

    @Override
    public void setClip( Shape shape ) {
    }

    private void setTextureMode(boolean value) {
        setOpenglProperty(GL11.GL_TEXTURE_2D,value);
    }

    private void setOpenglProperty(int property, boolean value) {
        if (value) {
            GL11.glEnable(property);
        } else {
            GL11.glDisable(property);
        }
    }

    @Override
    public void setTextureStage(int TextureStage, Image image) {
        GL13.glActiveTexture( GL13.GL_TEXTURE0 + TextureStage );
        GL11.glBindTexture( GL11.GL_TEXTURE_2D, (image != null) ? image.getTextureID() : 0 );
    }
}
