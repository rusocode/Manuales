/*
 * @(#)JLabel.java	1.0 Feb 2, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.m2gui.controls;

import abGroup.sgGaming.Engine.Minix2D.device.Color;
import abGroup.sgGaming.Engine.Minix2D.device.Font;
import abGroup.sgGaming.Engine.Minix2D.device.Font.Aligment;
import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Control;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Drawable;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLException;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 2, 2010
 * @since JDK 1.6
 */
public class JLabel extends Control implements Drawable {

    protected String caption = "JLabel";
    protected Font font;
    protected Vector2f size = new Vector2f(1.0f, 1.0f);
    protected Aligment aligment = Aligment.Left;
    protected boolean autoresize = false;
    protected Color color = Color.White;

    /**
     * Constructor
     *
     * @param x
     * @param y
     * @param f
     */
    public JLabel( int x, int y, Font f ) {
        super("JLabel");
        setPosition(new Vector2f(x,y));
        setFont(f);
    }

    /**
     * Constructor
     *
     * @param element
     * @throws XMLException
     */
    public JLabel(XMLElement element) throws XMLException {
        super("JPicture");
        parse(element);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Control#parse(abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement) 
     */
    @Override
    public void parse(XMLElement element) throws XMLException {
        // Control parse native.
        super.parse(element);
        // JPicture propertys.
        String[] xmlProperty = element.getAttributeNames();
        String currentProperty;
        for (int i = 0; i < xmlProperty.length; i++) {
            currentProperty = xmlProperty[i].toUpperCase();
            if (currentProperty.equals("SCALE")) {
                setScale(Vector2f.parseOf(element.getAttribute("Scale")));
            } else if (currentProperty.equals("COLOR")) {
                setColor(Color.parseOf(element.getAttribute("Color")));
            } else if (currentProperty.equals("CAPTION")) {
                setCaption(element.getAttribute("Caption"));
            } else if (currentProperty.equals("ALIGMENT")) {
                setAligment(Aligment.valueOf(element.getAttribute("Aligment")));
            } else if (currentProperty.equals("RESIZE")) {
                setResizable(element.getBooleanAttribute("Resize"));
            } else if (currentProperty.equals("FONT")) {
                setFont(Font.Retrieve(element.getAttribute("Font")));
            }
        }
    }
    
    /**
     * Set the text of the text.
     * 
     * @param scale
     */
    public void setScale( Vector2f scale ) {
        size = scale;
    }
    
    /**
     * Set the aligent of the text.
     * 
     * @param alig
     */
    public void setAligment( Aligment alig ) {
        aligment = alig;
    }
    
    /**
     * Set the caption of the label.
     * 
     * @param caption
     */
    public void setCaption( String caption ) {
        this.caption = caption;
    }
    
    /**
     * Set the autoresizable option.
     * 
     * @param value
     */
    public void setResizable( boolean value ) {
        autoresize = value;
    }
    
    /**
     * Set the color of the label.
     * 
     * @param c
     */
    public void setColor(Color c ) {
        color = c;
    }
    
    /**
     * Set the text font.
     * 
     * @param f
     */
    public void setFont( Font f ) {
        font = f;
    }
    
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Drawable#Drawable(abGroup.sgGaming.Engine.Minix2D.device.Graphics2D, int, int)
     */
    public void Drawable(Graphics2D g, int x, int y) {
        boolean continueRendering = true;
        String text = caption;
        int lineY = 0;
        // Nothing to render if the label is empty
        if (text.length() == 0) {
            return;
        }
        // Set the autoresize property
        if (autoresize == true) {
            this.width = font.getWidth(text, aligment);
            this.height = font.getHeight();
        }
        // Aligment Renderer
        int renderOffsetX = 0, renderOffsetY = 0;
        switch (aligment) {
            case Center:
                renderOffsetX = width / 2;
                renderOffsetY = height / 2 - (int) (font.getHeight() * size.y) / 2;
                break;
        }
        // Set the Color Render of the Control
        g.setColor(color);
        // Render
        while (continueRendering == true) {
            // Get the index
            int index = font.getIndexFromPosition(text, aligment, width);
            // Render
            font.write(x + this.x + renderOffsetX,
                    y + this.y + renderOffsetY + lineY,
                    text.substring(0, index),
                    size.x, size.y, aligment);
            // Stop the rendering
            if (index == text.length()) {
                continueRendering = false;
            } else {
                lineY += font.getHeight();
                text = text.substring(index + 1);
            }
            // Check for height end
            if (lineY >= height) {
                continueRendering = false;
            }
        }
        g.setColor(Color.White);

    }


}
