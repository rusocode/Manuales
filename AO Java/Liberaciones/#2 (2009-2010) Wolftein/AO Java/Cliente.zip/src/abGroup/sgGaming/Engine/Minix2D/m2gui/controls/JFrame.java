/*
 * @(#)JFrame.java	1.0 Feb 2, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.m2gui.controls;

import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.input.Keyboard;
import abGroup.sgGaming.Engine.Minix2D.input.Keyboard.enumKeyboardKey;
import abGroup.sgGaming.Engine.Minix2D.input.Mouse.MouseButton;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Control;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Dragable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Drawable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Eventable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Focuseable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Keyable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Lockeable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Mouseable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Regionable;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 2, 2010
 * @since JDK 1.6
 */
public class JFrame extends Control implements Dragable, Drawable, Eventable, Focuseable, Keyable, Mouseable, Regionable, Lockeable {

    /**
     * Constructor
     *
     * @param x
     * @param y
     */
    public JFrame( int x, int y ) {
        super("JFrame");
        setPosition(new Vector2f(x,y));
    }

    public void dragEvent(int iX, int iY) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void Drawable(Graphics2D g, int x, int y) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean focus(boolean bValue) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void keyDown(enumKeyboardKey key, Keyboard trigger) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void keyRelease(enumKeyboardKey key, Keyboard trigger) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void keyPress(enumKeyboardKey key, Keyboard trigger) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void mouseMove(int dX, int dY, int rX, int rY) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void mouseButton(MouseButton button) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void mouseWheel(int WheelNumber) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void Enter() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void Exit() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean isLocked() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
