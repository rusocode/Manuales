/*
 * @(#)Keyboard.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.input;

import abGroup.sgGaming.Engine.Minix2D.util.Timer;
import java.util.ArrayList;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public abstract class Keyboard {

    /**
     * Default Keyboard Tiping Velocity
     */
    protected static final long KEYBOARD_TIPE_VELOCITY_DEFAULT = 125;
    protected static final long KEYBOARD_REPETYTION_VELOCITY_DEFAULT = 50;

    /**
     * Keyboard event type
     */
    public enum KeyboardEvent {

        KEY_NONE,
        KEY_DOWN,
        KEY_RELEASE,
        KEY_PRESS
    };

    /**
     * Keyboard key that change the
     * event
     */
    public enum KeyboardState {

        KEY_ALT,
        KEY_SHIFT,
        KEY_META,
        KEY_CONTROL
    };

    /**
     * Keyboard Native Keys
     */
    public static enum enumKeyboardKey {

        KEY_NONE(0x00),
        KEY_ESCAPE(0x01),
        KEY_1(0x02),
        KEY_2(0x03),
        KEY_3(0x04),
        KEY_4(0x05),
        KEY_5(0x06),
        KEY_6(0x07),
        KEY_7(0x08),
        KEY_8(0x09),
        KEY_9(0x0A),
        KEY_0(0x0B),
        KEY_MINUS(0x0C),
        KEY_EQUALS(0x0D),
        KEY_BACK(0x0E),
        KEY_TAB(0x0F),
        KEY_Q(0x10),
        KEY_W(0x11),
        KEY_E(0x12),
        KEY_R(0x13),
        KEY_T(0x14),
        KEY_Y(0x15),
        KEY_U(0x16),
        KEY_I(0x17),
        KEY_O(0x18),
        KEY_P(0x19),
        KEY_LBRACKET(0x1A),
        KEY_RBRACKET(0x1B),
        KEY_RETURN(0x1C), /* Enter on main keyboard */
        KEY_LCONTROL(0x1D),
        KEY_A(0x1E),
        KEY_S(0x1F),
        KEY_D(0x20),
        KEY_F(0x21),
        KEY_G(0x22),
        KEY_H(0x23),
        KEY_J(0x24),
        KEY_K(0x25),
        KEY_L(0x26),
        KEY_SEMICOLON(0x27), /* Spanish Keyboard = ÃƒÂ± Ãƒâ€˜ */
        KEY_APOSTROPHE(0x28),
        KEY_GRAVE(0x29), /* accent grave */
        KEY_LSHIFT(0x2A),
        KEY_BACKSLASH(0x2B), /* Spanish Keyboard = < > */
        KEY_Z(0x2C),
        KEY_X(0x2D),
        KEY_C(0x2E),
        KEY_V(0x2F),
        KEY_B(0x30),
        KEY_N(0x31),
        KEY_M(0x32),
        KEY_COMMA(0x33),
        KEY_PERIOD(0x34),
        KEY_SLASH(0x35),
        KEY_RSHIFT(0x36),
        KEY_MULTIPLY(0x37),
        KEY_LMENU(0x38),
        KEY_SPACE(0x39),
        KEY_CAPITAL(0x3A),
        KEY_F1(0x3B),
        KEY_F2(0x3C),
        KEY_F3(0x3D),
        KEY_F4(0x3E),
        KEY_F5(0x3F),
        KEY_F6(0x40),
        KEY_F7(0x41),
        KEY_F8(0x42),
        KEY_F9(0x43),
        KEY_F10(0x44),
        KEY_NUMLOCK(0x45),
        KEY_SCROLL(0x46), /* Scroll Lock */
        KEY_NUMPAD7(0x47),
        KEY_NUMPAD8(0x48),
        KEY_NUMPAD9(0x49),
        KEY_SUBTRACT(0x4A), /* - on numeric keypad */
        KEY_NUMPAD4(0x4B),
        KEY_NUMPAD5(0x4C),
        KEY_NUMPAD6(0x4D),
        KEY_ADD(0x4E), /* + on numeric keypad */
        KEY_NUMPAD1(0x4F),
        KEY_NUMPAD2(0x50),
        KEY_NUMPAD3(0x51),
        KEY_NUMPAD0(0x52),
        KEY_DECIMAL(0x53), /* . on numeric keypad */
        KEY_F11(0x57),
        KEY_F12(0x58),
        KEY_F13(0x64), /* (NEC PC98) */
        KEY_F14(0x65), /* (NEC PC98) */
        KEY_F15(0x66), /* (NEC PC98) */
        KEY_KANA(0x70), /* (Japanese keyboard) */
        KEY_CONVERT(0x79), /* (Japanese keyboard) */
        KEY_NOCONVERT(0x7B), /* (Japanese keyboard) */
        KEY_YEN(0x7D), /* (Japanese keyboard) */
        KEY_NUMPADEQUALS(0x8D), /** = on numeric keypad (NEC PC98) */
        KEY_CIRCUMFLEX(0x90), /* (Japanese keyboard) */
        KEY_AT(0x91), /* (NEC PC98) */
        KEY_COLON(0x92), /* (NEC PC98) */
        KEY_UNDERLINE(0x93), /* (NEC PC98) */
        KEY_KANJI(0x94), /* (Japanese keyboard) */
        KEY_STOP(0x95), /* (NEC PC98) */
        KEY_AX(0x96), /* (Japan AX) */
        KEY_UNLABELED(0x97), /* (J3100) */
        KEY_NUMPADENTER(0x9C), /* Enter on numeric keypad */
        KEY_RCONTROL(0x9D),
        KEY_NUMPADCOMMA(0xB3), /* , on numeric keypad (NEC PC98) */
        KEY_DIVIDE(0xB5), /* / on numeric keypad */
        KEY_SYSRQ(0xB7),
        KEY_RMENU(0xB8), /* right Alt */
        KEY_PAUSE(0xC5), /* Pause */
        KEY_HOME(0xC7), /* Home on arrow keypad */
        KEY_UP(0xC8), /* UpArrow on arrow keypad */
        KEY_PRIOR(0xC9), /* PgUp on arrow keypad */
        KEY_LEFT(0xCB), /* LeftArrow on arrow keypad */
        KEY_RIGHT(0xCD), /* RightArrow on arrow keypad */
        KEY_END(0xCF), /* End on arrow keypad */
        KEY_DOWN(0xD0), /* DownArrow on arrow keypad */
        KEY_NEXT(0xD1), /* PgDn on arrow keypad */
        KEY_INSERT(0xD2), /* Insert on arrow keypad */
        KEY_DELETE(0xD3), /* Delete on arrow keypad */
        KEY_LWIN(0xDB), /* Left Windows key */
        KEY_RWIN(0xDC), /* Right Windows key */
        KEY_APPS(0xDD), /* AppMenu key */
        KEY_POWER(0xDE),
        KEY_SLEEP(0xDF);
        /**
         * Opengl ID
         */
        public final int keyID;

        /**
         * Constructor
         * @param KeyboardID
         */
        enumKeyboardKey(int KeyboardID) {
            keyID = KeyboardID;
        }

        public int GetKeyID() {
            return keyID;
        }

        public static enumKeyboardKey GetKeyFromID(int ID) {
            enumKeyboardKey[] key = enumKeyboardKey.values();

            for (int i = 0; i < key.length; i++) {
                if (key[i].keyID == ID) {
                    return key[i];
                }
            }
            return enumKeyboardKey.KEY_NONE;
        }
    };

    /**
     * Keyboard Locale
     */
    public enum KeyboardLocale {

        ENGLISH,
        SPANISH
    };
    /**
     * List of events to raise
     */
    protected ArrayList<KeyboardListener> eventListener;
    /**
     * List of keys and his states
     */
    protected Map<Integer, KeyboardKey> keyStates;
    /**
     * Set the time to repeat
     */
    protected long keyTimeRepeat;
    /**
     * Implementation Created?
     */
    protected Vector<Integer> implKeyDown;
    /**
     * Capital State
     */
    protected boolean bExtensionCapitalState = false;
    /**
     * Reseted state
     */
    protected boolean bResetted = true;

    /**
     * Constructor
     */
    public Keyboard() {
        // Allocate memory for the event listener array
        eventListener = new ArrayList<KeyboardListener>();
        // Allocate memory and initialize the keyState Map
        keyStates = new ConcurrentHashMap<Integer, KeyboardKey>();
        for (int i = GetSize(); i >= 0; i--) {
            keyStates.put(i, new KeyboardKey(i, 0, KeyboardEvent.KEY_NONE));
        }
        // Set the Timer
        keyTimeRepeat = KEYBOARD_TIPE_VELOCITY_DEFAULT;
        // initialize the array for key Down
        implKeyDown = new Vector<Integer>();
    }

    /**
     * Add an listener
     * @param Action
     * @param Listener
     */
    public void AddListener(KeyboardListener listener) {
        eventListener.add(listener);
    }

    /**
     * Delete an listener
     * @param Action
     * @param Listener
     */
    public void RemoveListener(KeyboardListener listener) {
        eventListener.remove(listener);
    }

    /**
     * Raise from an external
     * resource the event
     *
     * @param eventType
     * @param keyboardKey
     */
    public void raiseEvent(KeyboardEvent eventType, int keyboardKey) {
        Channel(eventType, keyboardKey);
    }

    /**
     * This function call the
     * implementation of the keyboard
     */
    public abstract void irqEvent();

    /**
     * Return TRUE if the state
     * of the key match with the
     * eventType that the user
     * input
     * @param eventType
     * @param keyboardKey
     * @return
     */
    public boolean isKey(KeyboardEvent eventType, int keyboardKey) {
        return (keyStates.get(keyboardKey).keyEventType == eventType);
    }

    /**
     * Return the keyEnumeration of
     * the keyNumber
     * @param keyNumber
     * @return
     */
    public enumKeyboardKey keyMapped(int keyNumber) {
        return enumKeyboardKey.values()[keyNumber];
    }

    /**
     * Return the state Key of the
     * keyboard, usefull to gather information
     * about SHIFT,CONTROL,ALT
     * @param eventType
     * @param stateType
     * @return
     */
    public boolean isEvent(KeyboardEvent eventType, KeyboardState stateType) {
        if (stateType == KeyboardState.KEY_ALT) {
            return (keyStates.get(enumKeyboardKey.KEY_LMENU.ordinal()).keyEventType == eventType) ||
                    (keyStates.get(enumKeyboardKey.KEY_RMENU.ordinal()).keyEventType == eventType);
        } else if (stateType == KeyboardState.KEY_CONTROL) {
            return (keyStates.get(enumKeyboardKey.KEY_LCONTROL.ordinal()).keyEventType == eventType) ||
                    (keyStates.get(enumKeyboardKey.KEY_RCONTROL.ordinal()).keyEventType == eventType);
        } else if (stateType == KeyboardState.KEY_SHIFT) {
            return (keyStates.get(enumKeyboardKey.KEY_LSHIFT.ordinal()).keyEventType == eventType) ||
                    (keyStates.get(enumKeyboardKey.KEY_RSHIFT.ordinal()).keyEventType == eventType);
        } else // Meta not supported yet.
        {
            return bExtensionCapitalState;
        }
    }

    /**
     * This actually call each
     * listener with the parameter
     * @param eventType
     * @param keyboardKey
     */
    protected void keyboardEvent(KeyboardEvent eventType, int keyboardKey) {
        // Result for anulation
        boolean eventResult = true;
        // set the current KeyState
        // of the parse Key
        keyStates.remove(keyboardKey);
        keyStates.put(keyboardKey, new KeyboardKey(keyboardKey, Timer.getMillisecondTime(), eventType));
        // Check Keyboard Predefined Key (Capital Letter)
        if (keyboardKey == enumKeyboardKey.KEY_CAPITAL.ordinal()) {
            bExtensionCapitalState = (eventType == KeyboardEvent.KEY_DOWN || eventType == KeyboardEvent.KEY_PRESS ? true : false);
            return;
        }
        // for each Listener
        // call his function
        for (int i = 0; i < eventListener.size(); i++) {
            // Check what function to call
            // of the listener
            switch (eventType) {
                case KEY_DOWN:
                    eventResult = eventListener.get(i).keyDown(enumKeyboardKey.values()[keyboardKey]);
                    break;
                case KEY_RELEASE:
                    eventResult = eventListener.get(i).keyRelease(enumKeyboardKey.values()[keyboardKey]);
                    break;
                case KEY_PRESS:
                    eventResult = eventListener.get(i).keyPress(enumKeyboardKey.values()[keyboardKey]);
                    break;
            }
            // if the result was FALSE
            // then we stop
            if (eventResult == false) {
                return;
            }
        }
    }

    /**
     * This function itÃ‚Â´s the
     * channel from the implementation
     * and the abstract Keyboard, the
     * data its passed to this function
     * @param eventType
     * @param KeyboardKey
     */
    protected void Channel(KeyboardEvent eventType, int KeyboardKey) {
        // Check if there is an prev Keyboard Event
        KeyboardKey prevKey = keyStates.get(KeyboardKey);
        // Check each Action
        switch (eventType) {
            case KEY_DOWN:
                // Get the Current Time
                long timeEvent = Timer.getMillisecondTime();
                // Keep pressing down
                if (prevKey.keyEventType == KeyboardEvent.KEY_DOWN) {
                    if (timeEvent - prevKey.keyEventTime >= KEYBOARD_REPETYTION_VELOCITY_DEFAULT) {
                        keyboardEvent(KeyboardEvent.KEY_DOWN, KeyboardKey);
                    }
                } // Key Pressed!
                else {
                    // Check if itÃ‚Â´s pass the timeOfRepeat
                    if (timeEvent - prevKey.keyEventTime >= keyTimeRepeat) {
                        if (prevKey.keyEventType == KeyboardEvent.KEY_NONE || prevKey.keyEventType == KeyboardEvent.KEY_RELEASE) {
                            keyStates.put(KeyboardKey, new KeyboardKey(KeyboardKey, Timer.getMillisecondTime(), KeyboardEvent.KEY_PRESS));
                        } else {
                            keyboardEvent(KeyboardEvent.KEY_DOWN, KeyboardKey);
                        }
                    }
                }
                break;
            case KEY_RELEASE:
                // if the key it was down, then itÃ‚Â´s release
                if (prevKey.keyEventType == KeyboardEvent.KEY_DOWN) {
                    keyboardEvent(KeyboardEvent.KEY_RELEASE, KeyboardKey);
                } // else if the key just was pressed, then press it
                else if (prevKey.keyEventType == KeyboardEvent.KEY_PRESS) {
                    keyboardEvent(KeyboardEvent.KEY_PRESS, KeyboardKey);
                }
                // set to none
                keyStates.put(KeyboardKey, new KeyboardKey(KeyboardKey, Timer.getMillisecondTime(), KeyboardEvent.KEY_NONE));
                break;
        }

    }

    /**
     * Translate the key to ascii.
     *
     * @param control
     * @param shift
     * @param alt
     * @param key
     * @return
     */
    static public char TranslateToAscii(boolean control, boolean shift, boolean alt, enumKeyboardKey key) {
        switch (key) {
            case KEY_0:
                return (shift == true) ? ')' : '0';
            case KEY_1:
                return (shift == true) ? '!' : '1';
            case KEY_2:
                if (control) {
                    return (control == true) ? '@' : '2';
                }
                return (shift == true) ? '"' : '2';
            case KEY_3:
                if (control) {
                    return (control == true) ? '#' : '3';
                }
                return (shift == true) ? '#' : '3';
            case KEY_4:
                if (control) {
                    return (control == true) ? '~' : '4';
                }
                return (shift == true) ? '$' : '4';
            case KEY_5:
                return (shift == true) ? '%' : '5'; //NOT YET
            case KEY_6:
                return (shift == true) ? '^' : '6';
            case KEY_7:
                return (shift == true) ? '&' : '7';
            case KEY_8:
                return (shift == true) ? '*' : '8';
            case KEY_9:
                return (shift == true) ? '(' : '9';

            case KEY_A:
                return (shift == true) ? 'A' : 'a';
            case KEY_B:
                return (shift == true) ? 'B' : 'b';
            case KEY_C:
                return (shift == true) ? 'C' : 'c';
            case KEY_D:
                return (shift == true) ? 'D' : 'd';
            case KEY_E:
                return (shift == true) ? 'E' : 'e';
            case KEY_F:
                return (shift == true) ? 'F' : 'f';
            case KEY_G:
                return (shift == true) ? 'G' : 'g';
            case KEY_H:
                return (shift == true) ? 'H' : 'h';
            case KEY_I:
                return (shift == true) ? 'I' : 'i';
            case KEY_J:
                return (shift == true) ? 'J' : 'j';
            case KEY_K:
                return (shift == true) ? 'K' : 'k';
            case KEY_L:
                return (shift == true) ? 'L' : 'l';
            case KEY_M:
                return (shift == true) ? 'M' : 'm';
            case KEY_N:
                return (shift == true) ? 'N' : 'n';
            case KEY_O:
                return (shift == true) ? 'O' : 'o';
            case KEY_P:
                return (shift == true) ? 'P' : 'p';
            case KEY_Q:
                return (shift == true) ? 'Q' : 'q';
            case KEY_R:
                return (shift == true) ? 'R' : 'r';
            case KEY_S:
                return (shift == true) ? 'S' : 's';
            case KEY_T:
                return (shift == true) ? 'T' : 't';
            case KEY_U:
                return (shift == true) ? 'U' : 'u';
            case KEY_V:
                return (shift == true) ? 'V' : 'v';
            case KEY_W:
                return (shift == true) ? 'W' : 'w';
            case KEY_X:
                return (shift == true) ? 'X' : 'x';
            case KEY_Y:
                return (shift == true) ? 'Y' : 'y';
            case KEY_Z:
                return (shift == true) ? 'Z' : 'z';
            case KEY_COLON:
                return ':';
            case KEY_SEMICOLON:
                return ';';
            case KEY_COMMA:
                return ',';
            case KEY_SLASH:
                return '-';
            case KEY_PERIOD:
                return '.';
            case KEY_SPACE:
                return ' ';
        }

        return '?';
    }

    /**
     * Return if the key is a character.
     *
     * @param key
     * @return
     */
    static public boolean IsKeyCharacter(enumKeyboardKey key) {
        return (IsKeyNumber(key) || IsKeyLetter(key) || IsKeySpecialCharacter(key));
    }

    /**
     * Return if the key is a number.
     *
     * @param key
     * @return
     */
    static public boolean IsKeyNumber(enumKeyboardKey key) {
        return (key.keyID >= enumKeyboardKey.KEY_1.keyID && key.keyID <= enumKeyboardKey.KEY_0.keyID);
    }

    /**
     * Return if the key is a letter.
     *
     * @param key
     * @return
     */
    static public boolean IsKeyLetter(enumKeyboardKey key) {
        return ((key.keyID >= 0x10 && key.keyID <= 0x19) ||
                (key.keyID >= 0x1E && key.keyID <= 0x26) ||
                (key.keyID >= 0x2C && key.keyID <= 0x32) ||
                (key.keyID == 0x39));
    }

    /**
     * Return if the key is a special character.
     *
     * @param key
     * @return
     */
    static public boolean IsKeySpecialCharacter(enumKeyboardKey key) {
        return ((key.keyID >= 0x0C && key.keyID <= 0x0E) ||
                (key.keyID >= 0x27 && key.keyID <= 0x29) ||
                (key.keyID >= 0x33 && key.keyID <= 0x35) ||
                (key.keyID == 0x37) || (key.keyID == 0x4A) ||
                (key.keyID == 0x4E));
    }

    /**
     * Set the tiping velocity of the keyboard
     * in MS
     * @param TimeVelocity
     */
    public void changeTipingVelocity(int TimeVelocity) {
        keyTimeRepeat = TimeVelocity;
    }

    /**
     * Return the size of key supported
     * by the implementation
     * @return
     */
    protected int GetSize() {
        return enumKeyboardKey.values().length;
    }

    /**
     * Reset the Keyboard
     */
    public void Reset() {
        if( bResetted == false ) {
            keyStates.clear();
            for (int i = GetSize(); i >= 0; i--) {
                keyStates.put(i, new KeyboardKey(i, 0, KeyboardEvent.KEY_NONE));
            }
            // initialize the array for key Down
            implKeyDown.clear();
            bResetted = true;
        }
    }
}