/*
 * @(#)implCanvas.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl;

import abGroup.sgGaming.Engine.Minix2D.util.filesystem.ClassLoader;
import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.device.Canvas;
import abGroup.sgGaming.Engine.Minix2D.device.Color;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug.TypeDebug;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug.TypeDebugChannel;
import java.applet.Applet;
import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.PixelFormat;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class implCanvas extends Canvas {

    public implCanvas(java.awt.Canvas javaCanvas, String title, Vector2f size, boolean fullscreen, boolean sync, boolean pixelFormat) {
        super.setParent(javaCanvas);
        super.setTitle(title);
        super.setSize(size);
        super.setFullscreen(fullscreen);
        super.setSync(sync);
        super.setPixelFormat(pixelformat);
        java.lang.System.setProperty("org.lwjgl.librarypath", ClassLoader.getLocalPath());
        createCanvas();
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Canvas#setTitle(java.lang.String)
     */
    @Override
    public void setTitle(String value) {
        super.setTitle(value);
        Display.setTitle(value);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Canvas#setSize(abGroup.sgGaming.Engine.Minix2D.Math.Vector2f)
     */
    @Override
    public void setSize(Vector2f value) {
        super.setSize(value);
        try {
            DisplayMode displaySize = findDisplayMode((int) value.x, (int) value.y, 32, this.fullscreen);
            Display.setDisplayMode(displaySize);
        } catch (LWJGLException ex) {
            throw new RuntimeException("implCanvas#findDisplayMode Exception");
        }
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Canvas#setSize(abGroup.sgGaming.Engine.Minix2D.Math.Vector2f)
     */
    @Override
    public void record() {
        
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Canvas#setSync(boolean)
     */
    @Override
    public void setSync(boolean value) {
        super.setSync(value);
        Display.setVSyncEnabled(value);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Canvas#setFullscreen(boolean)
     */
    @Override
    public void setFullscreen(boolean value) {
        super.setFullscreen(value);
        try {
            Display.setFullscreen(value);
        } catch (LWJGLException ex) {
            throw new RuntimeException("implCanvas#setFullscreen exception");
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Canvas#setViewport(float, float, float, float) 
     */
    @Override
    public void setViewport(float x, float y, float width, float height) {
        GL11.glViewport((int) x, (int) y, (int) width, (int) height);
        GL11.glMatrixMode(GL11.GL_PROJECTION); // Select The Projection Matrix
        GL11.glLoadIdentity();                 // Reset The Projection Matrix
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Canvas#setOrtho(float, float, float, float, float, float) 
     */
    @Override
    public void setOrtho(float x, float width, float y, float height, float near, float far) {
        GL11.glOrtho(x, width, y, height, near, far);
        GL11.glMatrixMode(GL11.GL_MODELVIEW); // Select The Modelview Matrix
        GL11.glLoadIdentity();                // Reset The Modelview Matrix
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Canvas#setParent(java.awt.Canvas) 
     */
    @Override
    public void setParent(java.awt.Canvas value) {
        super.setParent(value);
        try {
            Display.setParent(parent);
        } catch (LWJGLException ex) {
            throw new RuntimeException("implCanvas#SetParent Exception");
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Canvas#clearBuffer()
     */
    @Override
    public void clearBuffer() {
        GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
        GL11.glLoadIdentity();
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Canvas#updateScreen()
     */
    @Override
    public void updateScreen() {
        Display.update();
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Canvas#setClearColor(abGroup.sgGaming.Engine.Minix2D.device.Color)
     */
    @Override
    public void setClearColor(Color color) {
        GL11.glClearColor(color.colorArray[0], color.colorArray[1], color.colorArray[2], color.colorArray[3]);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Canvas#closeRequest()
     */
    @Override
    public boolean closeRequest() {
        return Display.isCloseRequested();
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Canvas#isVisible()
     */
    @Override
    public boolean isVisible() {
        return Display.isVisible() || Display.isDirty();
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Canvas#isActive()
     */
    @Override
    public boolean isActive() {
        return Display.isActive();
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Canvas#processMessage()
     */
    @Override
    public void processMessage() {
        Display.processMessages();
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Canvas#getClipboard()
     */
    @Override
    public String getClipboard() {
        return Sys.getClipboard();
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.Canvas#createCanvas()
     */
    @Override
    protected void createCanvas() {
        try {
            // Create the OpenGL context.
            setParent(parent);
            setFullscreen(fullscreen);
            if (parent == null) {
                setSize(size);
                setTitle(title);
            }
            setSync(verticalsync);
            createContext((pixelformat == true) ? new PixelFormat(8, 16, 0, 4) : null);
            setViewport(0, 0, size.x, size.y);
            setOrtho(0, size.x, size.y, 0, -100, 100);
            setClearColor(Color.Black);
            initOpenglProperty();
            Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                    TypeDebug.INFORMATION,
                    "LWJGL Version: " + org.lwjgl.Sys.getVersion() + " - Opengl Version: " + GL11.glGetString(GL11.GL_VERSION));
        } catch (LWJGLException ex) {
            Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                    TypeDebug.ERROR,
                    "Failed to create LWJGL canvas");
        }
    }

    private void initOpenglProperty() {
        // initialize Opengl Property
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glHint(GL11.GL_PERSPECTIVE_CORRECTION_HINT, GL11.GL_NICEST);
        GL11.glAlphaFunc(GL11.GL_GREATER, 0.0f);
        GL11.glEnable(GL11.GL_ALPHA_TEST);
        GL11.glDepthMask(true);
    }

    private void createContext(PixelFormat pformat) throws LWJGLException {
        if (Display.isCreated()) {
            Display.destroy();
        }
        if (pformat == null) {
            Display.create();
        } else {
            Display.create(pformat);
        }
    }

    private DisplayMode findDisplayMode(int Width, int Height, int ColorBit, boolean Fullscreen) throws LWJGLException {
        DisplayMode d[] = Display.getAvailableDisplayModes();
        // Find all the possibles Display Modes.
        for (int i = 0; i < d.length; i++) {
            if (d[i].getWidth() == Width && d[i].getHeight() == Height && d[i].getBitsPerPixel() == ColorBit && (Fullscreen == true ? d[i].isFullscreenCapable() == true : true)) {
                return d[i];
            }
        }
        throw new RuntimeException("implCanvas#findDisplayMode Could't found the display mode");
    }
}
