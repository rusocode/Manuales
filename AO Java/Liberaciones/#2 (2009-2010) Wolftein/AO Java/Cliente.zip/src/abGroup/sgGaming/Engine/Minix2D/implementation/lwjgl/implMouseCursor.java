/*
 * @(#)implMouseCursor.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl;

import java.nio.IntBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.input.Cursor;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class implMouseCursor extends Cursor {

    /**
     * LWJGL Cursor Implementation
     */
    public static Cursor cursor;
    /**
     * Buffer for the cursor image
     */
    private static IntBuffer cursorImage;
    /**
     * Image imageSize itÃ‚Â´s 32x32
     */
    private static int imageSize = 32;

    /**
     * Static Constructors
     */
    static {
        cursorImage = BufferUtils.createIntBuffer(imageSize * imageSize);

        int row = 0;
        cursorImage.put(row * imageSize + 8, 0xFF000000);
        cursorImage.put(row * imageSize + 9, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize + 7, 0xFF000000);
        cursorImage.put(row * imageSize + 8, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 9, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 10, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize + 7, 0xFF000000);
        cursorImage.put(row * imageSize + 8, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 9, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 10, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize + 6, 0xFF000000);
        cursorImage.put(row * imageSize + 7, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 8, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 9, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize, 0xFF000000);
        cursorImage.put(row * imageSize + 6, 0xFF000000);
        cursorImage.put(row * imageSize + 7, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 8, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 9, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize, 0xFF000000);
        cursorImage.put(row * imageSize + 1, 0xFF000000);
        cursorImage.put(row * imageSize + 5, 0xFF000000);
        cursorImage.put(row * imageSize + 6, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 7, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 8, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize, 0xFF000000);
        cursorImage.put(row * imageSize + 1, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 2, 0xFF000000);
        cursorImage.put(row * imageSize + 5, 0xFF000000);
        cursorImage.put(row * imageSize + 6, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 7, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 8, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize, 0xFF000000);
        cursorImage.put(row * imageSize + 1, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 2, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 3, 0xFF000000);
        cursorImage.put(row * imageSize + 4, 0xFF000000);
        cursorImage.put(row * imageSize + 5, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 6, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 7, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize, 0xFF000000);
        cursorImage.put(row * imageSize + 1, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 2, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 3, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 4, 0xFF000000);
        cursorImage.put(row * imageSize + 5, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 6, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 7, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize, 0xFF000000);
        cursorImage.put(row * imageSize + 1, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 2, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 3, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 4, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 5, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 6, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 7, 0xFF000000);
        cursorImage.put(row * imageSize + 8, 0xFF000000);
        cursorImage.put(row * imageSize + 9, 0xFF000000);
        cursorImage.put(row * imageSize + 10, 0xFF000000);
        cursorImage.put(row * imageSize + 11, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize, 0xFF000000);
        cursorImage.put(row * imageSize + 1, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 2, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 3, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 4, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 5, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 6, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 7, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 8, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 9, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 10, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize, 0xFF000000);
        cursorImage.put(row * imageSize + 1, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 2, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 3, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 4, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 5, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 6, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 7, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 8, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 9, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize, 0xFF000000);
        cursorImage.put(row * imageSize + 1, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 2, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 3, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 4, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 5, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 6, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 7, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 8, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize, 0xFF000000);
        cursorImage.put(row * imageSize + 1, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 2, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 3, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 4, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 5, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 6, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 7, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize, 0xFF000000);
        cursorImage.put(row * imageSize + 1, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 2, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 3, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 4, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 5, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 6, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize, 0xFF000000);
        cursorImage.put(row * imageSize + 1, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 2, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 3, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 4, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 5, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize, 0xFF000000);
        cursorImage.put(row * imageSize + 1, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 2, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 3, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 4, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize, 0xFF000000);
        cursorImage.put(row * imageSize + 1, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 2, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 3, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize, 0xFF000000);
        cursorImage.put(row * imageSize + 1, 0xFFFFFFFF);
        cursorImage.put(row * imageSize + 2, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize, 0xFF000000);
        cursorImage.put(row * imageSize + 1, 0xFF000000);

        row++;
        cursorImage.put(row * imageSize, 0xFF000000);

        try {
            cursor = new implMouseCursor();
        } catch (Exception ex) {
            throw new RuntimeException( "MouseCursor#Constructor Exception" );
        }
    }

    /**
     * Default Constructor
     * @throws java.lang.Exception
     */
    private implMouseCursor() throws Exception {
        super(imageSize, imageSize, 0, 19, 1, cursorImage, null);
    }
}