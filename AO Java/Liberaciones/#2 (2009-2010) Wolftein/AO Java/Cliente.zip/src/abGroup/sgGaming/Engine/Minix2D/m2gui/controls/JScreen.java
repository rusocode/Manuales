/*
 * @(#)JScreen.java	1.0 Feb 2, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.m2gui.controls;

import abGroup.sgGaming.Engine.Minix2D.device.Color;
import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.device.ImageBuffer;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Control;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Drawable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Triggered;
import abGroup.sgGaming.Engine.Minix2D.math.FastMath;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLException;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 2, 2010
 * @since JDK 1.6
 */
public class JScreen extends Control implements Drawable {

    private ImageBuffer buffer;
    private Triggered callback;

    /**
     * Constructor
     *
     * @param x
     * @param y
     * @param width
     * @param height
     */
    public JScreen( int x, int y, int width, int height ) {
        super("JScreen");
        setPosition( new Vector2f(x,y));
        setSize(new Vector2f(width,height));
        setBuffer(new Vector2f(width,height));
    }

    /**
     * Constructor
     *
     * @param element
     * @throws XMLException
     */
    public JScreen(XMLElement element) throws XMLException {
        super("JScreen");
        parse( element );
        setBuffer( this.getSize() );
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Control#parse(abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement)
     */
    @Override
    public void parse(XMLElement element) throws XMLException {
        // Control parse native.
        super.parse(element);
    }

    /**
     * Set the screen callback.
     *
     * @param c
     */
    public void setCallback( Triggered c ) {
        callback = c;
    }
    /**
     * Set the screen buffer.
     *
     * @param size
     */
    public void setBuffer( Vector2f size ) {
        buffer = Runtime.getKernel().createBuffer((int) size.x,(int) size.y,(int) size.x,(int) size.y);
    }
    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Drawable#Drawable(abGroup.sgGaming.Engine.Minix2D.device.Graphics2D, int, int)
     */
    public void Drawable(Graphics2D g, int x, int y) {
        buffer.start();
        g.setColor(Color.White);
        callback.callback();
        buffer.update();
        g.drawImage(buffer.getBackingImage(), x + this.x, y + this.y,
                FastMath.getClosedPowerTwo(width), FastMath.getClosedPowerTwo(height),
                0, 0, width, height);
    }

}
