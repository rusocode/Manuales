/*
 * @(#)Dragable.java	1.0 Feb 2, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.m2gui;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 2, 2010
 * @since JDK 1.6
 */
public interface Dragable {

    /**
     * Function that start the drag and drop.
     *
     * @param iX
     * @param iY
     */
    public void dragEvent(int iX, int iY);

}
