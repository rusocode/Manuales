//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.Client.Engine;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * Define a world trigger that cause action for the client.
 *
 * @author Agustin L. Alvarez
 */
public abstract class Trigger {

    /** Trigger Types **/
    public static enum typeTrigger {
        // This type of trigger has a targe sprite.
        TARGET_SPRITE
    };

    /** World Variable **/
    protected World pkWorld;

    /**
     * Pass the world variable for use of it.
     *
     * @param world
     */
    public void setWorld( World world ) {
        pkWorld = world;
    }

    /**
     * @return The trigger type.
     */
    public abstract typeTrigger getTriggerType();
    /**
     * @return The trigger id number.
     */
    public abstract int getTriggerID();
    /**
     * Run the trigger logical.
     */
    public abstract void Logical();

    /**
     * @return The trigger id name.
     */
    public abstract String getTriggerName();

    /**
     * @return IF the trigger has finished.
     */
    public abstract boolean isFinish();

    /**
     * Load the trigger data.
     *
     * @param in
     */
    public abstract void Load( DataInputStream in ) throws IOException;

    /**
     * Save the trigger data.
     *
     * @param out
     */
    public abstract void Save( DataOutputStream out ) throws IOException;
}
