/*
 * @(#)Keyable.java	1.0 Feb 2, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.m2gui;

import abGroup.sgGaming.Engine.Minix2D.input.Keyboard;
import abGroup.sgGaming.Engine.Minix2D.input.Keyboard.enumKeyboardKey;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 2, 2010
 * @since JDK 1.6
 */
public interface Keyable {

    /**
     * Event that raise when the
     * key is down
     * @param KeyNumber
     */
    public void keyDown(enumKeyboardKey key, Keyboard trigger);

    /**
     * Event that raise when the key
     * is release, after doing down
     * @param KeyNumber
     */
    public void keyRelease(enumKeyboardKey key, Keyboard trigger);

    /**
     * Event that raise then the key
     * is pressed
     * @param KeyNumber
     */
    public void keyPress(enumKeyboardKey key, Keyboard trigger);
}
