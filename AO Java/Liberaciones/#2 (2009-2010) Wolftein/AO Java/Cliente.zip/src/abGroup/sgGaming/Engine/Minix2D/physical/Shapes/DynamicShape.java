/*
 * @(#)DynamicShape.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical.Shapes;

/**
 * A tagging interface used for shapes which the current implementation
 * can use for dynamic bodies - i.e. some shapes arn't implemented to
 * work for moving bodies.
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public interface DynamicShape extends Shape {

}
