/*
 * @(#)WindSource.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical.FourceSource;

import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.physical.Body;


/**
 * A source to apply wind to all bodies in a given direction
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class WindSource implements ForceSource {

    /** The force to be applied */
    private Vector2f force = new Vector2f();

    /**
     * Create a new source
     *
     * @param x The x component of the direction
     * @param y The y component of the direction
     * @param power The power of the window
     */
    public WindSource(float x, float y, float power) {
        force.x = x * power;
        force.y = y * power;
    }

    /**
     * @see net.phys2d.raw.forcesource.ForceSource#apply(net.phys2d.raw.Body, float)
     */
    public void apply(Body body, float delta) {
        body.addForce(force);
    }
}
