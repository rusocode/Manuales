/*
 * @(#)Control.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.m2gui;

import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLException;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public abstract class Control {

    /** The default Z **/
    protected final static int DEFAULT_Z = -100;

    protected String name;
    protected boolean enabled;
    protected int x, y;
    protected int width = 0, height = 0;

    public Control(String name) {
        this.name = name;
        this.enabled = false;
    }


    public void parse(XMLElement element) throws XMLException {
        String[] list = element.getAttributeNames();
        // find the native controls.
        for( int i = 0; i < list.length; i++ ) {
            // get the element atrb name
            String atr = list[i].toUpperCase();
            // check the element name
            if( atr.equals("NAME") ) {
                this.name = element.getAttribute("Name");
            } else if( atr.equals("SIZE") ) {
                setSize( Vector2f.parseOf(element.getAttribute("Size")) );
            } else if( atr.equals("POSITION") ) {
                setPosition( Vector2f.parseOf(element.getAttribute("Position")) );
            } else if( atr.equals("ENABLE")) {
                setEnable( element.getBooleanAttribute("Enable") );
            }

        }
    }

    public void setEnable(boolean value) {
        enabled = value;
    }

    public boolean getEnabled() {
        return enabled;
    }

    public void setPosition(Vector2f pos) {
        x = (int) pos.x;
        y = (int) pos.y;
    }

    public Vector2f getPosition() {
        return new Vector2f(x,y);
    }

    public void setSize(Vector2f size) {
        width = (int) size.x;
        height = (int) size.y;
    }

    public Vector2f getSize() {
        return new Vector2f(width,height);
    }

    public boolean checkIntersect(Vector2f pos) {
        return ((pos.x > this.x && pos.x < this.x + width) &&
                (pos.y > this.y && pos.y < this.y + height));
    }
}
