//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.Client.Engine.Manager;

import abGroup.sgGaming.Games.Nylox.Client.Foundation.vsClientLoading;
import abGroup.sgGaming.Minix2D.Util.Debug.Debug;
import abGroup.sgGaming.Minix2D.Util.FileSystem.BinaryStreamFile;
import abGroup.sgGaming.Minix2D.Util.FileSystem.Resource;
import java.io.DataInputStream;
import java.io.IOException;


/**
 * This class load and manage all the sprite resource in the game.
 *
 * @author Agustin L. Alvarez
 */
public class SpriteManager {


    /** Structure for sprite file **/
    public static class SpriteFileClass {

        public String pkVersion;
        public SpriteDataClass[] pkSprite;
    }

    /** List of Sprites in the game **/
    public static SpriteFileClass pkSprite;
    /** List of Character Sprites Data **/
    public static int[][] pkHeadList;
    public static int[][] pkBodyList;
    public static int[][] pkWeaponList;

    /**
     * Load the Sprite data from the a file.
     *
     * @param Filename The file where to load
     * @param PorcentageUse Is the porcentage that use this loading function
     */
    public static boolean initLoadSprite(String Filename, float PorcentageUse) {
        // initialize the path where the sprite are.
        Resource.Add("Data/image/texture/", new BinaryStreamFile() );

        float porcentage = 0.0f;
        DataInputStream in = Resource.Open(Filename);
        try {
            pkSprite = new SpriteFileClass();
            // Load the version of the file
            pkSprite.pkVersion = in.readUTF();
            // Load each Sprite data
            pkSprite.pkSprite = new SpriteDataClass[in.readInt()];
            for (int i = 0; i < pkSprite.pkSprite.length; i++) {
                pkSprite.pkSprite[i] = new SpriteDataClass();
                pkSprite.pkSprite[i].pkIndex = i;
                // Get the Frame list
                byte frameList = in.readByte();
                if (frameList > 0) {
                    pkSprite.pkSprite[i].pkSprite = new int[frameList];
                    for (int j = 0; j < frameList; j++) {
                        pkSprite.pkSprite[i].pkSprite[j] = in.readInt();
                    }
                    pkSprite.pkSprite[i].pkSpeed = in.readFloat();
                } else {
                    pkSprite.pkSprite[i].pkSprite = new int[1];
                    pkSprite.pkSprite[i].pkSprite[0] = i;
                    pkSprite.pkSprite[i].pkSpeed = 1.0000f;
                }
                // Load the sprite data.
                pkSprite.pkSprite[i].pkFilename = in.readUTF();
                pkSprite.pkSprite[i].pkSourceX = in.readShort();
                pkSprite.pkSprite[i].pkSourceY = in.readShort();
                pkSprite.pkSprite[i].pkSourceWidth = in.readShort();
                pkSprite.pkSprite[i].pkSourceHeight = in.readShort();
                // Precalculate the tile's
                pkSprite.pkSprite[i].pkPrePixelX = pkSprite.pkSprite[i].pkSourceWidth / 32;
                pkSprite.pkSprite[i].pkPrePixelY = pkSprite.pkSprite[i].pkSourceHeight / 32;
                // Update the porcentage loaded
                porcentage = (i * 100) / pkSprite.pkSprite.length;
                vsClientLoading.setPorcentage(((porcentage * PorcentageUse) / 100));
            }
            // Now load each character data sprite.
            pkHeadList = new int[in.readInt()][4]; // Load the HEAD data.
            for (int i = 0; i < pkHeadList.length; i++) {
                pkHeadList[i][0] = in.readInt();
                pkHeadList[i][1] = in.readInt();
                pkHeadList[i][2] = in.readInt();
                pkHeadList[i][3] = in.readInt();
            }
            pkBodyList = new int[in.readInt()][6];  // Load the BODY data.
            for (int i = 0; i < pkBodyList.length; i++) {
                pkBodyList[i][0] = in.readInt();
                pkBodyList[i][1] = in.readInt();
                pkBodyList[i][2] = in.readInt();
                pkBodyList[i][3] = in.readInt();
                pkBodyList[i][4] = in.readInt();
                pkBodyList[i][5] = in.readInt();
            }
            pkWeaponList = new int[in.readInt()][4]; // Load the WEAPON data.
            for (int i = 0; i < pkWeaponList.length; i++) {
                pkWeaponList[i][0] = in.readInt();
                pkWeaponList[i][1] = in.readInt();
                pkWeaponList[i][2] = in.readInt();
                pkWeaponList[i][3] = in.readInt();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * Get a body from the entity head list.
     *
     * @param index
     * @return
     */
    public static int[] getHead( int index ) {
        return pkHeadList[index];
    }

    /**
     * Get a body from the entity body list.
     *
     * @param index
     * @return
     */
    public static int[] getBody( int index ) {
        return pkBodyList[index];
    }

}
