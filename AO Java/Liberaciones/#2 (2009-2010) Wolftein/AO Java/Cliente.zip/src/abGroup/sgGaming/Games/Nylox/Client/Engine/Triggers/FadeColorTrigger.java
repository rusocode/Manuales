//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.Client.Engine.Triggers;

import abGroup.sgGaming.Games.Nylox.Client.Engine.Trigger;
import abGroup.sgGaming.Games.Nylox.Client.Engine.World.WorldTileClass;
import abGroup.sgGaming.Minix2D.Util.Color;
import abGroup.sgGaming.Minix2D.Util.ColorPulsator;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * This trigger fade the color of a sprite.
 *
 * @author Agustin L. Alvarez
 */
public class FadeColorTrigger extends Trigger {

    /** Destination Tile **/
    public WorldTileClass pkWcTile;
    public int pkDestinationX, pkDestinationY, pkDestinationLayer;
    /** Color Pulsator **/
    public ColorPulsator pkColor;
    
    /**
     * Constructor
     * 
     * @param tile
     * @param layer
     * @param startColor
     * @param endColor
     * @param Speed
     * @param fromAbove
     */
    public FadeColorTrigger(WorldTileClass tile, int layer, Color startColor, Color endColor, float Speed, boolean fromAbove) {
        pkWcTile = tile;
        pkDestinationLayer = layer;
        pkColor = new ColorPulsator(startColor);
        pkColor.setFrameTimer(Speed);
        pkColor.setPulsator(endColor);
        pkColor.setOriginDestination(fromAbove);
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.Trigger
     */
    @Override
    public void Logical() {
        // Make the color logical.
        pkColor.Logical();
        // Set the Sprite color.
        if( pkWcTile.pkTile[pkDestinationLayer] != null ) {
            pkWcTile.pkTile[pkDestinationLayer].setColor(pkColor);
        }
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.Trigger
     */
    @Override
    public String getTriggerName() {
        return "FadeColor";
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.Trigger
     */
    @Override
    public void Load(DataInputStream in) throws IOException {
        pkDestinationX = in.readShort();
        pkDestinationY = in.readShort();
        pkDestinationLayer = in.readByte();
        pkColor        = new ColorPulsator( in.readFloat(), in.readFloat(), in.readFloat(), in.readFloat() );
        pkColor.setFrameTimer( in.readFloat() );
        pkColor.setPulsator( new Color( in.readFloat(), in.readFloat(), in.readFloat(), in.readFloat()));
        pkColor.setOriginDestination( in.readBoolean() );
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.Trigger
     */
    @Override
    public void Save(DataOutputStream out) throws IOException {
        out.writeShort( pkDestinationX );
        out.writeShort( pkDestinationY );
        out.writeByte( pkDestinationLayer );
        out.writeFloat( pkColor.Red() );
        out.writeFloat( pkColor.Green() );
        out.writeFloat( pkColor.Blue() );
        out.writeFloat( pkColor.Alpha() );
        // Todo Gatther;

    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.Trigger
     */
    @Override
    public boolean isFinish() {
        // TODO: Finish FadeColorTrigger
        return false;
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.Trigger
     */
    @Override
    public typeTrigger getTriggerType() {
        return typeTrigger.TARGET_SPRITE;
    }
    
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.Trigger
     */
    @Override
    public int getTriggerID() {
        return 1;
    }


}
