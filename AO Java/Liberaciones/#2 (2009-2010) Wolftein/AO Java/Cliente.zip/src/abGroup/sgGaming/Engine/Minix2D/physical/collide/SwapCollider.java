/*
 * @(#)SwapCollider.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical.collide;

import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.physical.Body;
import abGroup.sgGaming.Engine.Minix2D.physical.Contact;

/**
 * A collider wrapper that swaps the collision result of the collider.
 * This is very useful to get rid of code duplication for colliders like
 * CircleBoxCollider and BoxCircleCollider.
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class SwapCollider implements Collider {

    /** The wrapped collider of which the result will be swapped */
    private Collider collider;

    /**
     * Create a collider that swaps the result of the wrapped
     * collider.
     *
     * @param collider The collider of which to swap the result
     */
    public SwapCollider(Collider collider) {
        this.collider = collider;
    }

    /**
     * @see net.phys2d.raw.collide.Collider#collide(net.phys2d.raw.Contact[], net.phys2d.raw.Body, net.phys2d.raw.Body)
     */
    public int collide(Contact[] contacts, Body bodyA, Body bodyB) {
        int count = collider.collide(contacts, bodyB, bodyA);

        // reverse the collision results by inverting normals
        for (int i = 0; i < count; i++) {
            Vector2f vec = Vector2f.scale(contacts[i].getNormal(), -1);
            contacts[i].setNormal(vec);
        }

        return count;
    }
}
