/*
 * @(#)Graphics2D.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.device;

import abGroup.sgGaming.Engine.Minix2D.device.Font.Aligment;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public abstract class Graphics2D {

    /** AlphaBlending Enumeration */
    public static enum AlphaBlending {
        // Disable the Alpha Blending
        NONE,
        // Source Alpha Blending
        SOURCE_ALPHA,
        // Destination Alpha Blending
        DESTINATION_ALPHA,
        // Multitexture alpha
        MULTI_BLEND_ALPHA,
        // Blend Equation Add ARB
        ADD_BLEND_EQUATION,
        // Blend Equation Substract ARB
        SUBSTRACT_BLEND_EQUATION,
        // Blend Equation Substract Reverse ARB
        SUBSTRACT_REVERSE_BLEND_EQUATION
    };

    /**
     * Device Property
     */
    public static enum GraphicsHint {
        /**
         * Poligonal Smooth Shading.
         */
        SHADING,
        /**
         * Multisampling
         */
        MULTISAMPLING,
        /**
         * Render Line Width
         */
        LINE_WIDTH
    };

    protected AlphaBlending alphaBlending;
    protected boolean depthBuffer;
    protected Shader shader;

    public abstract void setHintGraphics(GraphicsHint hint, Object value);

    public boolean getDepthBuffer() {
        return depthBuffer;
    }

    public abstract void setDepthBuffer( boolean value );

    public AlphaBlending getAlphaBlending() {
        return alphaBlending;
    }

    public abstract void setClip( int x, int y, int width, int height );

    public abstract void setClip( Shape shape );

    public abstract void setAlphaBlending( AlphaBlending alphaType );

    public abstract void setColor( Color color );

    public void setShader(Shader shader) {
        if (shader == null && this.shader != null) {
            this.shader.disable();
        } else {
            this.shader = shader;
            this.shader.enable();
        }
    }

    public abstract void drawPoint(int x, int y);

    public abstract void drawLine(int x, int y, int width, int height);

    public abstract void drawRect(int x, int y, int width, int height);

    public abstract void drawOval(int x, int y, int width, int height);

    public abstract void drawImage( Image image, int x, int y );

    public abstract void drawImage( Image image, int x, int y, float w, float h );

    public abstract void drawImage( Image image, int x, int y ,float w, float h, float sx, float sy, float sw, float sh );

    public abstract void drawFont( Image image, int x, int y, float w, float h, float sx, float sy, float sw, float sh );

    public abstract void scale(double x, double y);

    public abstract void rotate(double theta);

    public abstract void rotate(double theta, double x, double y);

    public abstract void translate(int x, int y, int z);

    public abstract void translate(double rx, double ry, double rz);

    public abstract void setTransform();

    public abstract void getTransform();

    public abstract void setTextureStage( int TextureStage, Image image);
}
