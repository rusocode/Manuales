/*
 * @(#)BroadCollisionStrategy.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical;

/**
 * A description of any strategy for determining which bodies should
 * be compared against each other for collision - some times referred to
 * as the broad phase. For example the default implementation simply
 * compares every body against every other. Another implementation might
 * spatially partition the bodies into areas and only resolve collisions
 * between those in the same area.
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public interface BroadCollisionStrategy {

    /**
     * Perform the broad phase strategy. The implementation of this method
     * is expected to determine a set of lists of bodies to collided against
     * each other and then pass these lists back through the context for
     * collision detection and response.
     *
     * @param context The context that can actually perform the collision
     * checking.
     * @param bodies The complete list of bodies to be computed
     * @param dt The amount of time passed since last collision
     */
    public void collideBodies(CollisionContext context, BodyList bodies, float dt);
}
