/*
 * @(#)Message.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.network.Message;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public interface Message {
    /**
     * Get a protocol unique ID for this type of message
     *
     * @return The ID of this message type
     */
    public short getID();

    /**
     * Encode the contents of this message to the given stream/
     * Note that this method must be symetric with the decode().
     *
     * @param dout The stream the message should be written to
     * @throws IOException Indicate a failure to the framework while encoding
     */
    public void encode(DataOutputStream dout) throws IOException;

    /**
     * Decode a message from the given stream. Read off each part of the message.
     * Note that this method must be symetric with the encode().
     *
     * @param din The stream from the message contents can be read
     * @throws IOException Indicate a failure to the framework while decoding
     */
    public void decode(DataInputStream din) throws IOException;
}
