/*
 * @(#)SpatialGroup.java	1.0 Feb 12, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.util;

import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.device.Shader;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 12, 2010
 * @since
 */
public class SpatialGroup {

    protected ArrayList<Spatial> spatials;
    protected Shader shader;

    public SpatialGroup() {
        spatials = new ArrayList<Spatial>();
    }

    public SpatialGroup(Spatial[] spatial) {
        this();
        for (int i = 0; i < spatial.length; i++) {
            add(spatial[i]);
        }
    }

    public void setShader(Shader g) {
        shader = g;
    }

    public void add(Spatial t) {
        spatials.add(t);
    }

    public void remove(Spatial t) {
        spatials.remove(t);
    }

    public void render(Graphics2D g, Camera c) {
        // Apply The Shader.
        if (shader != null) {
            shader.enable();
        }
        // Render each spatial.
        Iterator<Spatial> it = spatials.iterator();
        while (it.hasNext()) {
            Spatial t = it.next();
            t.drawSpatial(g, c);
        }
        // End the Shader.
        if (shader != null) {
            shader.disable();
        }
    }
}
