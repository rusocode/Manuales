/*
 * @(#)Canvas.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.device;

import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug.TypeDebug;
import abGroup.sgGaming.Engine.Minix2D.util.debug.ClassDebug.TypeDebugChannel;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public abstract class Canvas {

    /** Device Type. */
    public static enum CanvasType {
        /**
         * Applet Type is inside a canvas renderer.
         */
        APPLET,
        /**
         * Native Type is inside a windows native screen.
         */
        NATIVE
    };

    /** Canvas Property **/
    protected java.awt.Canvas parent;
    protected String title;
    protected Vector2f size;
    protected boolean fullscreen;
    protected boolean verticalsync;
    protected CanvasType type;

    /** Canvas Hint **/
    protected boolean pixelformat;
    protected boolean multisampling;

    /** Canvas recorder **/
    protected ByteBuffer recordData;

    public void setTitle(String value) {
        title = value;
    }

    public void setSize(Vector2f value) {
        size = value;
    }

    public void setSync(boolean value) {
        verticalsync = value;
    }

    public void setFullscreen(boolean value) {
        fullscreen = value;
    }
    
    public void setPixelFormat(boolean value) {
        pixelformat = value;
    }

    public abstract void setViewport( float x, float y, float width, float heith );

    public abstract void setOrtho( float x, float width, float y, float height, float near, float far );

    public void setParent( java.awt.Canvas value ) {
        parent = value;
    }

    public Vector2f getSize() {
        return size;
    }

    public abstract void record();

    public void stopRecord(String path, String filename) {
        try {
            recordData.flip();
            DataOutputStream out = Runtime.getClassLoader().getResourceAsOutput(path, filename);
            out.write(recordData.array());
            out.close();
        } catch (IOException ex) {
            Runtime.getClassDebug().write(TypeDebugChannel.CONSOLE,
                    TypeDebug.ERROR,
                    "Writing recording data.");
        }
    }

    public abstract void clearBuffer( );

    public abstract void updateScreen( );

    public abstract void setClearColor( Color color );

    protected abstract void createCanvas( );

    public abstract boolean closeRequest();

    public abstract boolean isVisible();

    public abstract boolean isActive();

    public abstract void processMessage();

    public abstract String getClipboard();
}
