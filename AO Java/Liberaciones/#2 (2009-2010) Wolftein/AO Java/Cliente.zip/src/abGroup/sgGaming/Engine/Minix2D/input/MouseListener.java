/*
 * @(#)MouseListener.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.input;

import abGroup.sgGaming.Engine.Minix2D.input.Mouse.MOUSE_BUTTON_EVENT;
import abGroup.sgGaming.Engine.Minix2D.input.Mouse.MouseButton;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public interface MouseListener {

    /**
     * Call a Mouse listener, where dx/dy
     * are the relative movement, and rx/ry
     * are the unique position
     * @param dX
     * @param dY
     * @param rX
     * @param rY
     */
    public boolean mouseMove(int dX, int dY, int rX, int rY);

    /**
     * A Button has been pressed
     * @param type
     */
    public boolean mouseButton(MouseButton button, MOUSE_BUTTON_EVENT event);

    /**
     * The Whell has been moved
     * @param WheelNumber
     */
    public boolean mouseWheel(int WheelNumber);
}
