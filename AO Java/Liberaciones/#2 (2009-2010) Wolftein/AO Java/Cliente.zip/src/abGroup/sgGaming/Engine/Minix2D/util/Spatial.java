/*
 * @(#)Spatial.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.util;

import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import abGroup.sgGaming.Engine.Minix2D.math.FastMath;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.device.Color;
import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D.AlphaBlending;
import abGroup.sgGaming.Engine.Minix2D.device.Image;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class Spatial {

    /** Properties */
    protected String image = "";
    protected int sourceX, sourceY, sourceWidth, sourceHeight;
    protected Color color = Color.White;
    protected int translateX, translateY, translateZ;
    protected int width = 0, height = 0;
    protected float rotateAngle;
    protected float scaleX = 1.0f, scaleY = 1.0f;
    protected boolean useDepthBuffer;
    protected AlphaBlending alphaBlending;
    protected Image imageClass = new Image("Spatial", new Vector2f(0,0),0);

    /**
     * Constructor
     *
     * @param imageFilename
     */
    public Spatial(String imageFilename ) {
        setTexture(imageFilename);
        useDepthBuffer = false;
        alphaBlending = AlphaBlending.NONE;
    }

    /**
     * Constructor
     *
     * @param imageFilename
     * @param x
     * @param y
     * @param z
     */
    public Spatial(String imageFilename, int x, int y, int z) {
        this(imageFilename);
        setLocation( x, y, z );
    }

    /**
     * Cloneable constructor
     *
     * @param clone
     */
    public Spatial( Spatial clone ) {
        this(clone.image, clone.translateX, clone.translateY, clone.translateZ );
        sourceX = clone.sourceX;
        sourceY = clone.sourceY;
        sourceWidth = clone.sourceWidth;
        sourceHeight = clone.sourceHeight;
        color = clone.color;
        rotateAngle = clone.rotateAngle;
        scaleX = clone.scaleX;
        scaleY = clone.scaleY;
        useDepthBuffer = clone.useDepthBuffer;
        alphaBlending = clone.alphaBlending;
    }

    /**
     * Check if the spatial is inside the rectangle.
     *
     * @param pos
     * @param size
     * @return
     */
    public boolean isInside( Vector2f pos, Vector2f size ) {
        return true;
    }

    /**
     * Set the texture name.
     *
     * @param texture
     */
    public void setTexture(String imageFilename) {
        image = imageFilename;
    }

    /**
     * Set the texture source.
     *
     * @param x
     * @param y
     * @param width
     * @param height
     */
    public void setTextureSource(int x, int y, int width, int height) {
        sourceX = x;
        sourceY = y;
        sourceWidth = width;
        sourceHeight = height;
    }

    /**
     * Set the size of the destination.
     *
     * @param size
     */
    public void setSize( Vector2f size ) {
        width = (int) size.x;
        height = (int) size.y;
    }

    /**
     * @return The spatial texture size
     */
    public Vector2f getSize() {
        return (width != 0 && height != 0 ? new Vector2f(width,height) :
            new Vector2f( imageClass.getTextureWidth(), imageClass.getTextureHeight()));
    }

    /**
     * @return The spatial image size
     */
    public Vector2f getSourceSize() {
        return (sourceWidth != 0 && sourceHeight != 0 ? new Vector2f( sourceWidth, sourceHeight ) :
            new Vector2f( imageClass.getWidth(), imageClass.getHeight()));
    }

    /**
     * Set the angle of rotation for the spakt.
     *
     * @param Angle
     */
    public void setRotation(float Angle) {
        rotateAngle = Angle;
    }

    /**
     * Set the scalation of the spakt.
     *
     * @param ScaleX
     * @param ScaleY
     */
    public void setScale(float ScaleX, float ScaleY) {
        scaleX = FastMath.clamp( ScaleX, 0.0f, 100.0f );
        scaleY = FastMath.clamp( ScaleY, 0.0f, 100.0f );
    }

    /**
     * Set the color of the spakt.
     *
     * @param c
     */
    public void setColor(Color c) {
        color = c;
    }

    /**
     * Set the use of depth buffer on this spatial.
     *
     * @param value
     */
    public void setDepthBuffer( boolean value ) {
        useDepthBuffer = value;
    }

    /**
     * Set the alpha blending type.
     *
     * @param alphaType
     */
    public void setAlphaBlending( AlphaBlending alphaType ) {
        alphaBlending = alphaType;
    }

    /**
     * Set the location of the spakt.
     *
     * @param X
     * @param Y
     * @param Z
     */
    public void setLocation(int X, int Y, int Z) {
        translateX = X;
        translateY = Y;
        translateZ = Z;
    }

    /**
     * @return The object rotation
     */
    public float getRotation() {
        return rotateAngle;
    }

    /**
     * @return The object x position
     */
    public int getPositionX() {
        return translateX;
    }

    /**
     * @return The object y position
     */
    public int getPositionY() {
        return translateY;
    }

    /**
     * @return The object color.
     */
    public Color getColor() {
        return color;
    }

    /**
     * @return The object x scale
     */
    public float getScaleX() {
        return scaleX;
    }

    /**
     * @return The object y scale
     */
    public float getScaleY() {
        return scaleY;
    }

    /**
     * Render the spakt.
     *
     * @param g The Graphics2D to render into the device.
     */
    public void drawSpatial(Graphics2D g, Camera c) {
        // current rendering size.
        int widthImageSource = sourceWidth;
        int heightImageSource = sourceHeight;
        // Enable the Color
        g.setColor(color);
        // load the image.
        imageClass = Runtime.getImageLoader().getImage(image);
        // Check for the destination.
        if (sourceWidth == 0 && sourceHeight == 0) {
            widthImageSource = imageClass.getWidth();
            heightImageSource = imageClass.getHeight();
        }
        // Save the transformation
        g.getTransform();
        // get the buffer.
        boolean oldBuffer = g.getDepthBuffer();
        if (oldBuffer != useDepthBuffer) {
            g.setDepthBuffer(useDepthBuffer);
        }
        // get and set the alpha blending
        AlphaBlending oldBlend = g.getAlphaBlending();
        if (oldBlend != alphaBlending && alphaBlending != AlphaBlending.NONE) {
            g.setAlphaBlending(alphaBlending);
        }
        // Pre Effect.
        c.applyPreSpatialRender(g, this);
        int widthImageDestination = width;
        int heightImageDestination = height;
        if (width == 0 && height == 0) {
            widthImageDestination = imageClass.getTextureWidth();
            heightImageDestination = imageClass.getTextureHeight();
        }
        // Set for the Position for the rotate
        g.translate(translateX + widthImageSource / 2, translateY + heightImageSource / 2, translateZ);
        // Set the Scale
        g.scale(scaleX, scaleY);
        // Set the rotation
        g.rotate(rotateAngle);
        // Restore the location
        g.translate(-(translateX + widthImageSource / 2), -(translateY + heightImageSource / 2), -(translateZ));
        // Render the object
        g.drawImage(imageClass, translateX, translateY, widthImageDestination, heightImageDestination, sourceX, sourceY, widthImageSource, heightImageSource);
        // Pre Effect.
        c.applyPostSpatialRender(g, this);
        // Restore alplha blending
        if (oldBlend != alphaBlending && alphaBlending != AlphaBlending.NONE) {
            g.setAlphaBlending(oldBlend);
        }
        // Restore the depth buffer
        if (oldBuffer != useDepthBuffer) {
            g.setDepthBuffer(oldBuffer);
        }
        // Restore the transformation
        g.setTransform();
    }
}
