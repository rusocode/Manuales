//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.Client.Foundation.Space;

import abGroup.sgGaming.Minix2D.Networking.Message.Message;
import abGroup.sgGaming.Minix2D.Networking.UrlConnection;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * Message that indicate a client request login into the game server.
 *
 * @author Agustin L. Alvarez
 */
public class vpLoginMessage implements Message {

    /** Constants **/
    private final static String GAME_MASTER_SERVER = "http://www.nylox-online.com.ar";

    /** Message ID implementation **/
    public final static int ID = 1;
    
    /** Session Variables **/
    private String  pkSession;
    private boolean pkValidation;
    private String  pkMappedName;
    
    /**
     * <Client> Constructor
     * 
     * @param Session
     */
    public vpLoginMessage( String Session ) {
        pkValidation = true;
        pkSession = Session;
    }
    
    /**
     * @return If the server validate the Session
     */
    public boolean isValidated() {
        return pkValidation;
    }
    
    /**
     * @return The session of the client.
     */
    public String getSession() {
        return pkSession;
    }
    
    /**
     * @return The name mapped to the session
     */
    public String getMappedName() {
        return pkMappedName;
    }
     
    /**
     * @see abGroup.sgGaming.Minix2D.Networking.Message.Message
     */
    public short getID() {
        return ID;
    }
    /**
     * @see abGroup.sgGaming.Minix2D.Networking.Message.Message
     */
    public void encode(DataOutputStream dout) throws IOException {
        dout.writeUTF(pkSession);
    }
    /**
     * @see abGroup.sgGaming.Minix2D.Networking.Message.Message
     */
    public void decode(DataInputStream din) throws IOException {
       pkSession = din.readUTF();
       // Validate in the master server.
       UrlConnection postConnection = new UrlConnection( GAME_MASTER_SERVER );
       if( postConnection.Post("validation.php?type=validate", "s=" + pkSession) == true ) {
           String postData = postConnection.GetBuffer().toString();
           pkValidation = (postData.indexOf("Session Valid") != -1 ? Boolean.TRUE : Boolean.FALSE);
           // Only if the session is correct, we retrieve the account name.
           if( pkValidation == Boolean.TRUE ) {
               pkMappedName = postData.substring("Session Valid".length());
           }
        }
    }

}
