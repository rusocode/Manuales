/*
 * @(#)Mouseable.java	1.0 Feb 2, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.m2gui;

import abGroup.sgGaming.Engine.Minix2D.input.Mouse.MouseButton;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 2, 2010
 * @since JDK 1.6
 */
public interface Mouseable {
    /**
     * Call a Mouse listener, where dx/dy
     * are the relative movement, and rx/ry
     * are the unique position
     *
     * @param dX
     * @param dY
     * @param rX
     * @param rY
     */
    public void mouseMove(int dX, int dY, int rX, int rY);

    /**
     * A Button has been pressed
     * @param type
     */
    public void mouseButton(MouseButton button);

    /**
     * The Whell has been moved
     * @param WheelNumber
     */
    public void mouseWheel(int WheelNumber);
}
