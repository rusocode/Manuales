
package abGroup.sgGaming.Games.Nylox.Client.Foundation.Space;

import abGroup.sgGaming.Minix2D.Networking.Message.Message;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * This message indicate the creation data of a character.
 *
 * @author Agustin L. Alvarez
 */
public class vpCreateCharacterMessage implements Message {

    /** Message ID implementation **/
    public final static int ID = 5;

    /**
     * @see abGroup.sgGaming.Minix2D.Networking.Message.Message
     */
    public short getID() {
        return ID;
    }
    /**
     * @see abGroup.sgGaming.Minix2D.Networking.Message.Message
     */
    public void encode(DataOutputStream dout) throws IOException {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    /**
     * @see abGroup.sgGaming.Minix2D.Networking.Message.Message
     */
    public void decode(DataInputStream din) throws IOException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
