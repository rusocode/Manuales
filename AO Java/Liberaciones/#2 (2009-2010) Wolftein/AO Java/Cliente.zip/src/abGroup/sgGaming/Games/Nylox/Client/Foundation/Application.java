//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.Client.Foundation;

import abGroup.sgGaming.Games.Nylox.Client.Engine.Entity;
import abGroup.sgGaming.Games.Nylox.Client.Engine.Manager.ManagerState;
import abGroup.sgGaming.Games.Nylox.Client.Engine.World;
import abGroup.sgGaming.Minix2D.Foundation.Engine;
import abGroup.sgGaming.Minix2D.Networking.Message.Message;
import abGroup.sgGaming.Minix2D.Networking.Message.MessageChannel;
import abGroup.sgGaming.Minix2D.Renderer.Device;
import abGroup.sgGaming.Minix2D.Renderer.DeviceListener;
import abGroup.sgGaming.Minix2D.Renderer.Render2D;
import abGroup.sgGaming.Minix2D.Util.Debug.ConstantDebugChannelCompilator;
import abGroup.sgGaming.Minix2D.Util.Debug.Debug;

/**
 * This class define the entry application for the Minix2D Launcher.
 *
 * @author Agustin L. Alvarez
 */
public class Application implements DeviceListener {

    /** This is the application frame per second speed **/
    public static final float APPLICATION_FRAME_PER_SECOND = 60.0f;

    /** This is the Channel of the server **/
    protected static MessageChannel pkServerChannel;
    /** This is the game World **/
    protected static World pkWorld;
    /** Character Controller **/
    protected static Entity pkCharacter;

    /**
     * Constructor for the <br>Minix2D Launcher</br>
     *
     * @param param The list of parameters.
     * @param dir The application directory.
     * @param Minix The Minix2D engine.
     */
    public Application(String[] param, String dir, Engine Minix) {
        // Check the application states.
        if (checkParameter(param, "-debug") == true) {
            Debug.SetChannel(ConstantDebugChannelCompilator.getClassTag());
        }
        if (checkParameter(param, "-console") == true) {
        }
        // set the first state
        // (SESSION,NAME,FIRSTNAME,LASTNAME,AGE,EMAIL)
        //ManagerState.setState( new vsClientServer( new String[]{"TEST_SESSION","Wolftein","Agustin","Alvarez","19","arthas03@hotmail.com"}) );
        ManagerState.setState(new vsClientLogin());
    }

    /**
     * Find a parameter inside the parameter list.
     *
     * @param param The parameters list
     * @param paramName The parameter to find
     * @return TRUE if we found the parameter
     */
    private boolean checkParameter(String[] param, String paramName) {
        if (param.length > 0) {
            for (int i = 0; i < param.length; i++) {
                if (param[i].equalsIgnoreCase(paramName) == true) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Send a message packet to the remote server.
     *
     * @param c The message to send.
     */
    public static void sendMessage(Message c) {
        try {
            pkServerChannel.write(c, false);
        } catch (Exception ex) {
            pkServerChannel = null;
        }
    }

    /**
     * @see abGroup.sgGaming.Minix2D.Renderer.DeviceListener
     */
    public void Initialize(Device c, Render2D g) {
        g.SetAlphaBlending(Render2D.AlphaBlending.SOURCE_ALPHA);
    }

    /**
     * @see abGroup.sgGaming.Minix2D.Renderer.DeviceListener
     */
    public void Render(Render2D g) {
        if (ManagerState.isVsRunning() == false) {
            pkWorld.Render(g, 0, 0, 0f, 0f);
        }
    }
    /**
     * @see abGroup.sgGaming.Minix2D.Renderer.DeviceListener
     */
    public void Logical(float deltaTime) {
        // Execute the network state.
        Message msgRecieve = null;
        if (pkServerChannel != null) {
            // Read an incoming message.
            try {
                msgRecieve = pkServerChannel.read();
            } catch (Exception ex) {
                pkServerChannel = null;
            }
        }
        // Continue executing state until we reach the engine custom state.
        if (ManagerState.isVsRunning() == true) {
            ManagerState.executeManager(deltaTime, msgRecieve);
        } else {
            // Parse the Message
            if (msgRecieve != null) {
                pkWorld.MessageNetwork(msgRecieve);
            }
            pkWorld.Logical(deltaTime);
        }
    }
    /**
     * @see abGroup.sgGaming.Minix2D.Renderer.DeviceListener
     */
    public boolean CloseRequest() {
        return true;
    }

}
