/*
 * @(#)JButton.java	1.0 Feb 2, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.m2gui.controls;

import abGroup.sgGaming.Engine.Minix2D.device.Color;
import abGroup.sgGaming.Engine.Minix2D.device.Font;
import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.input.Mouse.MouseButton;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Control;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Drawable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Eventable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Mouseable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Regionable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Triggered;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLException;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 2, 2010
 * @since JDK 1.6
 */
public class JButton extends Control implements Drawable, Mouseable, Regionable, Eventable {

    protected int currentFrame = 0;
    protected JPicture[] frame;
    protected JLabel caption;
    protected boolean reset = false;
    protected Triggered callback;

    /**
     * Constructor
     *
     * @param x
     * @param y
     * @param f
     */
    public JButton(int x, int y, Font f) {
        super("JButton");
        // Create the Resource.
        frame = new JPicture[2];
        for (int i = 0; i < frame.length; i++) {
            frame[i] = new JPicture(0, 0);
        }
        caption = new JLabel(0, 0, f);
        caption.setAligment(Font.Aligment.Center);
        caption.setResizable(false);
    }

    /**
     * Constructor
     *
     * @param element
     * @throws XMLException
     */
    public JButton(XMLElement element) throws XMLException {
        this(0, 0, null);
        parse(element);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Control#parse(abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement)
     */
    @Override
    public void parse(XMLElement element) throws XMLException {
        // Control parse native.
        super.parse(element);
        // JPicture propertys.
        String[] xmlProperty = element.getAttributeNames();
        String currentProperty;
        for (int i = 0; i < xmlProperty.length; i++) {
            currentProperty = xmlProperty[i].toUpperCase();
            if (currentProperty.equals("COLOR")) {
                setColor(Color.parseOf(element.getAttribute("Color")));
            } else if (currentProperty.equals("CAPTION")) {
                setCaption(element.getAttribute("Caption"));
            } else if (currentProperty.equals("IMAGE")) {
                setImage(element.getAttribute("Image"), 0);
            } else if (currentProperty.equals("ONIMAGE")) {
                setImage(element.getAttribute("onImage"), 1);
            } else if (currentProperty.equals("FONT")) {
                caption.setFont(Font.Retrieve(element.getAttribute("Font")));
            }
        }
    }

    /**
     * Set the button callback.
     * 
     * @param c
     */
    public void setCallback(Triggered c) {
        callback = c;
    }

    /**
     * Set the button image frame.
     *
     * @param image
     * @param frame
     */
    public void setImage(String image, int frame) {
        this.frame[frame].setImage(image);
    }

    /**
     * Set the button caption.
     *
     * @param text
     */
    public void setCaption(String text) {
        caption.setCaption(text);
    }

    /**
     * Set the button label color.
     *
     * @param c
     */
    public void setColor(Color c) {
        caption.setColor(c);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Drawable#Drawable(abGroup.sgGaming.Engine.Minix2D.device.Graphics2D, int, int)
     */
    public void Drawable(Graphics2D g, int x, int y) {
        // refresh the size.
        setSize(frame[currentFrame].getSize());
        caption.setSize(frame[currentFrame].getSize());
        // set the color of rendering
        g.setColor(Color.White);
        // render the image.
        frame[currentFrame].Drawable(g, this.x + x, this.y + y);
        // render the label
        caption.Drawable(g, this.x + x, this.y + y);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Regionable
     */
    public void Enter() {
        if (frame[1] != null) {
            currentFrame = 1;
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Regionable
     */
    public void Exit() {
        currentFrame = 0;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Mouseable
     */
    public void mouseMove(int dX, int dY, int rX, int rY) {
        return;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Mouseable
     */
    public void mouseButton(MouseButton button) {
        if (button == MouseButton.BUTTON_LEFT) {
            // Only call callback
            if (callback != null) {
                callback.callback();
            }
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Mouseable
     */
    public void mouseWheel(int WheelNumber) {
        return;
    }
}
