//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.Client.Foundation;

import abGroup.sgGaming.Games.Nylox.Client.Engine.Manager.VirtualState;
import abGroup.sgGaming.Games.Nylox.Client.Foundation.Space.vpCharacterMessage;
import abGroup.sgGaming.Minix2D.Networking.Message.Message;
import abGroup.sgGaming.Minix2D.Networking.Message.MessageChannel;

/**
 * This class define the virtual state of character creation.
 *
 * @author Agustin L. Alvarez
 */
public class vsClientCreateCharacter implements VirtualState {

    /** backward compatibility **/
    private vpCharacterMessage pkCharacter;
    /** This boolean represent if the state need to continue **/
    private boolean pkFinish = false;

    /**
     * Constructor
     *
     * @param l The message for backward compatibility
     */
    protected vsClientCreateCharacter( vpCharacterMessage l ) {
        pkCharacter = l;
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public String getStateName() {
        return "vsClientCreateCharacter";
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public void Execute(float virtualTimer) {
        // Nothing to do here.
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public boolean hasNextState() {
        return false;
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public VirtualState getNextState() {
        return null;
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public VirtualState getPrevState() {
        return new vsClientCharacter(pkCharacter);
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public boolean isFinished() {
        return pkFinish;
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public void parseMessage(Message c) {
        return;
    }

}
