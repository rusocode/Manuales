/*
 * @(#)OpenUrlTrigger.java	1.0 May 25, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.m2gui.triggers;

import abGroup.sgGaming.Engine.Minix2D.m2gui.Triggered;
import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,May 25, 2010
 * @since
 */
public class OpenUrlTrigger implements Triggered {

    private String urlString;

    public OpenUrlTrigger(String url) {
        urlString = url;
    }

    public void callback() {
        Runtime.getKernel().getHelper().OpenURL(urlString);
    }
}
