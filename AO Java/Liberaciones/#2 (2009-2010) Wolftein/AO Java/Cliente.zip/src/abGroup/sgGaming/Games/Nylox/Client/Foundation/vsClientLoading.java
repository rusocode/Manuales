//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.Client.Foundation;

import abGroup.sgGaming.Games.Nylox.Client.Engine.Manager.SpriteManager;
import abGroup.sgGaming.Games.Nylox.Client.Engine.Manager.VirtualState;
import abGroup.sgGaming.Minix2D.Networking.Message.Message;

/**
 * This class define the virtual state of loading the game resource.
 *
 * @author Agustin L. Alvarez
 */
public class vsClientLoading implements VirtualState {

    /** This boolean represent if the state need to continue **/
    private boolean pkFinish = false;
    /** This is global because can be edited by multithread **/
    private static float pkPorcentage = 0.0f;

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public String getStateName() {
        return "vsClientLoading";
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public void Execute(float virtualTimer) {
        // Todo: Loading Screen.
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public boolean hasNextState() {
        return true;
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public VirtualState getNextState() {
        return new vsClientLogin();
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public VirtualState getPrevState() {
        return null;
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public boolean isFinished() {
        return pkFinish;
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public void parseMessage(Message c) {
        return;
    }
    /**
     * Set the porcentage of the loading screen.
     *
     * @param porcentage
     */
    public static synchronized void setPorcentage( float porcentage ) {
        pkPorcentage = porcentage;
    }

    /**
     * This function load's the game foundation resource.
     */
    private Runnable LoadFunction = new Runnable() {
        public void run() {
            SpriteManager.initLoadSprite( "Sprite.lst", 20 );
        }
    };

}
