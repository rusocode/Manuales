/*
 * @(#)Shape.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.device;

import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public abstract class Shape {

    /** The Shape property **/
    protected int x, y, z;
    protected Vector2f size;
    protected Vector2f scale;
    protected Color color;
    protected float rotate;

    /**
     * Construc a shape.
     * 
     * @param x
     * @param y
     * @param z
     * @param size
     */
    public Shape( int x, int y, int z, Vector2f size ) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.size = size;
        this.scale = new Vector2f(1.0f,1.0f);
        this.color = Color.White;
        this.rotate = 0.0f;
    }

    /**
     * Set the shape size.
     *
     * @param size
     */
    public void setSize( Vector2f size ) {
        this.size = size;
    }

    /**
     * Set the scale of the shape
     *
     * @param scale
     */
    public void setScale( Vector2f scale ) {
        this.scale = scale;
    }

    /**
     * Set the rotation of the shape.
     *
     * @param angle
     */
    public void setRotate( float angle ) {
        rotate = angle;
    }

    /**
     * Set the color of the shape.
     *
     * @param color
     */
    public void setColor( Color color ) {
        this.color = color;
    }

    
    /**
     * This function renders the actual shape type.
     *
     * @param g
     */
    protected void renderShape( Graphics2D g ) {
        return;
    }


    /**
     * Render the shape.
     *
     * @param g
     */
    public void render(Graphics2D g) {
        // Enable the Color
        g.setColor(color);
        // Save te Transformation
        g.getTransform();
        // Set for the Position for the rotate
        g.translate(x + size.x / 2, y + size.y / 2, z);
        // Set the Scale
        g.scale(scale.x, scale.y);
        // Set the rotation
        g.rotate(rotate);
        // Restore the location
        g.translate(-(x + size.x / 2), -(y + size.y / 2), -(z));
        // Render the object
        renderShape(g);
        // Restore the transformation
        g.setTransform();
    }

}
