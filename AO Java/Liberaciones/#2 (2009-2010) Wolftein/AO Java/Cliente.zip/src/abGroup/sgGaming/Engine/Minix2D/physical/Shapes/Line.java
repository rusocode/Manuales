/*
 * @(#)Line.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical.Shapes;

import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;

/**
 * Implemenation of a bunch of maths functions to do with lines. Note
 * that lines can't be used as dynamic shapes right now - also collision 
 * with the end of a line is undefined.
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public strictfp class Line extends AbstractShape implements DynamicShape {
    /** The start point of the line */
    private Vector2f start;
    /** The end point of the line */
    private Vector2f end;
    /** The vector between the two points */
    private Vector2f vec;
    /** The length of the line squared */
    private float lenSquared;
    /** Temporary storage - declared globally to reduce GC */
    private Vector2f loc = new Vector2f(0, 0);
    /** Temporary storage - declared globally to reduce GC */
    private Vector2f v = new Vector2f(0, 0);
    /** Temporary storage - declared globally to reduce GC */
    private Vector2f v2 = new Vector2f(0, 0);
    /** Temporary storage - declared globally to reduce GC */
    private Vector2f proj = new Vector2f(0, 0);
    /** Temporary storage - declared globally to reduce GC */
    private Vector2f closest = new Vector2f(0, 0);
    /** Temporary storage - declared globally to reduce GC */
    private Vector2f other = new Vector2f(0, 0);
    /** True if this line blocks on the outer edge */
    private boolean outerEdge = true;
    /** True if this line blocks on the inner edge */
    private boolean innerEdge = true;

    /**
     * Create a new line based on the origin and a single point
     *
     * @param x The end point of the line
     * @param y The end point of the line
     * @param inner True if this line blocks on it's inner edge
     * @param outer True if this line blocks on it's outer edge
     */
    public Line(float x, float y, boolean inner, boolean outer) {
        this(0, 0, x, y);

        setBlocksInnerEdge(inner);
        setBlocksOuterEdge(outer);
    }

    /**
     * Create a new line based on the origin and a single point
     *
     * @param x The end point of the line
     * @param y The end point of the line
     */
    public Line(float x, float y) {
        this(x, y, true, true);
    }

    /**
     * Create a new line based on two points
     *
     * @param x1 The x coordinate of the start point
     * @param y1 The y coordinate of the start point
     * @param x2 The x coordinate of the end point
     * @param y2 The y coordinate of the end point
     */
    public Line(float x1, float y1, float x2, float y2) {
        this(new Vector2f(x1, y1), new Vector2f(x2, y2));
    }

    /**
     * Create a new line based on two points
     *
     * @param start The start point
     * @param end The end point
     */
    public Line(Vector2f start, Vector2f end) {
        super();

//		float width = Math.abs(end.getX()-start.getX());
//		float height = Math.abs(end.getY()-start.getY());
//		float xoffset = width/2;
//		float yoffset = height/2;
//		if (width < 10) {
//			width = 10;
//		}
//		if (height < 10) {
//			height = 50;
//		}
//		if (end.getY() < start.getY()) {
//			yoffset = -yoffset;
//		}
//		if (end.getX() < start.getX()) {
//			xoffset = -xoffset;
//		}
        //TODO: do this properly!
        float radius = Math.max(start.length(), end.length());
        bounds = new AABox(0, 0, radius * 2, radius * 2);

        set(start, end);
    }

    /**
     * Check if this line blocks the inner side (for want of a better term)
     *
     * @return True if this line blocks the inner side
     */
    public boolean blocksInnerEdge() {
        return innerEdge;
    }

    /**
     * Indicate if this line blocks on it's inner edge
     *
     * @param innerEdge True if this line blocks on it's inner edge
     */
    public void setBlocksInnerEdge(boolean innerEdge) {
        this.innerEdge = innerEdge;
    }

    /**
     * Check if this line blocks the outer side (for want of a better term)
     *
     * @return True if this line blocks the outer side
     */
    public boolean blocksOuterEdge() {
        return outerEdge;
    }

    /**
     * Indicate if this line blocks on it's outer edge
     *
     * @param outerEdge True if this line blocks on it's outer edge
     */
    public void setBlocksOuterEdge(boolean outerEdge) {
        this.outerEdge = outerEdge;
    }

    /**
     * Get the start point of the line
     *
     * @return The start point of the line
     */
    public Vector2f getStart() {
        return start;
    }

    /**
     * Get the end point of the line
     *
     * @return The end point of the line
     */
    public Vector2f getEnd() {
        return end;
    }

    /**
     * Find the length of the line
     *
     * @return The the length of the line
     */
    public float length() {
        return vec.length();
    }

    /**
     * Find the length of the line squared (cheaper and good for comparisons)
     *
     * @return The length of the line squared
     */
    public float lengthSquared() {
        return vec.LengthSquared();
    }

    /**
     * Configure the line
     *
     * @param start The start point of the line
     * @param end The end point of the line
     */
    public void set(Vector2f start, Vector2f end) {
        this.start = start;
        this.end = end;

        vec = new Vector2f(end);
        vec.Sub(start);

        lenSquared = vec.length();
        lenSquared *= lenSquared;
    }

    /**
     * Get the x direction of this line
     *
     * @return The x direction of this line
     */
    public float getDX() {
        return end.GetX() - start.GetX();
    }

    /**
     * Get the y direction of this line
     *
     * @return The y direction of this line
     */
    public float getDY() {
        return end.GetY() - start.GetY();
    }

    /**
     * Get the x coordinate of the start point
     *
     * @return The x coordinate of the start point
     */
    public float getX1() {
        return start.GetX();
    }

    /**
     * Get the y coordinate of the start point
     *
     * @return The y coordinate of the start point
     */
    public float getY1() {
        return start.GetY();
    }

    /**
     * Get the x coordinate of the end point
     *
     * @return The x coordinate of the end point
     */
    public float getX2() {
        return end.GetX();
    }

    /**
     * Get the y coordinate of the end point
     *
     * @return The y coordinate of the end point
     */
    public float getY2() {
        return end.GetY();
    }

    /**
     * Get the shortest distance from a point to this line
     *
     * @param point The point from which we want the distance
     * @return The distance from the line to the point
     */
    public float distance(Vector2f point) {
        return (float) Math.sqrt(distanceSquared(point));
    }

    /**
     * Get the shortest distance squared from a point to this line
     *
     * @param point The point from which we want the distance
     * @return The distance squared from the line to the point
     */
    public float distanceSquared(Vector2f point) {
        getClosestPoint(point, closest);
        closest.Sub(point);

        float result = closest.LengthSquared();

        return result;
    }

    /**
     * Get the closest point on the line to a given point
     *
     * @param point The point which we want to project
     * @param result The point on the line closest to the given point
     */
    public void getClosestPoint(Vector2f point, Vector2f result) {
        loc.Set(point);
        loc.Sub(start);

        v.Set(vec);
        v2.Set(vec);
        v2.Scale(-1);

        v.Normalise();
        loc.ProjectOntoUnit(v, proj);
        if (proj.LengthSquared() > vec.LengthSquared()) {
            result.Set(end);
            return;
        }
        proj.Add(start);

        other.Set(proj);
        other.Sub(end);
        if (other.LengthSquared() > vec.LengthSquared()) {
            result.Set(start);
            return;
        }

        result.Set(proj);
        return;
    }

    /**
     * @see net.phys2d.raw.shapes.Shape#getSurfaceFactor()
     */
    public float getSurfaceFactor() {
        return lengthSquared() / 2;
    }

    /**
     * Get a line starting a x,y and ending offset from the current
     * end point. Curious huh?
     *
     * @param displacement The displacement of the line
     * @param rotation The rotation of the line in radians
     * @return The newly created line
     */
    public Line getPositionedLine(Vector2f displacement, float rotation) {
        Vector2f[] verts = getVertices(displacement, rotation);
        Line line = new Line(verts[0], verts[1]);

        return line;
    }

    /**
     * Return a translated and rotated line.
     *
     * @param displacement The displacement of the line
     * @param rotation The rotation of the line in radians
     * @return The two endpoints of this line
     */
    public Vector2f[] getVertices(Vector2f displacement, float rotation) {
        float cos = (float) Math.cos(rotation);
        float sin = (float) Math.sin(rotation);

        Vector2f[] endPoints = new Vector2f[2];
        endPoints[0] = new Vector2f(//getX1(), getY1());
                getX1() * cos - getY1() * sin,
                getY1() * cos + getX1() * sin);
        endPoints[0].Add(displacement);
        endPoints[1] = new Vector2f(//getX2(), getY2());
                getX2() * cos - getY2() * sin,
                getY2() * cos + getX2() * sin);
        endPoints[1].Add(displacement);

        return endPoints;
    }

    /**
     * Move this line a certain amount
     *
     * @param v The amount to move the line
     */
    public void move(Vector2f v) {
        Vector2f temp = new Vector2f(start);
        temp.Add(v);
        start = temp;
        temp = new Vector2f(end);
        temp.Add(v);
        end = temp;
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString() {
        return "[Line " + start + "," + end + "]";
    }

    /**
     * Intersect this line with another
     *
     * @param other The other line we should intersect with
     * @return The intersection point or null if the lines are parallel
     */
    public Vector2f intersect(Line other) {
        float dx1 = end.GetX() - start.GetX();
        float dx2 = other.end.GetX() - other.start.GetX();
        float dy1 = end.GetY() - start.GetY();
        float dy2 = other.end.GetY() - other.start.GetY();
        float denom = (dy2 * dx1) - (dx2 * dy1);

        if (denom == 0) {
            return null;
        }

        float ua = (dx2 * (start.GetY() - other.start.GetY())) - (dy2 * (start.GetX() - other.start.GetX()));
        ua /= denom;
        float ub = (dx1 * (start.GetY() - other.start.GetY())) - (dy1 * (start.GetX() - other.start.GetX()));
        ub /= denom;

        float u = ua;

        float ix = start.GetX() + (u * (end.GetX() - start.GetX()));
        float iy = start.GetY() + (u * (end.GetY() - start.GetY()));

        return new Vector2f(ix, iy);
    }
	
}
