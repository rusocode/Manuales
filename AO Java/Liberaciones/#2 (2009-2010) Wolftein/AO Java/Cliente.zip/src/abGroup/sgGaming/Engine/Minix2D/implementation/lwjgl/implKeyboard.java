/*
 * @(#)implKeyboard.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl;

import abGroup.sgGaming.Engine.Minix2D.input.Keyboard;
import org.lwjgl.LWJGLException;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class implKeyboard extends Keyboard {

    /**
     * Constructor
     */
    public implKeyboard() {
        super();
        Create( );
    }

    /**
     * @see abGroup.sgGaming.Minix2D.Input.Keyboard
     */
    public void irqEvent() {
        this.bResetted = false;
        Create();
        // Variable for gathering
        KeyboardEvent eventRaise;
        int eventKeyboard;
        enumKeyboardKey keyEvent;
        // Poll the keyboard events
        org.lwjgl.input.Keyboard.poll();
        // while there is a button pressed
        // make actions
        while (org.lwjgl.input.Keyboard.next()) {
            // only if the event itÃ‚Â´s not
            // none
            if (org.lwjgl.input.Keyboard.getEventKey() != enumKeyboardKey.KEY_NONE.ordinal()) {
                // the event can only be DOWN or UP
                eventRaise = (org.lwjgl.input.Keyboard.getEventKeyState() == true) ? KeyboardEvent.KEY_DOWN : KeyboardEvent.KEY_RELEASE;
                eventKeyboard = org.lwjgl.input.Keyboard.getEventKey();
                keyEvent = enumKeyboardKey.GetKeyFromID(eventKeyboard);
                // if it was on key Down then
                if (eventRaise == KeyboardEvent.KEY_RELEASE && implKeyDown.contains(keyEvent.ordinal())) {
                    implKeyDown.removeElement(keyEvent.ordinal());
                } else if (eventRaise == KeyboardEvent.KEY_DOWN && !implKeyDown.contains(keyEvent.ordinal())) {
                    implKeyDown.add(keyEvent.ordinal());
                }
                // Call the function of the Main Keyboard
                Channel(eventRaise, keyEvent.ordinal());
            }
        }
        // Call each Key Down
        if (!implKeyDown.isEmpty()) {
            for (int i = implKeyDown.size() - 1; i >= 0; i--) {
                Channel(KeyboardEvent.KEY_DOWN, implKeyDown.get(i));
            }
        }
    }

    /**
     * Create the implementation
     */
    private void Create() {
        try {
            if( org.lwjgl.input.Keyboard.isCreated() == false ) {
                org.lwjgl.input.Keyboard.create();
            }
        } catch (LWJGLException ex) {
            throw new RuntimeException("LWJGLKeyboard#Create Exception");
        }
    }

    protected void finalize() throws Throwable {
        super.finalize();
        org.lwjgl.input.Keyboard.destroy();
    }

}