/*
 * @(#)StateApplication.java	1.0 Feb 7, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.kernel;

import abGroup.sgGaming.Engine.Minix2D.device.Canvas;
import abGroup.sgGaming.Engine.Minix2D.device.DeviceListener;
import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.input.Keyboard.enumKeyboardKey;
import abGroup.sgGaming.Engine.Minix2D.input.KeyboardListener;
import abGroup.sgGaming.Engine.Minix2D.input.Mouse.MOUSE_BUTTON_EVENT;
import abGroup.sgGaming.Engine.Minix2D.input.Mouse.MouseButton;
import abGroup.sgGaming.Engine.Minix2D.input.MouseListener;
import abGroup.sgGaming.Engine.Minix2D.kernel.BaseApplication.Library;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import java.util.ArrayList;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 7, 2010
 * @since
 */
public abstract class StateApplication implements DeviceListener, MouseListener, KeyboardListener {

    /** The application base **/
    protected BaseApplication baseEngine;
    protected int mouseX, mouseY;
    /** The application state list **/
    protected ArrayList<MinixState> stateList;
    protected MinixState currentState;

    /**
     * Constructor
     *
     * @param library
     * @param title
     * @param size
     * @param fullscreen
     * @param quality
     */
    public StateApplication(Library library, String title, Vector2f size, boolean fullscreen, boolean quality) {
        stateList = new ArrayList<MinixState>();
        baseEngine = new BaseApplication(library, title, size, fullscreen, quality);
        baseEngine.setDeviceListener(this);
        baseEngine.setKeyboardListener(this);
        baseEngine.setMouseListener(this);
        baseEngine.setRun(true);
        baseEngine.run();
    }

    /**
     * Change the minix state for other.
     *
     * @param t
     */
    protected void changeState(MinixState t) {
        currentState = t;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.DeviceListener
     */
    public void Initialize(Canvas c) {
        createApplication(c);
        createSceneGraph(baseEngine);
    }

    /**
     * Create the application.
     */
    protected abstract void createApplication(Canvas c);

    /**
     * Create the scene graph.
     */
    protected abstract void createSceneGraph(BaseApplication ba);

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.DeviceListener
     */
    public void Render(Graphics2D g) {
        // Render the current state.
        if (currentState != null) {
            currentState.render(g);
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.DeviceListener
     */
    public void Logical(float deltaTime) {
        // Logical the current state.
        if (currentState != null) {
            currentState.logical(deltaTime);
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.device.DeviceListener
     */
    public boolean closeRequest() {
        if (currentState != null && currentState.isCloseOnRequest() == true) {
            return true;
        } else if (currentState != null && currentState.hasPrevState() == true) {
            changeState(currentState.getPrevState());
            return false;
        } else {
            return true;
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.input.MouseListener
     */
    public boolean mouseMove(int dX, int dY, int rX, int rY) {
        mouseX = dX;
        mouseY = dY;
        if (currentState != null) {
            currentState.mouseMove(mouseX, mouseY);
        }
        return Boolean.TRUE;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.input.MouseListener
     */
    public boolean mouseButton(MouseButton button, MOUSE_BUTTON_EVENT event) {
        if (currentState != null) {
            currentState.mouseButton(button, event);
        }
        return Boolean.TRUE;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.input.MouseListener
     */
    public boolean mouseWheel(int WheelNumber) {
        if( currentState != null ) {
            currentState.mouseWheel( (WheelNumber > 0) );
        }
        return Boolean.TRUE;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.input.KeyboardListener
     */
    public boolean keyDown(enumKeyboardKey key) {
        if (currentState != null) {
            currentState.keyDown(key);
        }
        return Boolean.TRUE;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.input.KeyboardListener
     */
    public boolean keyRelease(enumKeyboardKey key) {
        return true;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.input.KeyboardListener
     */
    public boolean keyPress(enumKeyboardKey key) {
        if (currentState != null) {
            currentState.keyPress(key);
        }
        return Boolean.TRUE;
    }


}
