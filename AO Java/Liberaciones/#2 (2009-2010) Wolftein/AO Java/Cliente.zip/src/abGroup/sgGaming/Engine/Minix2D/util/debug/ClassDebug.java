/*
 * @(#)ClassDebug.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.util.debug;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class ClassDebug {

    /** The types of debug **/
    public static enum TypeDebugChannel {
        // This type of debug, will print all
        // into a console os derived.
        CONSOLE,
        // This type of debug, will print all
        // into a file.
        FILE
    };

    /** The type of prints **/
    public static enum TypeDebug {
        INFORMATION,
        WARNING,
        ERROR
    };

    /** The current debug channel **/
    private Map<TypeDebugChannel, DebugChannel> classDebugChannel;

    public ClassDebug() {
        classDebugChannel = new HashMap<TypeDebugChannel,DebugChannel>( );
        classDebugChannel.put(TypeDebugChannel.CONSOLE, debugChannelFactory(TypeDebugChannel.CONSOLE));
        classDebugChannel.put(TypeDebugChannel.FILE, debugChannelFactory(TypeDebugChannel.FILE));
    }

    public void write(TypeDebugChannel channel, TypeDebug type, String string) {
        DebugChannel dcClass = classDebugChannel.get(channel);
        if (type == TypeDebug.WARNING) {
            dcClass.printWarning(string);
        } else if (type == TypeDebug.ERROR) {
            dcClass.printError(string);
        } else if (type == TypeDebug.INFORMATION) {
            dcClass.printInfo(string);
        }
    }

    private DebugChannel debugChannelFactory(TypeDebugChannel type) {
        if (type == TypeDebugChannel.CONSOLE) {
            return new DebugChannelDefault();
        } else if (type == TypeDebugChannel.FILE) {
            return new DebugChannelDefault();
        }
        return null;
    }
}
