/*
 * @(#)XMLException.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package abGroup.sgGaming.Engine.Minix2D.util.xml;

/**
 * An exception to describe failures in XML. Made a special case because with XML
 * to object parsing you might want to handle it differently
 *
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class XMLException extends Exception {

    /**
     * Create a new exception
     *
     * @param message The message describing the failure
     */
    public XMLException(String message) {
        super(message);
    }

    /**
     * Create a new exception
     *
     * @param message The message describing the failure
     * @param e The exception causing this failure
     */
    public XMLException(String message, Throwable e) {
        super(message, e);
    }
}

