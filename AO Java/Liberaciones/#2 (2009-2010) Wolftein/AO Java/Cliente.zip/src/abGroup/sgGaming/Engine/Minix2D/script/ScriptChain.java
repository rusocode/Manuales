/*
 * @(#)ScriptChain.java	1.0 May 27, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.script;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,May 27, 2010
 * @since
 */
public interface ScriptChain<T, E> {

    public String getScriptName();

    public T getScriptValue( E value );

}
