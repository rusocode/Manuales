/*
 * @(#)XMLElementList.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package abGroup.sgGaming.Engine.Minix2D.util.xml;

import java.util.ArrayList;
import java.util.Collection;

/**
 * A simple typed list.
 *
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class XMLElementList {

    /**
     * The list of elements
     */
    private ArrayList list = new ArrayList();

    /**
     * Create a new list
     */
    public XMLElementList() {
    }

    /**
     * Add an element to the list
     *
     * @param element The element to be added
     */
    public void add(XMLElement element) {
        list.add(element);
    }

    /**
     * Get the number of elements in the list
     *
     * @return The number of elements in the list
     */
    public int size() {
        return list.size();
    }

    /**
     * Get the element at a specified index
     *
     * @param i The index of the element
     * @return The element at the specified index
     */
    public XMLElement get(int i) {
        return (XMLElement) list.get(i);
    }

    /**
     * Check if this list contains the given element
     *
     * @param element The element to check for
     * @return True if the element is in the list
     */
    public boolean contains(XMLElement element) {
        return list.contains(element);
    }

    /**
     * Add all the elements in this list to another collection
     *
     * @param collection The collection the elements should be added to
     */
    public void addAllTo(Collection collection) {
        collection.addAll(list);
    }
}
