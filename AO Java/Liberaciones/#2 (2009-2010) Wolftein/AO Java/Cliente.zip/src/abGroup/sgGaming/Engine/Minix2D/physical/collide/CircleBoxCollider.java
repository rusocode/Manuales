/*
 * @(#)CircleBoxCollider.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical.collide;

import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.physical.Body;
import abGroup.sgGaming.Engine.Minix2D.physical.Contact;
import abGroup.sgGaming.Engine.Minix2D.physical.Shapes.Circle;

/**
 * A collider for circles hitting boxes, Circle = BodyA, Box = BodyB
 * 
 * The create() method is used as a factory incase this class should
 * ever become stateful.
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public strictfp class CircleBoxCollider extends BoxCircleCollider {

    /** The single instance of this collider to exist */
    private static CircleBoxCollider single = new CircleBoxCollider();

    /**
     * Get an instance of this collider
     *
     * @return The instance of this collider
     */
    public static CircleBoxCollider createCircleBoxCollider() {
        return single;
    }

    /**
     * Prevent construction
     */
    private CircleBoxCollider() {
    }

    /**
     * @see net.phys2d.raw.collide.Collider#collide(net.phys2d.raw.Contact[], net.phys2d.raw.Body, net.phys2d.raw.Body)
     */
    public int collide(Contact[] contacts, Body circleBody, Body boxBody) {
        int count = super.collide(contacts, boxBody, circleBody);

        // reverse the collision results by inverting normals
        // and projecting the results onto the circle
        for (int i = 0; i < count; i++) {
            Vector2f vec = Vector2f.scale(contacts[i].getNormal(), -1);
            contacts[i].setNormal(vec);

            Vector2f pt = Vector2f.sub(contacts[i].getPosition(), circleBody.getPosition());
            pt.Normalise();
            pt.Scale(((Circle) circleBody.getShape()).getRadius());
            pt.Add(circleBody.getPosition());
            contacts[i].setPosition(pt);
        }

        return count;
    }
}
