//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.Client.Foundation;

import abGroup.sgGaming.Games.Nylox.Client.Engine.Manager.VirtualState;
import abGroup.sgGaming.Minix2D.Foundation.Singleton;
import abGroup.sgGaming.Minix2D.Gui.Object.Button;
import abGroup.sgGaming.Minix2D.Gui.Object.MessageBox;
import abGroup.sgGaming.Minix2D.Gui.Object.Textbox;
import abGroup.sgGaming.Minix2D.Gui.Property.ActionTrigger;
import abGroup.sgGaming.Minix2D.Gui.System;
import abGroup.sgGaming.Minix2D.Networking.Message.Message;
import abGroup.sgGaming.Minix2D.Networking.UrlConnection;
import abGroup.sgGaming.Minix2D.Util.Tokenizer;

/**
 * This class define the virtual state of login into the master server.
 *
 * @author Agustin L. Alvarez
 */
public class vsClientLogin implements VirtualState {
    /** Language used by this vs **/
    private final static String GAME_LANGUAGE_ERROR = "GetLocaleID(SystemError)";
    private final static String GAME_LANGUAGE_LOGIN_LENGTH = "GetLocaleID(FoundationGameID9)";
    private final static String GAME_LANGUAGE_LOGIN_OFFLINE = "GetLocaleID(FoundationNetworkID1)";
    private final static String GAME_LANGUAGE_LOGIN_VERSION = "GetLocaleID(FoundationGameID11)";
    private final static String GAME_LANGUAGE_LOGIN_INCORRECT = "GetLocaleID(FoundationGameID10)";

    /** Misc constants **/
    private final static String GAME_VERSION = "1.0 Alpha 05510";
    private final static int MIN_LOGIN_LENGTH = 6;

    /** Url Constant **/
    private final static String GAME_CREDIT_URL = "http://www.nylox-online.com.ar/credit.html";
    private final static String GAME_HOWTOPLAY_URL = "http://www.nylox-online.com.ar/howtoplay.html";
    private final static String GAME_MASTER_SERVER = "http://www.nylox-online.com.ar";

    /** This boolean represent if the state need to continue **/
    private boolean pkFinish = false;
    /** this list is retrieved from the master server **/
    private String[] pkMasterServerData;

    /**
     * Constructor
     */
    public vsClientLogin( ) {
        createRuntimeControl( );
    }

    /**
     * @see abGroup. sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public String getStateName() {
        return "vsClientLogin";
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public void Execute(float virtualTimer) {
        // nothing to do in this state.
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public boolean hasNextState() {
        return true;
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public VirtualState getNextState() {
        return new vsClientServer( pkMasterServerData );
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public VirtualState getPrevState() {
        return null; // first game state
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public boolean isFinished() {
        return pkFinish;
    }
    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public void parseMessage(Message c) {
        return;
    }
    /**
     * Create the runtime controls for the state.
     */
    private void createRuntimeControl() {
        System g = Singleton.GetEngine().GetUserSystem();
        ((Button)g.ControlRetrieve("btnLogin")).SetCallback(actionLogin);
        ((Button)g.ControlRetrieve("btnCredit")).SetCallback(actionCredit);
        ((Button)g.ControlRetrieve("btnHowToUse")).SetCallback(actionHowToUse);
    }
    /**
     * Build the login packet that is sended to the master server.
     * 
     * @param login The login name.
     * @param password the password of the user.
     * @return The built in packet constructed
     */
    private String builLoginPacket( String login, String password ) {
        return String.format("u=%s&p=%s&v=%s", login, password, GAME_VERSION );
    }
    /**
     * @Callback -> #btnLogin
     * @description Login the client into the master server.
     */
    private ActionTrigger actionLogin = new ActionTrigger( ) {
        public void ActionCallback() {
            System g = Singleton.GetEngine().GetUserSystem();
            // Retrieve the controls that have the login and password
            Textbox login    = (Textbox)g.ControlRetrieve("tbLogin");
            Textbox password = (Textbox)g.ControlRetrieve("tbPassword");
            // Check for the size of the login/password
            if( login.GetText().length() < MIN_LOGIN_LENGTH || password.GetText().length() < MIN_LOGIN_LENGTH ) {
                ((MessageBox)g.ControlRetrieve("msgBoxCustom")).Show( 320, 320, GAME_LANGUAGE_ERROR, GAME_LANGUAGE_LOGIN_LENGTH);
                return;
            }
            // Login into the master server
            UrlConnection masterServer = new UrlConnection(GAME_MASTER_SERVER);
            if( masterServer.Post("validation.php?type=login", builLoginPacket( login.GetText(), password.GetText() ) ) == false ) {
                // Offline master server.
                ((MessageBox)g.ControlRetrieve("msgBoxCustom")).Show( 320, 320, GAME_LANGUAGE_ERROR, GAME_LANGUAGE_LOGIN_OFFLINE );
                return;
            }
            // Check if we are logged into the server
            String postData = masterServer.GetBuffer().toString();
            if( postData.contains("Version Mismatch") ) {
                // Version is old
                ((MessageBox)g.ControlRetrieve("msgBoxCustom")).Show( 320, 320, GAME_LANGUAGE_ERROR, GAME_LANGUAGE_LOGIN_VERSION );
                return;
            } else if( postData.contains("Login Failed") ) {
                // Login or password incorrect
                ((MessageBox)g.ControlRetrieve("msgBoxCustom")).Show( 320, 320, GAME_LANGUAGE_ERROR, GAME_LANGUAGE_LOGIN_INCORRECT );
                return;
            } else {
                // We are logged into the master server :)
                pkMasterServerData = new String[Tokenizer.Count(postData, "<br>")];
                // Retrieve all the data that the master server send us.
                for( int i = 0; i < pkMasterServerData.length; i++ ) {
                    pkMasterServerData[i] = Tokenizer.Tokenize(postData, i, "<br>");
                }
                // End this state and start the next state (vsClientServer)
                pkFinish = true;
            }
        }
    };
    /**
     * @Callback -> #btnCredit
     * @description Show the game credits.
     */
    private ActionTrigger actionCredit = new ActionTrigger( ) {
        public void ActionCallback() {
            Singleton.GetDevice().OpenURL(GAME_CREDIT_URL);
        }
    };
    /**
     * @Callback -> #btnHowToUse
     * @description Show the game how to use option.
     */
    private ActionTrigger actionHowToUse = new ActionTrigger( ) {
        public void ActionCallback() {
            Singleton.GetDevice().OpenURL(GAME_HOWTOPLAY_URL);
        }
    };
}
