/*
 * @(#)FileSystemStreamFile.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.util.filesystem;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class FileSystemStreamFile implements FileSystemStream {

    /** This is the path of the file system **/
    private String fsPath;

    public FileSystemStreamFile(String path) {
        fsPath = path;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.util.filesystem.FileSystemStream#create(java.lang.String) 
     */
    public void create(String path) throws IOException {
        File javaFile = new File(fsPath + path);
        javaFile.createNewFile();
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.util.filesystem.FileSystemStream#load(java.lang.String)
     */
    public byte[] load(String filename) throws IOException {
        // Connect the file to the stream.
        File fileNative = new File(fsPath + filename);
        // Open the input stream.
        DataInputStream fileStream = new DataInputStream(new FileInputStream(fileNative));
        // Read the bytes from the input stream.
        byte[] inputBytes = new byte[fileStream.available()];
        fileStream.read(inputBytes, 0, fileStream.available());
        fileStream.close();
        // Return the loaded bytes.
        return inputBytes;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.util.filesystem.FileSystemStream#open(java.lang.String)
     */
    public DataInputStream open(String filename) throws IOException {
        // Connect the file to the stream.
        File fileNative = new File(fsPath + filename);
        // Open the input stream.
        DataInputStream fileStream = new DataInputStream(new FileInputStream(fileNative));
        // Return the Stream
        return fileStream;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.util.filesystem.FileSystemStream#getFileList(java.lang.String)
     */
    public String[] getFileList(String path) {
        // Open the Directory
        File f = new File(fsPath + path);
        // Get The File List.
        return f.list();
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.util.filesystem.FileSystemStream#retrieve(java.lang.String)
     */
    public DataOutputStream retrieve(String filename) throws IOException {
        // Connect the file to the stream.
        File fileNative = new File(fsPath + filename);
        // Create if it doesnt exist
        if (fileNative.exists() == false) {
            fileNative.createNewFile();
        }
        // Open the output stream.
        DataOutputStream fileStream = new DataOutputStream(new FileOutputStream(fileNative));
        // return the output stream.
        return fileStream;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.util.filesystem.FileSystemStream#check(java.lang.String)
     */
    public boolean check(String filename) {
        return new File(fsPath + filename).exists();
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.util.filesystem.FileSystemStream#delete(java.lang.String)
     */
    public void delete(String filename) {
        new File(fsPath + filename).delete();
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.util.filesystem.FileSystemStream#getLocalPath()
     */
    public String getLocalPath() {
        return fsPath;
    }
}
