/*
 * @(#)Shader.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.device;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public abstract class Shader {

    protected String name;

    /**
     * Constructor.
     *
     * @param name
     */
    protected Shader(String name) {
        this.name = name;
    }

    /**
     * @return The shader name.
     */
    public String getName() {
        return name;
    }


    public abstract int getUniformVariable( String variable );
    public abstract void setUniform1fARB( int variable, float a );
    public abstract void setUniform2fARB( int variable, float a, float b );
    public abstract void setUniform3fARB( int variable, float a, float b, float c );
    public abstract void setUniform4fARB( int variable, float a, float b, float c, float d );
    public abstract void setUniform1iARB( int variable, int a );
    public abstract void setUniform2iARB( int variable, int a, int b );
    public abstract void setUniform3iARB( int variable, int a, int b, int c );
    public abstract void setUniform4iARB( int variable, int a, int b, int c, int d );

    /**
     * Enable the shader for his use.
     */
    public abstract void enable();

    /**
     * Disable the use of this shader.
     */
    public abstract void disable();

    /**
     * Transform the shader file into a big string.
     *
     * @param in
     * @return
     * @throws IOException
     */
    protected String getDataFromStream(DataInputStream in) throws IOException {
        String readLine = "", retValue = "";
        while ((readLine = in.readLine()) != null) {
            retValue += readLine + "\n";
        }
        return retValue;
    }

    /**
     * Convert a string data into a buffer for the shader.
     *
     * @param str
     * @return
     */
    protected ByteBuffer getDataIntoByteBuffer(String str) {
        ByteBuffer buffer = ByteBuffer.allocateDirect(str.length());
        try {
            buffer.put(str.getBytes("US-ASCII"));
        } catch (UnsupportedEncodingException e) {
            return null;
        }
        buffer.flip();
        return buffer;
    }
}
