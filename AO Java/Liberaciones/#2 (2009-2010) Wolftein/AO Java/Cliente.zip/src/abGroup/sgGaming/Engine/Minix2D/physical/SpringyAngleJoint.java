/*
 * @(#)SpringyAngleJoint.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical;

import abGroup.sgGaming.Engine.Minix2D.math.Matrix2f;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;

/**
 * A joint providing a springy resistance between bodies. Wiring a series together
 * gives an effective bopper spring. 
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public class SpringyAngleJoint implements Joint {

    /** Anchor point for first body, on which impulse is going to apply*/
    private Vector2f anchor1;
    /** Anchor point for second body, on which impulse is going to apply*/
    private Vector2f anchor2;
    /** The first body jointed */
    private Body body1;
    /** The second body jointed */
    private Body body2;
    /** The constant that defines how springy the spring is */
    private float compressConstant;
    /** the original angle to attempt to maintain between the bodies - this may be varied by the spring */
    private float originalAngle;

    /**
     * Create a new joint
     *
     * @param body1	The first body to be attached on constraint
     * @param body2 The second body to be attached on constraint
     * @param anchor1 The anchor point on first body
     * @param anchor2 The anchor point on second body
     * @param compressConstant The constant k of hooke's law
     * @param originalAngle The original angle of the spring
     */
    public SpringyAngleJoint(Body body1, Body body2, Vector2f anchor1,
            Vector2f anchor2, float compressConstant, float originalAngle) {
        this.body1 = body1;
        this.body2 = body2;
        this.anchor1 = anchor1;
        this.anchor2 = anchor2;
        this.compressConstant = compressConstant;
        this.originalAngle = originalAngle;
    }

    /**
     * @see net.phys2d.raw.Joint#applyImpulse()
     */
    public void applyImpulse() {
    }

    /**
     * @see net.phys2d.raw.Joint#getBody1()
     */
    public Body getBody1() {
        return body1;
    }

    /**
     * @see net.phys2d.raw.Joint#getBody2()
     */
    public Body getBody2() {
        return body2;
    }

    /**
     * @see net.phys2d.raw.Joint#preStep(float)
     */
    public void preStep(float invDT) {
        Matrix2f rot1 = new Matrix2f(body1.getRotation());
        Matrix2f rot2 = new Matrix2f(body2.getRotation());
        Vector2f r1 = Vector2f.mul(rot1, anchor1);
        Vector2f r2 = Vector2f.mul(rot2, anchor2);

        Vector2f p1 = new Vector2f(body1.getPosition());
        p1.Add(r1);
        Vector2f p2 = new Vector2f(body2.getPosition());
        p2.Add(r2);
        Vector2f dp = new Vector2f(p2);
        dp.Sub(p1);
        float length = dp.length();
        // dp.scale(1.0f/length);
        Vector2f V = new Vector2f((float) Math.cos(originalAngle + body1.getRotation()), (float) Math.sin(originalAngle + body1.getRotation()));
        Vector2f ndp = new Vector2f(dp);
        ndp.Normalise();
        float torq = (float) Math.asin(Vector2f.cross(ndp, V)) * compressConstant / invDT;
        float P = torq / length;
        Vector2f n = new Vector2f(ndp.y, -ndp.x);
        Vector2f impulse = new Vector2f(n);
        impulse.Scale(P);
        if (!body1.isStatic()) {
            Vector2f accum1 = new Vector2f(impulse);
            accum1.Scale(body1.getInvMass());
            body1.adjustVelocity(accum1);
            body1.adjustAngularVelocity((body1.getInvI() * Vector2f.cross(dp,
                    impulse)));
        }
        if (!body2.isStatic()) {
            Vector2f accum2 = new Vector2f(impulse);
            accum2.Scale(-body2.getInvMass());
            body2.adjustVelocity(accum2);
            body2.adjustAngularVelocity(-(body2.getInvI() * Vector2f.cross(r2,
                    impulse)));
        }
    }

    /**
     * @see net.phys2d.raw.Joint#setRelaxation(float)
     */
    public void setRelaxation(float relaxation) {
    }
}
