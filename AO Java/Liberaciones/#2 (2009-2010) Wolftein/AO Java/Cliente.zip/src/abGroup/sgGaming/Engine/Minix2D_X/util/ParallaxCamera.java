/*
 * @(#)ParallaxCamera.java	1.0 Feb 7, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D_X.util;

import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.util.Camera;
import abGroup.sgGaming.Engine.Minix2D.util.Spatial;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 7, 2010
 * @since
 */
public class ParallaxCamera extends Camera {

    protected Vector2f spatialSize;
    protected Vector2f putSize;

    /**
     * Apply the spatial effect.
     *
     * @param t
     */
    @Override
    public void applyPreSpatialRender( Graphics2D g, Spatial t ) {
        // Rotate the view for a parallax isometric view.
        //g.rotate(45.0f);
        // set the size to (width,width/2)
        spatialSize = t.getSize();
        putSize = new Vector2f(spatialSize);
        putSize.y = (putSize.y / 2.1f);
        t.setSize(putSize);
    }

    @Override
    public void applyPostSpatialRender( Graphics2D g, Spatial t) {
        t.setSize(spatialSize);
    }

}
