/*
 * @(#)ImageLoader.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.device;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class ImageLoader {

    /**  The table of textures that have been loaded in this loader */
    protected Map<String, Image> cacheTexture;

    /** The processing textures **/
    protected ArrayList<Image> loadingTextureList;
    protected Map<Image, ImageObserver> loadingTexture;

    /**
     * Constructor
     */
    public ImageLoader() {
        cacheTexture = new ConcurrentHashMap<String, Image>();
        loadingTextureList = new ArrayList<Image>( );
        loadingTexture = new ConcurrentHashMap<Image, ImageObserver>();
    }

    /**
     * Check for the finished loading textures.
     */
    public void checkLoaderObservers() {
        Iterator<Image> it = ((ArrayList<Image>)loadingTextureList.clone()).iterator();

        while (it.hasNext()) {
            // get the image source.
            Image image = it.next();
            // get the observer of the image.
            ImageObserver observer = loadingTexture.get(image);
            // check for finished texture.
            if (observer.isLoadingFinished() == true) {
                // take it from the list.
                loadingTextureList.remove(image);
                loadingTexture.remove(image);
                // check if we load the texture succesfull.
                if (observer.isTextureLoaded() == true) {
                    image = createTexture(observer);
                    // update the image change
                    cacheTexture.put(image.filename, image);
                }
            }
        }
    }

    protected Image createTexture(ImageObserver ov) {
        return null;
    }

    public Image createImageData( int width, int height ) {
        return null;
    }

    public Image createImage( int width, int height ) {
        return null;
    }

    public void convertBufferedImage(BufferedImage bufferedimage, Image image) {
        return;
    }

    public Image getImage(String image) {
        // first check the cache.
        if (cacheTexture.containsKey(image)) {
            return cacheTexture.get(image);
        }
        return null;
    }

}
