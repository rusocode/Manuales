/*
 * @(#)Box.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical.Shapes;

import abGroup.sgGaming.Engine.Minix2D.math.Matrix2f;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;



/**
 * A simple box in the engine - defined by a width and height
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public strictfp class Box extends AbstractShape implements DynamicShape {

    /** The size of the box */
    private Vector2f size = new Vector2f();

    /**
     * Create a box in the simulation
     *
     * @param width The width of a box
     * @param height The hieght of the box
     */
    public Box(float width, float height) {
        super();
        size.Set(width, height);
        bounds = new AABox(size.length(), size.length());
    }

    /**
     * Get the size of this box
     *
     * @return The size of this box
     */
    public Vector2f getSize() {
        return size;
    }

    /**
     * @see net.phys2d.raw.shapes.Shape#getSurfaceFactor()
     */
    public float getSurfaceFactor() {
        float x = size.GetX();
        float y = size.GetY();

        return (x * x + y * y);
    }

    /**
     * Get the current positon of a set of points
     *
     * @param pos The centre of the box
     * @param rotation The rotation of the box
     * @return The points building up a box at this position and rotation
     */
    public Vector2f[] getPoints(Vector2f pos, float rotation) {
        Matrix2f R = new Matrix2f(rotation);
        Vector2f[] pts = new Vector2f[4];
        Vector2f h = Vector2f.scale(getSize(), 0.5f);

        pts[0] = Vector2f.mul(R, new Vector2f(-h.GetX(), -h.GetY()));
        pts[0].Add(pos);
        pts[1] = Vector2f.mul(R, new Vector2f(h.GetX(), -h.GetY()));
        pts[1].Add(pos);
        pts[2] = Vector2f.mul(R, new Vector2f(h.GetX(), h.GetY()));
        pts[2].Add(pos);
        pts[3] = Vector2f.mul(R, new Vector2f(-h.GetX(), h.GetY()));
        pts[3].Add(pos);

        return pts;
    }
}
