//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.CSprite;

import abGroup.sgGaming.Games.Nylox.Client.Engine.Manager.SpriteDataClass;
import abGroup.sgGaming.Minix2D.Foundation.Engine;
import abGroup.sgGaming.Minix2D.Foundation.Engine.Library;
import abGroup.sgGaming.Minix2D.Foundation.Singleton;
import abGroup.sgGaming.Minix2D.Gui.Object.Button;
import abGroup.sgGaming.Minix2D.Gui.Object.Canvas;
import abGroup.sgGaming.Minix2D.Gui.Object.Label;
import abGroup.sgGaming.Minix2D.Gui.Property.ActionTrigger;
import abGroup.sgGaming.Minix2D.Renderer.Device;
import abGroup.sgGaming.Minix2D.Renderer.DeviceListener;
import abGroup.sgGaming.Minix2D.Renderer.Font;
import abGroup.sgGaming.Minix2D.Renderer.Render2D;
import abGroup.sgGaming.Minix2D.Renderer.Render2D.AlphaBlending;
import abGroup.sgGaming.Minix2D.Util.Debug.Debug;
import abGroup.sgGaming.Minix2D.Util.FileSystem.BinaryStreamFile;
import abGroup.sgGaming.Minix2D.Util.FileSystem.Resource;
import abGroup.sgGaming.Minix2D.Util.Xml.XMLElement;
import abGroup.sgGaming.Minix2D.Util.Xml.XMLParser;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Calendar;

/**
 *
 * @author Agustin L. Alvarez
 */
public class CSpriteApplication implements DeviceListener {

    /** Enviroment path */
    public final static String ENVIROMENT_PATH = "abGroup/sgGaming/Games/Nylox/CSprite/Resource/";
    /** Engine Minix */
    private Engine pkEngine;
    /** Default Things */
    private int pkTargetSize = 0;
    private int pkTargetCurrent = 0;
    private boolean pkStarted = false;
    private String pkSaveFile;

    /**
     * Constructor
     */
    public CSpriteApplication( boolean autoStart ) {
        pkStarted = autoStart;
        pkEngine = new Engine( Library.Lwjgl, null, "CSprite", 640, 480, false, false, false );
        pkEngine.SetRenderer(this);
        pkEngine.Run();
    }

    /**
     * @see abGroup.sgGaming.Minix2D.Renderer.DeviceListener
     */
    public void Initialize(Device c, Render2D g) {
        try {
            g.SetAlphaBlending(AlphaBlending.SOURCE_ALPHA);
            LoadProperty();
        } catch (Exception ex) {
            Debug.Print("CSprite@Initialize Failed %s", ex.getMessage());
        }
    }
    /**
     * @see abGroup.sgGaming.Minix2D.Renderer.DeviceListener
     */
    public void Render( Render2D g ) {

    }

    /**
     * @see abGroup.sgGaming.Minix2D.Renderer.DeviceListener
     */
    public void Logical(float deltaTime) {
        // Update the parser
        if (pkStarted == true) {
            if (SpriteParser.Finish() == false) {
                pkTargetCurrent = SpriteParser.Next();
                // Update Label
                ((Label) pkEngine.GetUserSystem().ControlRetrieve("lblStatus")).SetCaption(pkTargetCurrent + "/" + pkTargetSize + " Files Parsed");
            } else {
                // Save the file
                Save(pkSaveFile);
                // Change the user see result
                ((Label) pkEngine.GetUserSystem().ControlRetrieve("lblStatus")).SetCaption("Finished");
                ((Label) pkEngine.GetUserSystem().ControlRetrieve("lblStatus")).SetColor(0.0f, 1.09f, 0.09f, 1.0f);
                // Exit the Application
                this.pkEngine.Close();
            }
        }
    }

    /**
     * @see abGroup.sgGaming.Minix2D.Renderer.DeviceListener
     */
    public boolean CloseRequest() {
        return true;
    }

    /**
     * Load all the application property
     *
     * @throws Exception
     */
    public void LoadProperty() throws Exception {
        // Add the global path
        Resource.Add("Sprite/", new BinaryStreamFile());
        // Parse The Xml Property
        XMLParser parser = new XMLParser();
        XMLElement root = parser.parse(ENVIROMENT_PATH + "Configuration.xml");
        Font.Parse(root.getChildrenByName("fontmanager").get(0));
        pkEngine.GetUserSystem().Parse(root.getChildrenByName("interface").get(0));
        // custom property.
        XMLElement child = root.getChildrenByName("custom").get(0);
        pkSaveFile = child.getChildrenByName("Directory").get(0).getAttribute("Save");
        // Load Each Sprite.
        SpriteSearch.Search(child.getChildrenByName("Directory").get(0).getAttribute("Recursive"));
        // Set Default interface implementation
        pkTargetSize = SpriteSearch.GetSpriteList().length;
        ((Label) pkEngine.GetUserSystem().ControlRetrieve("lblStatus")).SetCaption("0/" + pkTargetSize + " Files Parsed");
        ((Button) pkEngine.GetUserSystem().ControlRetrieve("startButton")).SetCallback(new ActionTrigger() {

            public void ActionCallback() {
                if (pkStarted == true) {
                    ((Button) pkEngine.GetUserSystem().ControlRetrieve("startButton")).SetCaption("Start");
                    pkStarted = false;
                } else {
                    ((Button) pkEngine.GetUserSystem().ControlRetrieve("startButton")).SetCaption("Pause");
                    pkStarted = true;
                }
            }
        });
        SpriteParser.Parser(SpriteSearch.GetSpriteList());
        ((Canvas) pkEngine.GetUserSystem().ControlRetrieve("cvViewer")).SetCallback(new ActionTrigger() {

            public void ActionCallback() {
                String foo = SpriteParser.GetSpriteImage(pkTargetCurrent - 1);
                if (foo != null && SpriteParser.Finish() == false) {
                    Singleton.GetRender2D().Render(foo, 0, 0);
                }
            }
        });
    }

    /**
     * @return The calculation of the version thought the date.
     */
    private int CalculateVersionDate() {
        return Calendar.getInstance().get(Calendar.DAY_OF_YEAR) * Calendar.getInstance().get(Calendar.YEAR) +
               Calendar.getInstance().get(Calendar.DAY_OF_WEEK_IN_MONTH) * Calendar.getInstance().get(Calendar.MILLISECOND);
    }

    /**
     * This function is called when the game is initialized. Load every sprite in the game.
     *
     * @return TRUE if we initialize good.
     */
    private void Save(String Filename) {
        try {
            // Open the path for debug save.
            DataOutputStream indexOut = Resource.Retrieve(Resource.GetLocalDirectory(), "index.txt" );
            // Open the path for save.
            DataOutputStream out = Resource.Retrieve(Resource.GetLocalDirectory(), Filename);
            // The Version of the File and the count of sprite.
            indexOut.writeBytes("CSprite $" + String.valueOf(CalculateVersionDate()) + "$ Version\n");
            indexOut.writeBytes("----------------------------------\n");
            out.writeUTF( "CSprite $" + String.valueOf(CalculateVersionDate()) + "$ Version" );
            out.writeInt( SpriteParser.GetSpriteCount() );
            // List of Sprites
            SpriteDataClass[] list = SpriteParser.GetSpriteList();
            // Save each Sprite.
            for (int i = 0; i < SpriteParser.GetSpriteCount(); i++) {
                // Insert the number and the frame lenght
                out.writeByte( (byte)list[i].pkSprite.length );
                // if has animation the add the animations.
                if (list[i].pkSprite.length > 0) {
                    // Add each index.
                    for (int j = 0; j < list[i].pkSprite.length; j++) {
                        out.writeInt( list[i].pkSprite[j] );
                    }
                    // Add the frame speed
                    out.writeFloat( list[i].pkSpeed );
                }
                // Normalize the name, only debug name work the #
                int index = list[i].pkFilename.indexOf("#");
                if( index == -1 ) index = list[i].pkFilename.length();
                // add the sprite property
                out.writeUTF( list[i].pkFilename.substring(0, index) );
                out.writeShort( list[i].pkSourceX );
                out.writeShort( list[i].pkSourceY );
                out.writeShort( list[i].pkSourceWidth );
                out.writeShort( list[i].pkSourceHeight );
                // index print.
                indexOut.writeBytes(String.format("Sprite[%d]= %s\n", i, list[i].pkFilename));
            }
            indexOut.writeBytes("----------------------------------\n");
            // Parse head sprites.
            int[][] subList = SpriteParser.GetHeadList();
            out.writeInt( subList.length );
            for( int i = 0; i < subList.length; i++ ) {
                out.writeInt( subList[i][0] );
                out.writeInt( subList[i][1] );
                out.writeInt( subList[i][2] );
                out.writeInt( subList[i][3] );
                // index print.
                indexOut.writeBytes(String.format("Head[%d]= %s %s %s %s\n", i, list[subList[i][0]].pkFilename,
                                                list[subList[i][1]].pkFilename, list[subList[i][2]].pkFilename,
                                                list[subList[i][3]].pkFilename));
            }
            indexOut.writeBytes("----------------------------------\n");
            // Parse body sprites.
            subList = SpriteParser.GetBodyList();
            out.writeInt( subList.length );
            for( int i = 0; i < subList.length; i++ ) {
                out.writeInt( subList[i][0] );
                out.writeInt( subList[i][1] );
                out.writeInt( subList[i][2] );
                out.writeInt( subList[i][3] );
                out.writeInt( subList[i][4] );
                out.writeInt( subList[i][5] );
                // index print.
                indexOut.writeBytes(String.format("Body[%d]= %s %s %s %s %d %d\n", i, list[subList[i][0]].pkFilename,
                                                list[subList[i][1]].pkFilename, list[subList[i][2]].pkFilename,
                                                list[subList[i][3]].pkFilename, subList[i][4], subList[i][5]));
            }
            indexOut.writeBytes("----------------------------------\n");
            // Parse hand sprites.
            subList = SpriteParser.GetHandList();
            out.writeInt( subList.length );
            for( int i = 0; i < subList.length; i++ ) {
                out.writeInt( subList[i][0] );
                out.writeInt( subList[i][1] );
                out.writeInt( subList[i][2] );
                out.writeInt( subList[i][3] );
                // index print.
                indexOut.writeBytes(String.format("Weapon/Shield[%d]= %s %s %s %s\n", i, list[subList[i][0]].pkFilename,
                                                list[subList[i][1]].pkFilename, list[subList[i][2]].pkFilename,
                                                list[subList[i][3]].pkFilename));
            }
            // Copy
            out.flush();
            out.close();
            indexOut.flush();
            indexOut.close();
        } catch (IOException ex) {
            Debug.Print("Error Saving the file: %s", ex.getMessage());
        }
    }

}