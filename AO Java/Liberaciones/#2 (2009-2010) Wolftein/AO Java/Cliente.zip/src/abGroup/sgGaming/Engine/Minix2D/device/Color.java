/*
 * @(#)Color.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.device;

import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLException;
import java.util.StringTokenizer;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class Color {

    /** Default Color implementation. */
    public static Color Red = new Color(1.0f, 0.0f, 0.0f, 1.0f);
    public static Color LightRed = new Color(1.0f, 0.5f, 0.5f, 1.0f);
    public static Color DarkRed = new Color(0.54f, 0.0f, 0.0f, 1.0f);
    public static Color Green = new Color(0.0f, 1.0f, 0.0f, 1.0f);
    public static Color LightGreen = new Color(0.5f, 1.0f, 0.5f, 1.0f);
    public static Color DarkGreen = new Color(0.0f, 0.54f, 0.0f, 1.0f);
    public static Color Blue = new Color(0.0f, 0.0f, 1.0f, 1.0f);
    public static Color LightBlue = new Color(0.5f, 0.5f, 1.0f, 1.0f);
    public static Color DarkBlue = new Color(0.0f, 0.0f, 0.54f, 1.0f);
    public static Color Yellow = new Color(1.0f, 1.0f, 0.0f, 1.0f);
    public static Color Cyan = new Color(0.0f, 1.0f, 1.0f, 1.0f);
    public static Color Pink = new Color(1.0f, 0.6862f, 0.6862f, 1.0f);
    public static Color Magenta = new Color(1.0f, 0.0f, 1.0f, 1.0f);
    public static Color White = new Color(1.0f, 1.0f, 1.0f, 1.0f);
    public static Color Black = new Color(0.0f, 0.0f, 0.0f, 1.0f);
    public static Color Gray = new Color(0.5019f, 0.5019f, 0.5019f, 0.5019f);

   /**
     * Array of the colors
     */
    public float[] colorArray;

    /**
     * Constructor
     */
    public Color() {
        this(1.0f, 1.0f, 1.0f, 1.0f);
    }

    /**
     * Constructor
     *
     * @param Red
     * @param Green
     * @param Blue
     * @param Alpha
     */
    public Color(float Red, float Green, float Blue, float Alpha) {
        colorArray = new float[]{Red, Green, Blue, Alpha};
    }

    /**
     * Constructor clone.
     *
     * @param c
     */
    public Color( Color c ) {
        this(c.colorArray[0],c.colorArray[1],c.colorArray[2],c.colorArray[3]);
    }

    /**
     * @see abGroup.sgGaming.Minix2D.Util.Serializable.Serializable
     */
    public static Color parseOf(XMLElement element) throws XMLException {
        StringTokenizer token = new StringTokenizer(element.getAttribute("Color"), ",");
        return new Color(Float.parseFloat(token.nextToken()), Float.parseFloat(token.nextToken()),
                Float.parseFloat(token.nextToken()), Float.parseFloat(token.nextToken()));
    }

    /**
     * Parse a color from a string.
     *
     * @param string
     * @return
     */
    public static Color parseOf(String string) {
        StringTokenizer parser = new StringTokenizer(string, ",");
        if (parser.countTokens() != 4) {
            throw new RuntimeException("Error parsing a Color, invalid data.");
        }
        return new Color(Float.parseFloat(parser.nextToken()), Float.parseFloat(parser.nextToken()),
                Float.parseFloat(parser.nextToken()), Float.parseFloat(parser.nextToken()));
    }

    /**
     * bind the current color for rendering.
     */
    public void bind() {

    }

}
