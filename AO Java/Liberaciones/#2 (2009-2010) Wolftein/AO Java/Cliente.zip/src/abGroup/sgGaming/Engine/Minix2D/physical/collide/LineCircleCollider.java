/*
 * @(#)LineCircleCollider.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical.collide;

import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.physical.Body;
import abGroup.sgGaming.Engine.Minix2D.physical.Contact;
import abGroup.sgGaming.Engine.Minix2D.physical.Shapes.Circle;
import abGroup.sgGaming.Engine.Minix2D.physical.Shapes.Line;

/**
 * Collision routines betwene a circle and a line. The create method is
 * provided in case this collider becomes stateful at some point.
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public strictfp class LineCircleCollider implements Collider {

    /**
     * @see net.phys2d.raw.collide.Collider#collide(net.phys2d.raw.Contact[], net.phys2d.raw.Body, net.phys2d.raw.Body)
     */
    public int collide(Contact[] contacts, Body bodyA, Body bodyB) {
        Line line = (Line) bodyA.getShape();
        Circle circle = (Circle) bodyB.getShape();

        Vector2f[] vertsA = line.getVertices(bodyA.getPosition(), bodyA.getRotation());

        // compute intersection of the line A and a line parallel to
        // the line A's normal passing through the origin of B
        Vector2f startA = vertsA[0];
        Vector2f endA = vertsA[1];
        Vector2f startB = bodyB.getPosition();
        Vector2f endB = new Vector2f(endA);
        endB.Sub(startA);
        endB.Set(endB.y, -endB.x);
//		endB.add(startB);// TODO: inline endB into equations below, this last operation will be useless..

        //TODO: reuse Vector2f.intersect
//		float d = (endB.y - startB.getY()) * (endA.x - startA.x);
//		d -= (endB.x - startB.getX()) * (endA.y - startA.y);
//		
//		float uA = (endB.x - startB.getX()) * (startA.y - startB.getY());
//		uA -= (endB.y - startB.getY()) * (startA.x - startB.getX());
//		uA /= d;
        float d = endB.y * (endA.x - startA.x);
        d -= endB.x * (endA.y - startA.y);

        float uA = endB.x * (startA.y - startB.GetY());
        uA -= endB.y * (startA.x - startB.GetX());
        uA /= d;

        Vector2f position = null;

        if (uA < 0) { // the intersection is somewhere before startA
            position = startA;
        } else if (uA > 1) { // the intersection is somewhere after endA
            position = endA;
        } else {
            position = new Vector2f(
                    startA.x + uA * (endA.x - startA.x),
                    startA.y + uA * (endA.y - startA.y));
        }

        Vector2f normal = endB; // reuse of vector object
        normal.Set(startB);
        normal.Sub(position);
        float distSquared = normal.LengthSquared();
        float radiusSquared = circle.getRadius() * circle.getRadius();

        if (distSquared < radiusSquared) {
            contacts[0].setPosition(position);
            contacts[0].setFeature(new FeaturePair());

            normal.Normalise();
            contacts[0].setNormal(normal);

            float separation = (float) Math.sqrt(distSquared) - circle.getRadius();
            contacts[0].setSeparation(separation);

            return 1;
        }

        return 0;
    }
}
