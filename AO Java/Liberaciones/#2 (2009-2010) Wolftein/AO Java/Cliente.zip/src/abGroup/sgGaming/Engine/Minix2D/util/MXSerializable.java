/*
 * @(#)MXSerializable.java	1.0 Feb 14, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.util;

import java.io.DataOutputStream;
import java.io.IOException;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 14, 2010
 * @since
 */
public interface MXSerializable {

    /**
     * Save the class into a data outputstream.
     * 
     * @param out
     * @throws IOException
     */
    public void save( DataOutputStream out ) throws IOException;

}
