/*
 * @(#)SoundManager.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.soundmanager;

import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public abstract class SoundManager {

    protected static enum soundFormat {
        MONO8, STEREO8,
        MONO16, STEREO16
    };


    protected float playerGain = 1.0f;
    protected float playerReferenceDistance = 0.5f;

    protected int soundSize = 0, soundBufferSize = 0, soundSourceSize = 0;
    protected int[] soundBuffer, sourceBuffer;


    protected SoundManager(int maxSoundSize) {
        soundBuffer = new int[maxSoundSize];
        sourceBuffer = new int[maxSoundSize];
        soundSize = maxSoundSize;
    }

    /**
     * @see java.lang.Object
     */
    @Override
    protected void finalize() throws Throwable {
        // stop all sounds
        for (int i = 0; i < soundSourceSize; i++) {
            stop(sourceBuffer[i]);
            deleteSoundSource(sourceBuffer[i]);
        }
        // delete buffers and sources
        for (int i = 0; i < soundSize; i++) {
            deleteSoundData(soundBuffer[i]);
        }
        destroyContext();
    }

    protected abstract void destroyContext();

    /**
     * Pause or resume all sounds playing in the Loader
     *
     * @param bool
     */
    public void pause(boolean bool) {
        for (int i = 0; i < soundSourceSize; i++) {
            pause(sourceBuffer[i], bool);
        }
    }

    /**
     * Stop all sounds playing in the Loader
     */
    public void stop() {
        for (int i = 0; i < soundSourceSize; i++) {
            stop(sourceBuffer[i]);
        }
    }

    /**
     * Set the volume for all sounds.  Use this to adjust ambient volume
     * level for entire SoundPlayer.
     *
     * @param gain  float: 0 - 1
     */
    public void setGlobalGain(float gain) {
        if (gain != playerGain) {
            if (gain > 1) {
                gain = 1;
            } else if (gain < 0) {
                gain = 0;
            }
            playerGain = gain;
            for (int i = 0; i < soundSourceSize; i++) {
                setGain(sourceBuffer[i], getGain(sourceBuffer[i]) + playerGain);
            }
        }
    }

    /**
     * Set the reference distance, used by OpenAL to calculate how fast sound
     * drops off.  This distance should be proportional to the size of your
     * scene, ie. a scene that is hundreds of units wide might have a
     * reference distance of 10 for a "small" sound, or 100 for a "big" sound
     * that fills the whole space.
     * <P>
     * @see makeSoundSource().
     */
    public void setReferenceDistance(float d) {
        playerReferenceDistance = d;
    }

    /**
     * Set world coordinates of listener.
     *
     * @param x
     * @param y
     * @param z
     */
    public abstract void setListenerPosition(float x, float y, float z);

    /**
     * Set world Velocity of listener.
     *
     * @param x
     * @param y
     * @param z
     */
    public abstract void setListenerVelocity(float x, float y, float z);

    /**
     *  Set orientation of the listener.
     *  first 3 elements are "at", second 3 are "up"
     *
     * @param lookatx
     * @param lookaty
     * @param lookatz
     * @param upx
     * @param upy
     * @param upz
     */
    public abstract void setListenerOrientation(float lookatx, float lookaty, float lookatz, float upx, float upy, float upz);

    public abstract void pause( int sound, boolean value );
    public abstract void play( int sound );
    public abstract void stop( int sound );

    /**
     * Obtain the GainVolumen of a sound.
     *
     * @param soundSourceHandle
     * @return
     */
    public abstract float getGain(int sound);
    /**
     * Set velocity of sound 0 - 1
     *
     * @param sound
     * @param velocity
     */
    public abstract void setVelocity(int sound, float velocity);
    /**
     * Set the velocity of the soundClip
     *
     * @param sound  set pitch of this sound source
     * @param pitch
     */
    public abstract void setPitch(int sound, float pitch);
    /**
     * Set the SoundPlayer volume.  Gain range is 0.0 or above.
     * A value of 1.0 means unattenuated/unchanged.
     * Each division by 2 equals an attenuation of -6dB.
     * Each multiplication by 2 equals an amplification of +6dB.
     * A value of 0.0 turns sound off.
     *
     * @param sound
     * @param gain
     */
    public abstract void setGain(int sound, float gain);
    /**
     * Set the position of a Sound in a 3D Enviroment
     *
     * @param sound
     * @param x
     * @param y
     * @param z
     */
    public abstract void setSoundPosition(int sound, float x, float y, float z);
    /**
     * set the dropoff distance for this sound.  this number controls how far the
     * sound travels.  The distance parameter should be proportional to the units of
     * distance used in the scene.
     *
     * <P>
     * @param sound
     * @param distance
     */
    public abstract void setReferenceDistance(int sound, float distance);
    /**
     * Set A Sound to play Looped
     *
     * @param sound
     * @param on
     */
    public abstract void setLoop(int sound, boolean on);
    /**
     * return true if this sound is playing
     *
     * @param sound
     * @return true if sound is playing
     */
    public abstract boolean isPlaying(int sound);
    /**
     * Return integer handle to new sound source.  Expects a handle to a
     * loaded sound data buffer (see loadSoundData()).  Multiple sound sources
     * can share the same data buffer.  Each sound source can have a position,
     * pitch, velocity that will affect the way the sound plays.
     *
     * @return
     */
    public abstract int makeSoundSource(int sound);
    /**
     * Return integer handle to allocated sound data buffer.
     *
     * @return
     */
    public abstract int allocateSoundData();
    /**
     * Delete the sound data buffer with the given handle
     *
     * @param sound
     */
    protected abstract void deleteSoundData(int sound);
    /**
     * Delete the sound source with the given handle
     *
     * @param sound
     */
    protected abstract void deleteSoundSource(int sound);

    protected abstract void generateBuffer(int sound, SoundInput in);

    protected SoundInput soundInputFactory( String filename ) {
        // get the bytes of the sound file.
        byte[] soundData = Runtime.getClassLoader().getResource(filename);
        // Check for witch type of File is
        if (filename.toUpperCase().endsWith(".WAV")) {
            return SoundInputWav.create(soundData);
        } else if( filename.toUpperCase().endsWith(".AIFF") || filename.toUpperCase().endsWith(".AIF") ) {
            return SoundInputAiff.create(soundData);
        } else if( filename.toUpperCase().endsWith(".OGG")) {
            return SoundInputOgg.create(soundData);
        }
        throw new RuntimeException("Sound format not supported");
    }

}
