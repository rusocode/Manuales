/*
 * @(#)JPopup.java	1.0 Feb 2, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.m2gui.controls;

import abGroup.sgGaming.Engine.Minix2D.device.Color;
import abGroup.sgGaming.Engine.Minix2D.device.Font;
import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.device.Image;
import abGroup.sgGaming.Engine.Minix2D.input.Mouse;
import abGroup.sgGaming.Engine.Minix2D.input.Mouse.MouseButton;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Control;
import abGroup.sgGaming.Engine.Minix2D.m2gui.ControlManager;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Drawable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Eventable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Mouseable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Regionable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Triggered;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.util.Timer;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLException;
import java.util.StringTokenizer;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 2, 2010
 * @since JDK 1.6
 */
public class JPopup extends Control implements Drawable, Mouseable, Regionable, Eventable {

    /** Type of popup **/
    public static enum popupType {

        DOWN,
        RIGHT
    };
    /** Popup variables **/
    protected String[] image = new String[2];
    protected JLabel caption;
    protected Triggered callback;
    protected JPopup owner;
    protected JPopup[] child;
    protected boolean hide = true;
    protected popupType type = popupType.RIGHT;
    protected long timeLast;
    protected boolean continueOver;

    /**
     * Constructor
     * 
     * @param x
     * @param y
     * @param f
     */
    public JPopup(int x, int y, Font f) {
        super("JPopup");
        setPosition(new Vector2f(x, y));
        caption = new JLabel(0, 0, f);
        caption.setAligment(Font.Aligment.Center);
    }

    /**
     * Constructor
     * 
     * @param element
     * @throws XMLException
     */
    public JPopup(XMLElement element) throws XMLException {
        this(0, 0, null);
        parse(element);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Control#parse(abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement) 
     */
    @Override
    public void parse(XMLElement element) throws XMLException {
        // Control parse native.
        super.parse(element);
        // JPicture propertys.
        String[] xmlProperty = element.getAttributeNames();
        String currentProperty;
        for (int i = 0; i < xmlProperty.length; i++) {
            currentProperty = xmlProperty[i].toUpperCase();
            if (currentProperty.equals("IMAGE")) {
                setImage(0, element.getAttribute("Image"));
            } else if (currentProperty.equals("ONIMAGE")) {
                setImage(1, element.getAttribute("OnImage"));
            } else if (currentProperty.equals("COLOR")) {
                setColor(Color.parseOf(element.getAttribute("Color")));
            } else if (currentProperty.equals("CAPTION")) {
                setCaption(element.getAttribute("Caption"));
            } else if (currentProperty.equals("TYPE")) {
                setType(type.valueOf(element.getAttribute("Type")));
           } else if (currentProperty.equals("FONT")) {
                setFont( Font.Retrieve(element.getAttribute("Font")));
            } else if (currentProperty.equals("CHILD")) {
                StringTokenizer f = new StringTokenizer(element.getAttribute("Child"), ",");
                JPopup[] list = new JPopup[f.countTokens()];
                for (int j = 0; j < f.countTokens(); j++) {
                    list[j] = (JPopup) Runtime.getKernel().getControlManager().getControl(f.nextToken());
                }
                setPopupList(list);
            }
        }
    }

    /**
     * Set the popup over texture.
     *
     * @param texture
     */
    public void setImage(int index, String texture) {
        image[index] = texture;
    }

    /**
     * Set popup font.
     *
     * @param f
     */
    public void setFont(Font f) {
        caption.setFont(f);
    }

    /**
     * Set the popup type.
     *
     * @param t
     */
    public void setType(popupType t) {
        type = t;
    }

    /**
     * Set the popup color.
     *
     * @param c
     */
    public void setColor(Color c) {
        caption.setColor(c);
    }

    /**
     * Set the popup caption.
     *
     * @param caption
     */
    public void setCaption(String caption) {
        this.caption.setCaption(caption);
    }

    /**
     * Set the popup callback.
     *
     * @param at
     */
    public void setAction(Triggered at) {
        callback = at;
    }

    /**
     * Set the next popup list.
     *
     * @param p
     */
    public void setPopupList(JPopup[] p) {
        child = p;
        // set the owner
        for (int i = 0; i < child.length; i++) {
            child[i].owner = this;
            child[i].setEnable(false);
        }
    }

    /**
     * Find if the popup is owner.
     *
     * @param c
     * @return
     */
    protected boolean isControlOwner(JPopup c) {
        if (c == this) {
            return true;
        }
        if (child != null) {
            // set the position
            for (int i = 0; i < child.length; i++) {
                if (child[i] == c || child[i].isControlOwner(c)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Hide this control and all sub child
     */
    protected void hideOwner() {
        continueOver = false;
        if (child != null) {
            // set the position
            for (int i = 0; i < child.length; i++) {
                child[i].setEnable(false);
                child[i].continueOver = false;
            }
        }
        this.setEnable(false);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Drawable#Drawable(abGroup.sgGaming.Engine.Minix2D.device.Graphics2D, int, int)
     */
    public void Drawable(Graphics2D g, int x, int y) {
        // Does we need to hide?
        if (child != null) {
            // Find if it's a sub child
            ControlManager c = Runtime.getKernel().getControlManager();
            if (!(c.getControlHover() instanceof JPopup)) {
                if (Timer.getMillisecondTime() - timeLast > 100) {
                    // set the position
                    for (int i = 0; i < child.length; i++) {
                        child[i].hideOwner();
                    }
                    hide = false;
                    continueOver = false;
                }
            } else if (isControlOwner((JPopup) c.getControlHover()) == true) {
                timeLast = Timer.getMillisecondTime();
            } else if (Timer.getMillisecondTime() - timeLast > 100) {
                // set the position
                for (int i = 0; i < child.length; i++) {
                    child[i].hideOwner();
                }
                hide = false;
                continueOver = false;
            }
        }
        // Render background.
        g.setColor(Color.White);
        Image imageClass = Runtime.getImageLoader().getImage(image[0]);
        if (continueOver == true && image[1] != null) {
            imageClass = Runtime.getImageLoader().getImage(image[1]);
        }
        g.drawImage(imageClass, x + this.x, y + this.y);
        // update dimension
        setSize(new Vector2f(imageClass.getWidth(), imageClass.getHeight()));
        // Render Font.
        caption.Drawable(g, this.x + x, this.y + y);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Mouseable
     */
    public void mouseMove(int dX, int dY, int rX, int rY) {
        return;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Mouseable
     */
    public void mouseButton(MouseButton button) {
        // Call the callback if it has.
        if (button == Mouse.MouseButton.BUTTON_LEFT && callback != null) {
            callback.callback();
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Mouseable
     */
    public void mouseWheel(int WheelNumber) {
        return;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Regionable
     */
    public void Enter() {
        continueOver = true;
        // has next popup?
        if (child != null) {
            // set the position
            for (int i = 0; i < child.length; i++) {
                // Type of popup
                if (type == popupType.RIGHT) {
                    child[i].setPosition(new Vector2f(this.x + this.width, this.y + (i * child[i].height)));
                } else if (type == popupType.DOWN) {
                    child[i].setPosition(new Vector2f(this.x, this.y + (i * child[i].height) + this.height));
                }
                child[i].setEnable(true);
            }
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Regionable
     */
    public void Exit() {
        timeLast = Timer.getMillisecondTime();
        continueOver = false;
    }
}
