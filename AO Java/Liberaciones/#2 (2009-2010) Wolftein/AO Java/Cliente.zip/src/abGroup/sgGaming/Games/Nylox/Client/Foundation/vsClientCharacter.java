//////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2008-2009, sgGaming inc.
// All rights reserved.
//
// Redistribution and use in source and binary forms, without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the copyright holder nor the names of any
//       contributors may be used to endorse or promote products derived from
//       this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "A@B G"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

package abGroup.sgGaming.Games.Nylox.Client.Foundation;

import abGroup.sgGaming.Games.Nylox.Client.Engine.Manager.VirtualState;
import abGroup.sgGaming.Games.Nylox.Client.Foundation.Space.vpCharacterMessage;
import abGroup.sgGaming.Games.Nylox.Client.Foundation.Space.vpCharacterMessage.CharacterListClass;
import abGroup.sgGaming.Games.Nylox.Client.Foundation.Space.vpDeleteCharacterMessage;
import abGroup.sgGaming.Games.Nylox.Client.Foundation.Space.vpEnterCharacterMessage;
import abGroup.sgGaming.Games.Nylox.Client.Foundation.Space.vpSelectCharacterMessage;
import abGroup.sgGaming.Minix2D.Foundation.Singleton;
import abGroup.sgGaming.Minix2D.Gui.Object.Button;
import abGroup.sgGaming.Minix2D.Gui.Property.ActionTrigger;
import abGroup.sgGaming.Minix2D.Gui.System;
import abGroup.sgGaming.Minix2D.Networking.Message.Message;

/**
 * This class define the virtual state of character selection.
 *
 * @author Agustin L. Alvarez
 */
public class vsClientCharacter implements VirtualState {

    /** Selected character **/
    private Character pkCharacter;
    private byte pkSelectedCharacter = -1;
    /** Game server Channel connection **/
    private CharacterListClass[] pkData;
    /** This state contain two states **/
    private int pkNextState = 1; // 1 == Game, 2 == Create Character
    private boolean pkFinish = false;

    /**
     * Constructor
     *
     * @param c The connection with the game server
     * @param l The message that contain the list of availables character
     */
    protected vsClientCharacter(vpCharacterMessage l) {
        pkData = l.getCharacterList();
        createRuntimeControl();
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public String getStateName() {
        return "vsClientCharacter";
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public void Execute(float virtualTimer) {
        // Nothing to do here.
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public boolean hasNextState() {
        // this is the game state.
        if (pkNextState == 1) {
            return false;
        }
        // this is the creation state.
        return true;
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public VirtualState getNextState() {
        return new vsClientCreateCharacter(new vpCharacterMessage(pkData));
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public VirtualState getPrevState() {
        return new vsClientLogin();
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public boolean isFinished() {
        return pkFinish;
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.VirtualState
     */
    public void parseMessage(Message c) {
        if (c.getID() == vpEnterCharacterMessage.ID) {
            // create the engine.
            //TODO: LastState to engineState
            // Finish the last state!
            pkFinish = true;
        }
    }

    /**
     * Create the runtime controls for the state.
     */
    private void createRuntimeControl() {
        System g = Singleton.GetEngine().GetUserSystem();
        ((Button) g.ControlRetrieve("btnCharacter1")).SetCallback(actionCharacter1);
        ((Button) g.ControlRetrieve("btnCharacter2")).SetCallback(actionCharacter2);
        ((Button) g.ControlRetrieve("btnCharacter3")).SetCallback(actionCharacter3);
        ((Button) g.ControlRetrieve("btnCharacter4")).SetCallback(actionCharacter4);
        ((Button) g.ControlRetrieve("btnCharacter5")).SetCallback(actionCharacter5);
        ((Button) g.ControlRetrieve("btnCharacter6")).SetCallback(actionCharacter6);
        ((Button) g.ControlRetrieve("btnLogin")).SetCallback(actionLogin);
        ((Button) g.ControlRetrieve("btnCreate")).SetCallback(actionCreate);
        ((Button) g.ControlRetrieve("btnDelete")).SetCallback(actionDelete);
    }
    /**
     * @Callback -> #btnLogin
     * @description Enter the world with the selected character.
     */
    private ActionTrigger actionLogin = new ActionTrigger() {

        public void ActionCallback() {
            // Check for valid selection.
            if (pkSelectedCharacter != -1) {
                // send the selecte message
                Application.sendMessage(new vpSelectCharacterMessage(pkSelectedCharacter));
            }
        }
    };
    /**
     * @Callback -> #btnCharacter(n)
     * @description Select a character with this button. 
     */
    private ActionTrigger actionCharacter1 = new ActionTrigger() {

        public void ActionCallback() {
            setCharacter(0);
        }
    };
    private ActionTrigger actionCharacter2 = new ActionTrigger() {

        public void ActionCallback() {
            setCharacter(1);
        }
    };
    private ActionTrigger actionCharacter3 = new ActionTrigger() {

        public void ActionCallback() {
            setCharacter(2);
        }
    };
    private ActionTrigger actionCharacter4 = new ActionTrigger() {

        public void ActionCallback() {
            setCharacter(3);
        }
    };
    private ActionTrigger actionCharacter5 = new ActionTrigger() {

        public void ActionCallback() {
            setCharacter(4);
        }
    };
    private ActionTrigger actionCharacter6 = new ActionTrigger() {

        public void ActionCallback() {
            setCharacter(5);
        }
    };
    /**
     * @Callback -> #btnDelete
     * @description Delete a selected character.
     */
    private ActionTrigger actionDelete = new ActionTrigger() {

        public void ActionCallback() {
            // Send the deletion index
            if (pkSelectedCharacter != -1) {
                Application.sendMessage(new vpDeleteCharacterMessage(pkSelectedCharacter));
                pkData[pkSelectedCharacter].pkName = "";
                pkData[pkSelectedCharacter].pkClanName = "";
                pkData[pkSelectedCharacter].pkLevel = 0;
                pkData[pkSelectedCharacter].pkLookBody = 0;
                pkData[pkSelectedCharacter].pkLookHead = 0;
                pkSelectedCharacter = -1;
            }
        }
    };
    /**
     * @Callback -> #btnCreate
     * @description Enter into the creation state.
     */
    private ActionTrigger actionCreate = new ActionTrigger() {

        public void ActionCallback() {
            pkNextState = 2;
            pkFinish = true;
        }
    };

    /**
     * Set the current character.
     *
     * @param index
     */
    private void setCharacter(int index) {
        if (index < pkData.length) {
            pkSelectedCharacter = (byte) (pkData[index].pkName.equals("") == false ? index : -1);
        }
    }

    /**
     * @return The selected loaded character.
     */
    public Character getSelectedCharacter() {
        return pkCharacter;
    }

}
