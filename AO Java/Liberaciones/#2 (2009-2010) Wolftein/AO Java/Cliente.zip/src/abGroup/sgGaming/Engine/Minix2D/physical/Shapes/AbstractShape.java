/*
 * @(#)AbstractShape.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical.Shapes;

/**
 * Super class of generic shapes in the engine
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public strictfp abstract class AbstractShape implements Shape {
	/** The circular bounds that fit the shape based on the position of the body */
	protected AABox bounds;
	
	/**
	 * Construct a new shape as subclas swhich will specified it's
	 * own bounds
	 */
	protected AbstractShape() {
	}
	
	/**
	 * Create a shape
	 * 
	 * @param bounds The bounds of the shape
	 */
	public AbstractShape(AABox bounds) {
		this.bounds = bounds;
	}
	
	/**
	 * @see net.phys2d.raw.shapes.Shape#getBounds()
	 */
	public AABox getBounds() {
		return bounds;
	}	
}
