/*
 * @(#)DeviceListener.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.device;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public interface DeviceListener {

    /**
     * This function is called when the display is initialized.
     */
    public void Initialize( Canvas c );

    /**
     * This function is called when the display need to update.
     */
    public void Render( Graphics2D g );

    /**
     * This function is called when the logical need to update.
     *
     * @param deltaTime
     */
    public void Logical(float deltaTime);

    /**
     * This function is called when the windows ask for Close
     */
    public boolean closeRequest();

}
