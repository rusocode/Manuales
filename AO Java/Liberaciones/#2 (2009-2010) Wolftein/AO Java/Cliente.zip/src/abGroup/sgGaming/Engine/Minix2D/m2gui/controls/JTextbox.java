/*
 * @(#)JTextbox.java	1.0 Feb 2, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.m2gui.controls;

import abGroup.sgGaming.Engine.Minix2D.device.Color;
import abGroup.sgGaming.Engine.Minix2D.device.Font;
import abGroup.sgGaming.Engine.Minix2D.device.Font.Aligment;
import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.input.Keyboard;
import abGroup.sgGaming.Engine.Minix2D.input.Keyboard.enumKeyboardKey;
import abGroup.sgGaming.Engine.Minix2D.input.Mouse.MouseButton;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Control;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Drawable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Eventable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Focuseable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Keyable;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Mouseable;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.util.Timer;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement;
import abGroup.sgGaming.Engine.Minix2D.util.xml.XMLException;
import java.util.Arrays;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 2, 2010
 * @since JDK 1.6
 */
public class JTextbox extends Control implements Drawable, Mouseable, Keyable, Focuseable, Eventable {
    
    /** Cursor variables **/
    private boolean cursorShow = false;
    private long cursorTime = Timer.getMillisecondTime();
    private int cursorFrame = 0;
    /** Textbox string **/
    private String initial = "";
    private String text = "";
    private boolean lostOnFocus = false;
    private char passwordKey;
    private int maxLenght = 0;
    /** Textbox property **/
    private Font font;
    private Color color = Color.White;
    private Vector2f scale = new Vector2f(1.0f, 1.0f);
    /** Textbox action **/
    private int cursorPosition, cursorFirst, cursorLast;
    private int mouseX;

    /**
     * Constructor
     * 
     * @param x
     * @param y
     * @param width
     * @param height
     * @param f
     */
    public JTextbox(int x, int y, int width, int height, Font f) {
        super("JTextbox");
        setPosition(new Vector2f(x, y));
        setSize(new Vector2f(width, height));
        setFont(f);
    }

    /**
     * Constructor
     * 
     * @param element
     * @throws XMLException
     */
    public JTextbox(XMLElement element) throws XMLException {
        super("JTextbox");
        parse(element);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Control#parse(abGroup.sgGaming.Engine.Minix2D.util.xml.XMLElement)
     */
    @Override
    public void parse(XMLElement element) throws XMLException {
        // Control parse native.
        super.parse(element);
        // JPicture propertys.
        String[] xmlProperty = element.getAttributeNames();
        String currentProperty;
        for( int i = 0; i < xmlProperty.length; i++ ) {
            currentProperty = xmlProperty[i].toUpperCase();
            if( currentProperty.equals("COLOR") ) {
                setColor( Color.parseOf(element.getAttribute("Color")));
            } else if (element.getAttributeNames()[i].toUpperCase().equals("SCALE")) {
                setScale( Vector2f.parseOf(element.getAttribute("Scale")));
            } else if (element.getAttributeNames()[i].toUpperCase().equals("CAPTION")) {
                setString( element.getAttribute("Caption"));
            } else if (element.getAttributeNames()[i].toUpperCase().equals("REFRESH")) {
                setRefresh( element.getBooleanAttribute("Refresh"));
            } else if (element.getAttributeNames()[i].toUpperCase().equals("PASSWORDKEY")) {
                setPasswordKey( element.getAttribute("PasswordKey").charAt(0) );
            } else if (element.getAttributeNames()[i].toUpperCase().equals("MAXLENGHT")) {
                setMaxLenght( element.getIntAttribute("MaxLenght") );
            } else if (currentProperty.equals("FONT")) {
                setFont(Font.Retrieve(element.getAttribute("Font")));
            }
        }
    }

    /**
     * Set the textbox font.
     * 
     * @param f
     */
    public void setFont(Font f) {
        font = f;
    }

    /**
     * @return The text of the textbox
     */
    public String getText() {
        return text;
    }

    /**
     * Set the initial textbox text.
     *
     * @param text
     */
    public void setString(String text) {
        initial = text;
        reset(text);
    }

    /**
     * Set the color of the textbox.
     *
     * @param c
     */
    public void setColor(Color c) {
        color = c;
    }

    /**
     * Set the size of the font in %px
     * 
     * @param size
     */
    public void setScale(Vector2f scale) {
        this.scale = scale;
    }

    /**
     * Does the textbox loose the initial?.
     *
     * @param value
     */
    public void setRefresh(boolean value) {
        this.lostOnFocus = value;
    }

    /**
     * Set Max lenght of the textbox.
     *
     * @param value
     */
    public void setMaxLenght(int value) {
        maxLenght = value;
    }

    /**
     * Set the password key of the textbox.
     *
     * @param key
     */
    public void setPasswordKey(char key) {
        passwordKey = key;
    }

    /**
     * Reset the textbox with the given string.
     *
     * @param text
     */
    private void reset(String text) {
        //strText = Language.Script(text);
        cursorFirst = cursorLast = cursorPosition = 0;
        setCursor(text.length());
    }

    /**
     * Add a string to the textbox.
     *
     * @param text
     */
    private void addString(String text) {
        // Get the size of the string
        int lenght = text.length();
        // Per character, add one
        for (int i = 0; i < lenght; i++) {
            if (addCharacter(text.charAt(i)) == false) {
                return;
            }
        }
    }

    /**
     * Add a character to the string of the textbox.
     *
     * @param character
     * @return
     */
    private boolean addCharacter(char character) {
        // Check max lenght
        if (text.length() >= maxLenght && maxLenght != 0) {
            return false;
        }
        // Add a character to the position of the cursor
        text = text.substring(0, cursorPosition) + character + text.substring(cursorPosition);
        // Move the cursor forward
        moveCursor(+1);
        return true;
    }

    /**
     * This function remove the character at the current position
     */
    private void removeCharacter() {
        // Check min lenght
        if (text.length() == 0) {
            return;
        }
        // Remove the character from the string
        if (cursorPosition < text.length()) {
            text = text.substring(0, cursorPosition) + text.substring(cursorPosition + 1);
            // Remove from the end of the string
        } else {
            text = text.substring(0, cursorPosition - 1);
        }
        // Move the cursor backward
        moveCursor(-1);
    }

    /**
     * Move the cursor.
     * 
     * @param iRelative
     */
    private void moveCursor(int iRelative) {
        setCursor(cursorPosition + iRelative);
    }

    /**
     * Set the current Cursor position of the textbox.
     * 
     * @param iPosition
     */
    private void setCursor(int iPosition) {
        if (text == null) {
            return;
        }

        int lastPosition = cursorPosition;
        int stringLenght = text.length();

        // Set the Position
        cursorPosition = iPosition;
        // Normalize out of boundary
        if (cursorPosition < 0) {
            cursorPosition = 0;
        }
        if (cursorPosition > stringLenght) {
            cursorPosition = stringLenght;
        }
        // Get the Delta Position
        lastPosition -= cursorPosition;
        // Calculate the indexs
        if (cursorPosition < cursorFirst) {
            // Set the new position with the delta.
            cursorFirst -= lastPosition;
            // Normalize Boundary
            if (cursorFirst < 0) {
                cursorFirst = 0;
            }
            // Set the last viewport
            cursorLast = cursorFirst + font.getSpaceWidth(text.substring(cursorFirst), Aligment.Left, width);
            // Normalize Bondary
            if (cursorLast > stringLenght) {
                cursorLast = stringLenght;
            }
        } else if (cursorPosition > cursorLast) {
            // Set the new position with the delta.
            cursorLast -= lastPosition;
            // Normalize Boundary
            if (cursorFirst > stringLenght) {
                cursorPosition = stringLenght;
            }
            // Set the last viewport
            cursorFirst = cursorLast - font.getSpaceWidth(text.substring(cursorFirst), Aligment.Left, width);
            // Normalize Boundary
            if (cursorFirst < 0) {
                cursorFirst = 0;
            }
        } else {
            // Set the last viewport
            cursorLast = cursorFirst + font.getSpaceWidth(text.substring(cursorFirst), Aligment.Left, width);
            // Normalize Bondary
            if (cursorLast > stringLenght) {
                cursorLast = stringLenght;
            }
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Drawable#Drawable(abGroup.sgGaming.Engine.Minix2D.device.Graphics2D, int, int)
     */
    public void Drawable(Graphics2D g, int x, int y) {
        // Calculate the cursor view timer.
        long cursorCurrentTime = Timer.getTime() - cursorTime;
        // Render only if its visible
        if (cursorLast != 0) {
            // Set the Color Render of the Control
            g.setColor(color);
            // Does we need to pass the string to password key?
            if (passwordKey == 0 || text.equals(initial)) {
                font.write(x + this.x, y + this.y, text, cursorFirst, cursorLast - 1, scale.x, scale.y, Aligment.Left);
            } // The textbox need to convert the string to password keyr
            else {
                // Allocate a new List of character
                char[] hidingText = new char[text.length()];
                // Fill that list with the password key
                Arrays.fill(hidingText, passwordKey);
                // Copy the char List to a String
                String tokenize = new String(hidingText);
                // Render the tokenized string
                font.write(x + this.x, y + this.y, tokenize, cursorFirst, cursorLast - 1, scale.x, scale.y, Aligment.Left);
            }
            // Get back to The Default Color
            g.setColor(Color.White);
        }
        // Now we have to render and calculate the
        // cursor of the textbox
        // TODO LATER...
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Mouseable
     */
    public void mouseMove(int dX, int dY, int rX, int rY) {
        mouseX = dX;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Mouseable
     */
    public void mouseButton(MouseButton button) {
        // Get the OffsetX
        int offsetX = font.getIndexFromPosition(text.substring(cursorFirst, cursorLast), Aligment.Left, mouseX);
        // Set the position of the Mouse
        setCursor(offsetX + cursorFirst);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Mouseable
     */
    public void mouseWheel(int WheelNumber) {
        if (WheelNumber < 0) {
            moveCursor(-1);
        } else {
            moveCursor(+1);
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Keyable
     */
    public void keyDown(enumKeyboardKey key, Keyboard trigger) {
        keyPress(key, trigger);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Keyable
     */
    public void keyRelease(enumKeyboardKey key, Keyboard trigger) {
        return;
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Keyable
     */
    public void keyPress(enumKeyboardKey key, Keyboard trigger) {
        // Get the Key States.
        boolean Control = trigger.isEvent(Keyboard.KeyboardEvent.KEY_DOWN, Keyboard.KeyboardState.KEY_CONTROL);
        boolean Shift = trigger.isEvent(Keyboard.KeyboardEvent.KEY_DOWN, Keyboard.KeyboardState.KEY_SHIFT);
        boolean Alt = trigger.isEvent(Keyboard.KeyboardEvent.KEY_DOWN, Keyboard.KeyboardState.KEY_ALT);
        boolean Meta = trigger.isEvent(Keyboard.KeyboardEvent.KEY_DOWN, Keyboard.KeyboardState.KEY_META);
        // parse each key.
        switch (key) {
            // Horizontal Arrows
            case KEY_RIGHT:
                moveCursor(+1);
                break;
            case KEY_LEFT:
                moveCursor(-1);
                break;
            // Special Keys
            case KEY_HOME:
                setCursor(0);
                break;
            case KEY_END:
                setCursor(text.length());
                break;
            case KEY_BACK:
            case KEY_DELETE:
                removeCharacter();
                break;
            // Control V (Normal or PasteCode)
            case KEY_V:
                if (Control) {
                    //AddString( Singleton.GetDevice().getClipboard() );
                } else {
                    addCharacter(Keyboard.TranslateToAscii(Control, Shift || Meta, Alt, key));
                }
                break;
            // Control C (Normal or CopyCode)
            case KEY_C:
                // if( Control )
                //AddString( Sys.getClipboard( ) );
                // else
                addCharacter(Keyboard.TranslateToAscii(Control, Shift || Meta, Alt, key));
                break;
            // Normal Key
            default:
                if (Keyboard.IsKeyCharacter(key) == true) {
                    addCharacter(Keyboard.TranslateToAscii(Control, Shift || Meta, Alt, key));
                }
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.m2gui.Focuseable
     */
    public boolean focus(boolean bValue) {
        // Make the initial string event
        if (bValue == false && lostOnFocus == true) {
            reset(initial);
        } else if (bValue == true) {
            reset("");
        }
        // Set the Cursor Show
        cursorShow = bValue;
        // Return parsed succesfull and keep the focus.
        return true;
    }

}
