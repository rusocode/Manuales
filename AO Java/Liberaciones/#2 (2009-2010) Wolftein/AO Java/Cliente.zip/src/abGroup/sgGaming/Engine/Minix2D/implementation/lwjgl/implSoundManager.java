/*
 * @(#)implSoundManager.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.implementation.lwjgl;

import abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundInput;
import abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import org.lwjgl.LWJGLException;
import org.lwjgl.openal.AL;
import org.lwjgl.openal.AL10;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class implSoundManager extends SoundManager {

    /** OpenAL Extensions */
    private boolean vorbisProperty = false;
    /** AL instance. */
    private static int alContext = 0;

    public implSoundManager(int soundSize) {
        super(soundSize);
        createContext();
    }

    private void createContext() {
        // one more openal context
        alContext++;
        // Nothing to do if the OpenAL is already created.
        if (AL.isCreated()) {
            return;
        }
        // Create the context.
        try {
            AL.create();
        } catch (LWJGLException ex) {
            alContext--;
            throw new RuntimeException("Unable to create OpenAL. Please make sure that OpenAL is available on this system");
        }
        vorbisProperty = AL10.alIsExtensionPresent("AL_EXT_vorbis");
    }

    protected void destroyContext() {
        alContext--;
        if (alContext == 0 && AL.isCreated()) {
            AL.destroy();
        }
    }


    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#setListenerPosition(float, float, float) 
     */
    @Override
    public void setListenerPosition(float x, float y, float z) {
        AL10.alListener3f(AL10.AL_POSITION, x, y, z);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#setListenerVelocity(float, float, float)
     */
    @Override
    public void setListenerVelocity(float x, float y, float z) {
        AL10.alListener3f(AL10.AL_VELOCITY, x, y, z);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#setListenerOrientation(float, float, float, float, float, float)
     */
    @Override
    public void setListenerOrientation(float lookatx, float lookaty, float lookatz, float upx, float upy, float upz) {
        float[] fvals = {lookatx, lookaty, lookatz, upx, upy, upz};
        FloatBuffer fb = ByteBuffer.allocateDirect(fvals.length * Float.SIZE).order(ByteOrder.nativeOrder()).asFloatBuffer();
        fb.put(fvals);
        fb.flip();
        AL10.alListener(AL10.AL_ORIENTATION, fb);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#pause(int, boolean)
     */
    @Override
    public void pause(int sound, boolean value) {
        if (value) {
            AL10.alSourcePause(sound);
        } else {
            AL10.alSourcePlay(sound);
        }
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#play(int)
     */
    @Override
    public void play(int sound) {
        AL10.alSourcePlay(sound);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#stop(int)
     */
    @Override
    public void stop(int sound) {
        AL10.alSourceStop(sound);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#getGain(int)
     */
    @Override
    public float getGain(int sound) {
        return AL10.alGetSourcef(sound, AL10.AL_GAIN);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#setVelocity(int, float)
     */
    @Override
    public void setVelocity(int sound, float velocity) {
        AL10.alSourcef(sound, AL10.AL_VELOCITY, velocity);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#setPitch(int, float)
     */
    @Override
    public void setPitch(int sound, float pitch) {
        AL10.alSourcef(sound, AL10.AL_PITCH, pitch);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#setGain(int, float)
     */
    @Override
    public void setGain(int sound, float gain) {
        AL10.alSourcef(sound, AL10.AL_GAIN, gain * this.playerGain);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#setSoundPosition(int, float, float, float)
     */
    @Override
    public void setSoundPosition(int sound, float x, float y, float z) {
        AL10.alSource3f(sound, AL10.AL_POSITION, x, y, z);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#setReferenceDistance(int, float)
     */
    @Override
    public void setReferenceDistance(int sound, float distance) {
        AL10.alSourcef(sound, AL10.AL_REFERENCE_DISTANCE, distance);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#setLoop(int, boolean)
     */
    @Override
    public void setLoop(int sound, boolean on) {
        AL10.alSourcei(sound, AL10.AL_LOOPING, (on ? AL10.AL_TRUE : AL10.AL_FALSE));
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#isPlaying(int)
     */
    @Override
    public boolean isPlaying(int sound) {
        IntBuffer ib = ByteBuffer.allocateDirect(1 * Integer.SIZE).order(ByteOrder.nativeOrder()).asIntBuffer();
        ib.put(sound);
        AL10.alGetInteger(AL10.AL_PLAYING, ib);
        return (ib.get(0) == AL10.AL_TRUE);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#makeSoundSource(int)
     */
    @Override
    public int makeSoundSource(int sound) {
        IntBuffer soundSourceHandle = ByteBuffer.allocateDirect(1 * Integer.SIZE).order(ByteOrder.nativeOrder()).asIntBuffer();
        // al generate buffers and sources
        AL10.alGenSources(soundSourceHandle);
        // bind the sound source to a sound data buffer
        AL10.alSourcei(soundSourceHandle.get(0), AL10.AL_BUFFER, sound);
        // set the distance for sound droppoff calculations (a typical distance at which we should hear this sound)
        AL10.alSourcef(soundSourceHandle.get(0), AL10.AL_REFERENCE_DISTANCE, this.playerReferenceDistance);
        // set volume to current environment volume
        AL10.alSourcef(soundSourceHandle.get(0), AL10.AL_GAIN, this.playerGain);
        // hold onto the new sound source
        if (this.soundSourceSize < this.soundSize) {
            this.sourceBuffer[soundSourceSize++] = soundSourceHandle.get(0);
        }
        return soundSourceHandle.get(0);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#deleteSoundData(int)
     */
    @Override
    protected void deleteSoundData(int sound) {
        IntBuffer ib = ByteBuffer.allocateDirect(1 * Integer.SIZE).order(ByteOrder.nativeOrder()).asIntBuffer();
        ib.put(sound);
        ib.position(0).limit(1);
        AL10.alDeleteBuffers(ib);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#deleteSoundSource(int)
     */
    @Override
    protected void deleteSoundSource(int sound) {
        IntBuffer ib = ByteBuffer.allocateDirect(1 * Integer.SIZE).order(ByteOrder.nativeOrder()).asIntBuffer();
        ib.put(sound);
        ib.position(0).limit(1);
        AL10.alDeleteSources(ib);
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#generateBuffer(int, abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundInput)
     */
    @Override
    protected void generateBuffer(int sound, SoundInput in) {
        int alFormat = 0;
        switch (in.getSoundFormat()) {
            case MONO8:
                alFormat = AL10.AL_FORMAT_MONO8;
                break;
            case MONO16:
                alFormat = AL10.AL_FORMAT_MONO16;
                break;
            case STEREO8:
                alFormat = AL10.AL_FORMAT_STEREO8;
                break;
            case STEREO16:
                alFormat = AL10.AL_FORMAT_STEREO16;
                break;
        }
        AL10.alBufferData(sound, alFormat, in.getSoundData(), in.getSoundSamples());
    }

    /**
     * @see abGroup.sgGaming.Engine.Minix2D.soundmanager.SoundManager#generateBufferallocateSoundData()
     */
    @Override
    public int allocateSoundData() {
        IntBuffer soundDataHandle = ByteBuffer.allocateDirect(1 * Integer.SIZE).order(ByteOrder.nativeOrder()).asIntBuffer();
        // al generate buffers and sources
        AL10.alGenBuffers(soundDataHandle);
        // hold onto sound Data handle
        if (this.soundBufferSize < this.soundSize) {
            this.soundBuffer[this.soundBufferSize++] = soundDataHandle.get(0);
        }
        return soundDataHandle.get(0);
    }

}
