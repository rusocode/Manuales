/*
 * @(#)Mouse.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.input;

import java.util.ArrayList;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public abstract class Mouse {

    /**
     * Button mouse list
     */
    public static enum MouseButton {

        BUTTON_LEFT,
        BUTTON_RIGHT,
        BUTTON_MIDDLE;

        /**
         * Return the Mapped enum number
         * @param Number
         * @return
         */
        public static MouseButton valueOf(int Number) {
            return MouseButton.values()[Number];
        }
    };

    /**
     * Mouse Button Event Type
     */
    public enum MOUSE_BUTTON_EVENT {

        MOUSE_PRESS,
        MOUSE_RELEASE
    };

    /**
     * Mouse Event Types
     */
    public enum MOUSE_EVENT_TYPE {

        MOUSE_MOVEMENT,
        MOUSE_BUTTON,
        MOUSE_WHEEL;
    };
    /**
     * List of events to raise
     */
    protected ArrayList<MouseListener> eventListener;
    /**
     * Mouse Coordinates
     */
    protected int mouseX, mouseY, mouseRelativeX, mouseRelativeY;
    /**
     * Mouse Buttons
     */
    protected int mouseWheel, mouseWheelRotation;
    protected boolean mouseButton[];
    /**
     * Mouse States
     */
    protected boolean mouseMovementState, mouseButtonState, mouseWheelState;
    protected int mouseButtonUpdate, mouseWheelUpdate;
    /**
     * Internal implementation Coordinates
     */
    protected int lastMouseX, lastMouseY;
    /**
     * Size of the window
     */
    protected int iWindowHeight;

    /**
     * Constructor
     * @param buttonSize
     */
    protected Mouse(int iHeight) {
        // Allocate memory for the event listener array
        eventListener = new ArrayList<MouseListener>();
        // Allocate memory for the buttons
        mouseButton = new boolean[3];
        iWindowHeight = iHeight;
    }

    /**
     * Add an listener
     * @param Action
     * @param Listener
     */
    public void AddListener(MouseListener listener) {
        eventListener.add(listener);
    }

    /**
     * Delete an listener
     * @param Action
     * @param Listener
     */
    public void RemoveListener(MouseListener listener) {
        eventListener.remove(listener);
    }

    /**
     * This function call the
     * implementation of the mouse
     */
    public void irqEvent() {
        // call the implementation of the mouse
        implEvent();
        // call module parser
        mouseEvent();
    }

    /**
     * Raise the mouse Movement
     * from the implementation
     * @param eventType
     * @param eventParameter
     */
    protected void raiseEventMovement() {
        mouseMovementState = true;
    }

    /**
     * Raise the mouse Button
     * from the implementation
     * @param eventType
     * @param eventParameter
     */
    protected void raiseEventButton(int button) {
        mouseButtonState = true;
        mouseButtonUpdate = button;
    }

    /**
     * Raise the mouse Wheel
     * from the implementation
     * @param eventType
     * @param eventParameter
     */
    protected void raiseEventWheel(int wheelMovement) {
        mouseWheelState = true;
        mouseWheelUpdate = wheelMovement;
    }

    /**
     * This function actually
     * call all the listeners
     */
    private void mouseEvent() {
        // if nothing happed, then just exit
        if (!mouseMovementState && !mouseWheelState && !mouseButtonState) {
            return;
        }

        // Loop Though all the listeners
        for (int i = 0 ; i < eventListener.size(); i++) {
            // get the current Listener
            MouseListener currentListener = eventListener.get(i);
            // if it was an movement
            if (mouseMovementState == true) {
                mouseMovementState = !currentListener.mouseMove(mouseX, mouseY, mouseRelativeX, mouseRelativeY);
            }
            if (mouseWheelState == true) {
                mouseWheelState = !currentListener.mouseWheel(mouseWheelUpdate);
            }
            if (mouseButtonState == true) {
                mouseButtonState = !currentListener.mouseButton(MouseButton.valueOf(mouseButtonUpdate),
                        GetButtonState(mouseButtonUpdate));
            }
        }

        // reset all temporally states
        mouseMovementState = false;
        mouseWheelState = false;
        mouseButtonState = false;
    }

    /**
     * Return the button State
     *
     * @param buttonNumber
     * @return
     */
    protected MOUSE_BUTTON_EVENT GetButtonState(int buttonNumber) {
        if (mouseButton[buttonNumber] == true) {
            return MOUSE_BUTTON_EVENT.MOUSE_PRESS;
        } else {
            return MOUSE_BUTTON_EVENT.MOUSE_RELEASE;
        }
    }

    /**
     * Return if the key is event.
     *
     * @param event
     * @param buttonNumber
     * @return
     */
    public boolean isButtonState( MOUSE_BUTTON_EVENT event, MouseButton buttonNumber ) {
        return (event == GetButtonState(buttonNumber.ordinal()) );
    }

    /**
     * Set the state of the button
     *
     * @param buttonNumber
     * @param buttonState
     */
    protected void setButtonState(int buttonNumber, boolean buttonState) {
        mouseButton[buttonNumber] = buttonState;
    }

    /**
     * Return the wheel Rotation
     * @return
     */
    public int GetWheelRotation() {
        return mouseWheelRotation;
    }

    /**
     * Return the wheel position
     * @return
     */
    public int GetWheelPosition() {
        return mouseWheel;
    }

    /**
     * Return the Mouse Position X
     * @return
     */
    public int GetMouseX() {
        return mouseX;
    }

    /**
     * Return the Mouse Position Y
     * @return
     */
    public int GetMouseY() {
        return mouseY;
    }

    /**
     * Call the mouse implementation for
     * setting the cursor visibility
     * @param Value
     */
    public abstract void SetCursorVisible(boolean Value);

    /**
     * Call the mouse implementation for
     * check if the cursor is visible
     * @return
     */
    public abstract boolean isCursorVisible();

    /**
     * Implementation of the mouse
     * event
     */
    protected abstract void implEvent();

    /**
     * Reset the mouse hardware.
     */
    public void Reset() {
        mouseButton[0] = false;
        mouseButton[1] = false;
        mouseButton[2] = false;
    }
}