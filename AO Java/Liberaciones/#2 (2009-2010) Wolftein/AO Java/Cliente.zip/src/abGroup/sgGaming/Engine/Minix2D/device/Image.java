/*
 * @(#)Image.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.device;

import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class Image {

    protected String filename;
    protected int width, height;
    protected int textureWidth, textureHeight;
    protected float widthRatio, heightRatio;
    protected int textureID;

    /**
     * Constructor.
     *
     * @param filename
     * @param size
     */
    public Image(String filename, Vector2f size, int id) {
        this.filename = filename;
        this.width = (int) size.x;
        this.height = (int) size.y;
        this.textureID = id;
    }

    /**
     * Constructor
     *
     * @param clone
     */
    public Image(Image clone) {
        this(clone.filename, new Vector2f(clone.width, clone.height), clone.textureID);
        setTextureVector(new Vector2f(clone.textureWidth, clone.textureHeight));
    }

    /**
     * Set the texture vector.
     *
     * @param size
     */
    public void setTextureVector(Vector2f size) {
        textureWidth = (int) size.x;
        textureHeight = (int) size.y;
        setHeight();
        setWidth();
    }

    /**
     * Set the height of the texture. This will update the
     * ratio also.
     */
    private void setHeight() {
        heightRatio = ((float) height) / textureHeight;
    }

    /**
     * Set the width of the texture. This will update the
     * ratio also.
     */
    private void setWidth() {
        widthRatio = ((float) width) / textureWidth;
    }

    public int getTextureWidth() {
        return textureWidth;
    }

    public int getTextureHeight() {
        return textureHeight;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public float getRatioWidth() {
        return widthRatio;
    }

    public float getRationHeight() {
        return heightRatio;
    }

    public int getTextureID() {
        return textureID;
    }
}
