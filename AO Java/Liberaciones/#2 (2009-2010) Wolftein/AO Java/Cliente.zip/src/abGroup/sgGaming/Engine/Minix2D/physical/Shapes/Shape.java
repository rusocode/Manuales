/*
 * @(#)Shape.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical.Shapes;

/**
 * A simple shape describing the area covered by a body
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public interface Shape {

	/**
	 * Get the box bounds of the shape
	 * 
	 * @return The bounds of the shape
	 */
	public AABox getBounds();
	
	/**
	 * Some factor based on the edges length of the shape
	 * 
	 * @return The factor result - from the original demo
	 */
	public float getSurfaceFactor();
}
