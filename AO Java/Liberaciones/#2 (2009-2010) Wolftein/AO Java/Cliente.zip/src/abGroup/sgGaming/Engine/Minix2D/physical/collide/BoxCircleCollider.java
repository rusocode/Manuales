/*
 * @(#)BoxCircleCollider.java	1.0 Feb 1, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.physical.collide;

import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import abGroup.sgGaming.Engine.Minix2D.physical.Body;
import abGroup.sgGaming.Engine.Minix2D.physical.Contact;
import abGroup.sgGaming.Engine.Minix2D.physical.Shapes.Box;
import abGroup.sgGaming.Engine.Minix2D.physical.Shapes.Circle;
import abGroup.sgGaming.Engine.Minix2D.physical.Shapes.Line;

/**
 * A collider for boxes hitting circles. Box = bodyA, Circle = bodyB
 * 
 * The create() method is used as a factor although since this collider
 * is currently stateless a single instance is returned.
 * 
 * @author Agustin L. Alvarez
 * @version 1.0 ,Feb 1, 2010
 * @since JDK 1.6
 */
public strictfp class BoxCircleCollider implements Collider {

    /**
     * @see net.phys2d.raw.collide.Collider#collide(net.phys2d.raw.Contact[], net.phys2d.raw.Body, net.phys2d.raw.Body)
     */
    public int collide(Contact[] contacts, Body boxBody, Body circleBody) {
        float x1 = boxBody.getPosition().GetX();
        float y1 = boxBody.getPosition().GetY();
        float x2 = circleBody.getPosition().GetX();
        float y2 = circleBody.getPosition().GetY();

        boolean touches = boxBody.getShape().getBounds().touches(x1, y1, circleBody.getShape().getBounds(), x2, y2);
        if (!touches) {
            return 0;
        }

        Box box = (Box) boxBody.getShape();
        Circle circle = (Circle) circleBody.getShape();

        Vector2f[] pts = box.getPoints(boxBody.getPosition(), boxBody.getRotation());
        Line[] lines = new Line[4];
        lines[0] = new Line(pts[0], pts[1]);
        lines[1] = new Line(pts[1], pts[2]);
        lines[2] = new Line(pts[2], pts[3]);
        lines[3] = new Line(pts[3], pts[0]);

        float r2 = circle.getRadius() * circle.getRadius();
        int closest = -1;
        float closestDistance = Float.MAX_VALUE;

        for (int i = 0; i < 4; i++) {
            float dis = lines[i].distanceSquared(circleBody.getPosition());
            if (dis < r2) {
                if (closestDistance > dis) {
                    closestDistance = dis;
                    closest = i;
                }
            }
        }

        if (closest > -1) {
            float dis = (float) Math.sqrt(closestDistance);
            contacts[0].setSeparation(dis - circle.getRadius());

            // this should really be where the edge and the line
            // between the two elements cross?
            Vector2f contactPoint = new Vector2f();
            lines[closest].getClosestPoint(circleBody.getPosition(), contactPoint);

            Vector2f normal = Vector2f.sub(circleBody.getPosition(), contactPoint);
            normal.Normalise();
            contacts[0].setNormal(normal);
            contacts[0].setPosition(contactPoint);
            contacts[0].setFeature(new FeaturePair());

            return 1;
        }

        return 0;
    }
}
