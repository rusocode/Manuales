/*
 * @(#)Matrix2f.java	1.0 Jan 31, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package abGroup.sgGaming.Engine.Minix2D.math;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Jan 31, 2010
 * @since JDK 1.6
 */
public class Matrix2f {

    /**
     * The first column of the matrix
     */
    public Vector2f col1 = new Vector2f();
    /**
     * The second column of the matrix
     */
    public Vector2f col2 = new Vector2f();

    /**
     * Create an empty matrix
     */
    public Matrix2f() {
    }

    /**
     * Create a matrix with a rotation
     *
     * @param angle The angle of the rotation decribed by the matrix
     */
    public Matrix2f(float angle) {
        float c = (float) Math.cos(angle);
        float s = (float) Math.sin(angle);
        col1.x = c;
        col2.x = -s;
        col1.y = s;
        col2.y = c;
    }

    /**
     * Create a matrix
     *
     * @param col1 The first column
     * @param col2 The second column
     */
    public Matrix2f(Vector2f col1, Vector2f col2) {
        this.col1.Set(col1);
        this.col2.Set(col2);
    }

    /**
     * Transpose the matrix
     *
     * @return A newly created matrix containing the transpose of this matrix
     */
    public Matrix2f transpose() {
        return new Matrix2f(new Vector2f(col1.x, col2.x),
                new Vector2f(col1.y, col2.y));
    }

    /**
     * Transpose the invert
     *
     * @return A newly created matrix containing the invert of this matrix
     */
    public Matrix2f Invert() {
        float a = col1.x, b = col2.x, c = col1.y, d = col2.y;
        Matrix2f B = new Matrix2f();

        float det = a * d - b * c;
        if (det == 0.0f) {
            throw new RuntimeException("Matrix2f: invert() - determinate is zero!");
        }

        det = 1.0f / det;
        B.col1.x = det * d;
        B.col2.x = -det * b;
        B.col1.y = -det * c;
        B.col2.y = det * a;
        return B;
    }

    /**
     * Multiple two matricies
     *
     * @param A The first matrix
     * @param B The second matrix
     * @return A newly created matrix containing the result
     */
    public static Matrix2f mul(Matrix2f A, Matrix2f B) {
        return new Matrix2f(Vector2f.mul(A, B.col1), Vector2f.mul(A, B.col2));
    }

    /**
     * Create the absolute version of a matrix
     *
     * @param A The matrix to make absolute
     * @return A newly created absolute matrix
     */
    public static Matrix2f abs(Matrix2f A) {
        return new Matrix2f(Vector2f.abs(A.col1), Vector2f.abs(A.col2));
    }

    /**
     * Add two matricies
     *
     * @param A The first matrix
     * @param B The second matrix
     * @return A newly created matrix containing the result
     */
    public static Matrix2f add(Matrix2f A, Matrix2f B) {
        Vector2f temp1 = new Vector2f(A.col1);
        temp1.Add(B.col1);
        Vector2f temp2 = new Vector2f(A.col2);
        temp2.Add(B.col2);

        return new Matrix2f(temp1, temp2);
    }
}
