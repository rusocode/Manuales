/*
 * @(#)LoginFrame.java	1.0 May 25, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package aojclient;

import abGroup.sgGaming.Engine.Minix2D.kernel.MinixState;
import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import abGroup.sgGaming.Engine.Minix2D.m2gui.ControlManager;
import abGroup.sgGaming.Engine.Minix2D.m2gui.Triggered;
import abGroup.sgGaming.Engine.Minix2D.m2gui.controls.JButton;
import abGroup.sgGaming.Engine.Minix2D.m2gui.controls.JTextbox;
import abGroup.sgGaming.Engine.Minix2D.m2gui.triggers.OpenUrlTrigger;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,May 25, 2010
 * @since
 */
public class LoginFrame extends MinixState {
    
    /** Language used by this vs **/
    private final static String GAME_LANGUAGE_ERROR           = "GetLocaleID(SystemError)";
    private final static String GAME_LANGUAGE_LOGIN_LENGTH    = "GetLocaleID(FoundationGameID9)";
    private final static String GAME_LANGUAGE_LOGIN_OFFLINE   = "GetLocaleID(FoundationNetworkID1)";
    private final static String GAME_LANGUAGE_LOGIN_VERSION   = "GetLocaleID(FoundationGameID11)";
    private final static String GAME_LANGUAGE_LOGIN_INCORRECT = "GetLocaleID(FoundationGameID10)"; 
    
    /** Misc constants **/
    private final static String GAME_VERSION  = "0.1 RC1024 Alpha A";
    private final static int MIN_LOGIN_LENGHT = 6;
    private final static int MAX_LOGIN_LENGHT = 12;
    
    /** Url Constant **/
    private final static String GAME_CREDIT_URL    = "http://www.nylox-online.com.ar/credit.html";
    private final static String GAME_HOWTOPLAY_URL = "http://www.nylox-online.com.ar/howtoplay.html"; 
    
    /** Server Configuration **/
    ServerConfiguration configRemote;

    public LoginFrame( ServerConfiguration config ) {
        super("Login Frame");

        this.configRemote = config;
    }
    
    
    private void RuntimeControlAccess() {
        ControlManager cm = Runtime.getKernel().getControlManager();

        ((JButton)cm.getControl("btnLogin")).setCallback( LoginTrigger );
        ((JButton)cm.getControl("btnCredit")).setCallback( new OpenUrlTrigger(GAME_CREDIT_URL));
        ((JButton)cm.getControl("btnHowToPlay")).setCallback( new OpenUrlTrigger(GAME_HOWTOPLAY_URL));
    }

    private Triggered LoginTrigger = new Triggered() {
        public void callback() {
            ControlManager cm = Runtime.getKernel().getControlManager();
            // Retrieve the textbox controls.
            JTextbox login = (JTextbox)cm.getControl("tbLogin");
            JTextbox password = (JTextbox)cm.getControl("tbPassword");
            // Check the size of the input
            String szLogin = login.getText();
            String szPassword = password.getText();
            if( szLogin.length() < MIN_LOGIN_LENGHT || szLogin.length() > MAX_LOGIN_LENGHT ||
                szPassword.length() < MIN_LOGIN_LENGHT || szPassword.length() > MAX_LOGIN_LENGHT )
            {
                // Show Messagebox!
                // TODO: Show MessageBox
            }
            // Login into the server!
            // TODO: Login into the server
        }
    };

}
