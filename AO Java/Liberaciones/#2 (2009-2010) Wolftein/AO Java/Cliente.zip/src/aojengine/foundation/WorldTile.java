/*
 * @(#)WorldTile.java	1.0 Mar 5, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package aojengine.foundation;

import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Mar 5, 2010
 * @since
 */
public class WorldTile implements Cloneable {

    private final static int DEFAULT_START_Z  = 100;
    private final static int MAX_SPRITE_LAYER = 5;

    protected Sprite[] tile = new Sprite[5];
    protected Entity character;
    protected Entity item;
    protected boolean blocked;
    protected Trigger[] trigger;

    public WorldTile() {
        this.tile = new Sprite[MAX_SPRITE_LAYER];
    }

    public void render(Graphics2D g, int x, int y, int charX, int charY, float renderTime) {
        if (tile[0] != null) {
            tile[0].Render(g, x, y, DEFAULT_START_Z, renderTime, true, false);
        }
        if (tile[1] != null) {
            tile[1].Render(g, x, y, DEFAULT_START_Z - 1, renderTime, true, true);
        }
        if (tile[2] != null) {
            tile[2].Render(g, x, y, DEFAULT_START_Z - 2, renderTime, true, true);
        }
        if (character != null) {
            character.render(g, charX, charY, DEFAULT_START_Z - 3);
        }
        if (tile[3] != null) {
            tile[3].Render(g, x, y, DEFAULT_START_Z - 4, renderTime, true, true);
        }
        if (tile[4] != null) {
            tile[4].Render(g, x, y, DEFAULT_START_Z - 5, renderTime, true, true);
        }
    }

    public void setTile( int layer, Sprite tileSprite ) {
        tile[layer] = tileSprite;
    }

    public Sprite getTile( int layer ) {
        return tile[layer];
    }

    public void setBlock( boolean value ) {
        blocked = value;
    }

    @Override
    public Object clone() {
        WorldTile f = new WorldTile();
        f.tile = tile;
        f.character = character;
        f.item = item;
        f.blocked = blocked;
        f.trigger = trigger;
        return f;
    }

}
