/*
 * @(#)CharacterEntity.java	1.0 Mar 5, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package aojengine.foundation.entity;

import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import aojengine.foundation.Entity;
import aojengine.foundation.Sprite;
import aojengine.foundation.Sprite.SpriteAnimationType;
import aojengine.foundation.SpriteData;
import aojengine.foundation.SpriteManager;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Mar 5, 2010
 * @since
 */
public class CharacterEntity extends Entity {

    /** Entity Direction Types **/
    protected final static int ENTITY_MAX_DIRECTION = 4;

    /** Entity Head Sprite List **/
    protected Sprite[] headSprite;
    /** Entity Body Sprite List **/
    protected Sprite[] bodySprite;
    protected int[]    bodyOffset;
    /** Entity Movement **/
    protected boolean  movement;

    /**
     * Constructor
     *
     * @param name
     * @param x
     * @param y
     */
    public CharacterEntity( String name, int x, int y ) {
        // Constructor of <br>Entity</br>
        super( name, 2, x,  y);
        // This entity is animated
        this.setAnimated(true);
        // Create the Sprite list.
        headSprite = new Sprite[ENTITY_MAX_DIRECTION];
        bodySprite = new Sprite[ENTITY_MAX_DIRECTION];
    }

    /**
     * Set the character head.
     *
     * @param index Number of the head.
     */
    public void setHead(int index) {
        // get the head data.
        int[] headData = SpriteManager.getHead(index);
        // Load each head sprite.
        for (int i = 0; i < ENTITY_MAX_DIRECTION; i++) {
            // Create the sprite.
            headSprite[i] = new Sprite(headData[i], SpriteAnimationType.Loop);
        }
        // Set default Sprite Entity.
        this.setSprite(0, headSprite[0]  );
    }

    /**
     * Set the character body.
     *
     * @param index Number of the body
     */
    public void setBody(int index) {
        // get the head data.
        int[] bodyData = SpriteManager.getBody(index);
        // Base Body it's always the second -1 frame.
        int baseBody = bodyData[1] - 1;
        SpriteData baseBodySprite = SpriteManager.getSprite(baseBody);
        // Load each head sprite.
        for (int i = 0; i < ENTITY_MAX_DIRECTION; i++) {
            // Create the sprite.
            bodySprite[i] = new Sprite(baseBody, SpriteAnimationType.Loop);
            bodySprite[i].endAnimation();
            // Animation Start and End Frame.
            bodySprite[i].setFrameStart( (baseBodySprite.spriteList.length / ENTITY_MAX_DIRECTION) * i );
            bodySprite[i].setFrameLimit( (baseBodySprite.spriteList.length / ENTITY_MAX_DIRECTION) );
        }
        // Load the offsets
        bodyOffset = new int[2];
        bodyOffset[0] = bodyData[ENTITY_MAX_DIRECTION];
        bodyOffset[1] = bodyData[ENTITY_MAX_DIRECTION + 1];
        // Set default Sprite Entity.
        this.setSprite(1, bodySprite[0] );
        this.setSpritePosition(0, bodyOffset[0], bodyOffset[1] );
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.Entity#moveEntity(int, int)
     */
    @Override
    public boolean moveEntity( int x, int y ) {
        // Does the entity move it self?
        if( super.moveEntity(x, y) == false ) {
            return false;
        }
        movement = true;
        // Check what type of sprite direction made.
        int id = heading.ordinal();
        Sprite[] spriteList = new Sprite[] { headSprite[id], bodySprite[id] };
        // Start the animation of each part.
        bodySprite[id].startAnimation();
        // Set the new sprite direction.
        this.setSprite(spriteList);
        return true;
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.Entity#Render(abGroup.sgGaming.Minix2D.Renderer.Render2D, int, int)
     */
    @Override
    public void render(Graphics2D g, int startTileX, int startTileY, int startTileZ) {
        // Made the entity render.
        super.render(g,startTileX,startTileY,startTileZ);
    }

    /**
     * @see abGroup.sgGaming.Games.Nylox.Client.Engine.Entity#Logical(float)
     */
    @Override
    public void logical(float timeDelta) {
        // Made the entity logical.
        super.logical(timeDelta);
        // Stop the animation of all the character entity.
        if( canMove() == true && movement == true ) {
            this.getSprite(1).endAnimation();
            movement = false;
        }
    }
}
