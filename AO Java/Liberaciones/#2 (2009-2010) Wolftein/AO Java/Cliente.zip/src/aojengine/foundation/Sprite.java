/*
 * @(#)Sprite.java	1.0 Mar 5, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package aojengine.foundation;

import abGroup.sgGaming.Engine.Minix2D.device.Color;
import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.util.Spatial;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Mar 5, 2010
 * @since
 */
public class Sprite {

    /** The fps locked **/
    protected final static float SPRITE_FRAME_PER_SECOND = Engine.ENGINE_FPS;
    /** Enumeration of the diferent type of animation **/
    public static enum SpriteAnimationType {
        Single,
        Loop
    };
    /** Spakt Object, for better renderer **/
    protected Spatial object;
    /** Sprite animation variables **/
    protected int index;
    protected SpriteData sprite;
    protected SpriteAnimationType animationType;
    protected float frame, frameLimit, frameStart;
    protected float currentFrame = 0.0f;
    /** Sprite Animation end **/
    protected boolean animationEnd;

    /**
     * Constructor
     *
     * @param sprite
     */
    public Sprite(int sprite, SpriteAnimationType type) {
        setSprite(sprite);
        setAnimationType(type);
    }

    /**
     * Cloneable constructor
     *
     * @param sprite
     */
    public Sprite(Sprite sprite) {
        setSprite(sprite.sprite);
        setAnimationType(sprite.animationType);
        setFrameLimit(sprite.frameLimit);
        setFrameStart(sprite.frameStart);
        setColor(sprite.getColor());
        setRotation(sprite.getRotation());
        setScale(sprite.getScale());
    }

    /**
     * Set the current sprite data.
     *
     * @param sprite Index of the sprite.
     */
    public void setSprite(int spriteNumber) {
        index = spriteNumber;
        sprite = SpriteManager.getSprite(spriteNumber);
        object = new Spatial(sprite.filename);
        object.setTextureSource(sprite.sourceX, sprite.sourceY,
                sprite.sourceWidth, sprite.sourceHeight);
        frameLimit = sprite.spriteList.length;
        frameStart = 0.0f;
        frame = 0.0f;
    }

    /**
     * Set the current sprite data.
     *
     * @param sprite data of the sprite.
     */
    public void setSprite(SpriteData spriteData) {
        index = spriteData.index;
        sprite = spriteData;
        object = new Spatial(sprite.filename);
        object.setTextureSource(sprite.sourceX, sprite.sourceY,
                sprite.sourceWidth, sprite.sourceHeight);
        frameLimit = sprite.spriteList.length;
        frameStart = 0.0f;
        frame = 0.0f;
    }

    /**
     * Set the animation type.
     *
     * @param type Enumeration(Single,Loop)
     */
    public void setAnimationType(SpriteAnimationType type) {
        animationType = type;
    }

    /**
     * Set a limit of a frame.
     *
     * @param limit
     */
    public void setFrameLimit(float limit) {
        frameLimit = limit;
    }

    /**
     * Set the frame start.
     *
     * @param start
     */
    public void setFrameStart(float start) {
        frameStart = start;
    }

    /**
     * Rotate the sprite.
     *
     * @param angle The angle to rotate
     */
    public void setRotation(float angle) {
        object.setRotation(angle);
    }

    /**
     * @return The sprite rotation
     */
    public float getRotation() {
        return object.getRotation();
    }

    /**
     * Scale the sprite.
     *
     * @param Scale Relative Multiplier size from 0.0f-inf.f
     */
    public void setScale(float Scale) {
        object.setScale(Scale, Scale);
    }

    /**
     * @return The sprite scale
     */
    public float getScale() {
        return object.getScaleX();
    }

    /**
     * Set the color of the sprite.
     *
     * @param c The color to set.
     */
    public void setColor(Color c) {
        object.setColor(c);
    }

    /**
     * @return The sprite color
     */
    public Color getColor() {
        return object.getColor();
    }

    /**
     * Start the animation.
     */
    public void startAnimation() {
        animationEnd = false;
    }

    /**
     * Pause the animation.
     */
    public void pauseAnimation() {
        animationEnd = true;
    }

    /**
     * End the animation.
     */
    public void endAnimation() {
        pauseAnimation();
        frame = frameStart;
        currentFrame = 0.0f;
    }

    /**
     * @return The sprite index within the database.
     */
    public int getSpriteID() {
        return index;
    }

    /**
     * Make the frame time.
     *
     * @param time The time passed
     * @return the frame of the sprite.
     */
    protected SpriteData getNextFrame(float time) {
        // new frame;
        currentFrame++;
        // Animation current frame.
        frame = ((currentFrame * frameLimit) / SPRITE_FRAME_PER_SECOND) + frameStart;
        // Check for end.
        if (frame >= (frameLimit + frameStart)) {
            // Reset the frame.
            currentFrame = 0;
            frame = (frameStart - 1.0f < 0.0f ? 0.0f : frameStart);
            // Check for end.
            if (animationType == SpriteAnimationType.Single) {
                animationEnd = true;
            }
        }
        return SpriteManager.getSprite(sprite.spriteList[(int) frame]);
    }

    /**
     * Render the sprite.
     *
     * @param X The position to render.
     * @param Y The position to render.
     * @param animation TRUE if it's animated.
     * @param center TRUE if we need to center the tile.
     */
    public void Render(Graphics2D g, int X, int Y, int Z, float time, boolean animation, boolean center) {
        SpriteData spriteRender = sprite;
        // if it's an animation, then check for the next frame.
        if (animation == true) {
            // End the animation.
            if (animationEnd == false && sprite.spriteList.length > 1) {
                spriteRender = getNextFrame(time);
                //} else {
                //    spriteRender = SpriteManager.pkSprite.pkSprite[pkSprite.pkSprite[(int)pkFrame]];
            }
        }
        // if we need to center the tile then do it.
        if (center == true) {
            X = X; // Todo; Sprite#CenterX
            Y = Y; // Todo: Sprite#CenterY
        }
        // Set the object render
        object.setTextureSource(spriteRender.sourceX, spriteRender.sourceY,
                spriteRender.sourceWidth, spriteRender.sourceHeight);
        // set the position where to render.
        object.setLocation(X, Y, Z);
        // Render the spakt
        object.drawSpatial(g, null);
    }
}
