/*
 * @(#)Entity.java	1.0 Mar 5, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package aojengine.foundation;

import abGroup.sgGaming.Engine.Minix2D.device.Color;
import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Mar 5, 2010
 * @since
 */
public class Entity {


    /** Max Speed Movement **/
    protected final static float ENTITY_SPEED_MOVEMENT_MAX = 1024.0f;
    protected final static float ENTITY_SPEED_MOVEMENT_DEFAULT = 520.0f;

    /** Scrolling px (1,25f per frame at 60 frame ) **/
    protected final static float ENTITY_SCROLL_PER_FRAME = 1.25f;

    /** Entity Heading **/
    public static enum enumEntityHeading {
        // Normal four direction of a 2D game.
        SOUTH,
        NORTH,
        WEST,
        EAST,
        // None Heading
        NONE,
        // Normal four+ direction of isometric game.
        NORTH_WEST,
        NORTH_EAST,
        SOUTH_WEST,
        SOUTH_EAST
    };

    /** Name of the entity **/
    protected String name;

    /** Entity Speed Variable **/
    protected float speedMovement = ENTITY_SPEED_MOVEMENT_DEFAULT;

    /** This are the sprite that make the entity renderable **/
    protected Sprite[] entityRender;
    protected int[][]  entityRenderPosition;

    /** Entity TILE position **/
    protected int tilePositionX, tilePositionY;
    protected enumEntityHeading heading;

    /** Entity Property **/
    protected boolean center, animated;
    protected float   timePassed;
    protected float   scale = 1.0f, rotation = 0.0f;
    protected Color   color;

    /** Entity visibility **/
    protected boolean visible;

    /** Entity scrolling **/
    protected float   scrollX, scrollY;
    protected boolean scrollDirectionTopX, scrollDirectionTopY;


    /**
     * Constructor.
     *
     * @param name The name of the entity.
     * @param size The amount of sprite that has the entity.
     */
    public Entity( String name, int size ) {
        this.name = name;
        entityRender = new Sprite[size];
        entityRenderPosition = new int[size][2];
    }

    /**
     * Constructor
     *
     * @param name The name of the entity.
     * @param size The amount of sprite that has the entity.
     * @param x the started position x of the entity tile.
     * @param y the started position y of the entity tile.
     */
    public Entity( String name, int size, int x, int y ) {
        this(name,size);
        tilePositionX = x;
        tilePositionY = y;
    }

    /**
     * Construct the sprite list of the entity.
     *
     * @param spriteList List of sprite for renderer.
     */
    public void setSprite( Sprite[] spriteList ) {
        entityRender = spriteList;
    }

    /**
     * Set a sprite in the sprite list of the entity.
     *
     * @param index The index of the sprite.
     * @param sprite The sprite data for the entity.
     */
    public void setSprite( int index, Sprite sprite ) {
        entityRender[index] = sprite;
    }

    /**
     * Set a sprite part of the entity position.
     *
     * @param index The index of the sprite.
     * @param x The position x of the sprite.
     * @param y The position y of the sprite.
     */
    public void setSpritePosition( int index, int x, int y ) {
        entityRenderPosition[index][0] = x;
        entityRenderPosition[index][1] = y;
    }

    /**
     * Set the property animated of the entity.
     *
     * @param value TRUE or FALSE
     */
    public void setAnimated( boolean value ) {
        animated = value;
    }

    /**
     * Set the property center of the entity.
     *
     * @param value TRUE or FALSE
     */
    public void setCenter( boolean value ) {
        center = value;
    }

    /**
     * Set the visibility of the entity.
     *
     * @param value TRUE or FALSE
     */
    public void setVisible( boolean value ) {
        visible = value;
    }

    /**
     * Set the scale of the entity.
     *
     * @param scale
     */
    public void setSize(float scale) {
        this.scale = scale;
        for (int i = 0; i < entityRender.length; i++) {
            entityRender[i].setScale(scale);
        }
    }

    /**
     * Set the rotation of the entity.
     *
     * @param angle
     */
    public void setRotation( float angle ) {
        rotation = angle;
        for (int i = 0; i < entityRender.length; i++) {
            entityRender[i].setRotation(angle);
        }
    }

    /**
     * Set the color of the entity.
     *
     * @param c
     */
    public void setColor( Color c ) {
        color = c;
        for (int i = 0; i < entityRender.length; i++) {
            entityRender[i].setColor(c);
        }
    }

    /**
     * Set the entity movement speed.
     *
     * @param value
     */
    public void setMovementSpeed( float value ) {
        if( value > ENTITY_SPEED_MOVEMENT_MAX ) { value = ENTITY_SPEED_MOVEMENT_MAX; }
        speedMovement = value;
    }

    /**
     * @return The position x of the character
     */
    public int getPositionX() {
        return tilePositionX;
    }

    /**
     * @return The position y of the character
     */
    public int getPositionY() {
        return tilePositionY;
    }

    /**
     * Return a sprite renderer of this entity.
     *
     * @param index
     * @return
     */
    public Sprite getSprite( int index ) {
        return entityRender[index];
    }

    /**
     * @return If the character can move.
     */
    public boolean canMove() {
        return scrollX == 0 && scrollY == 0;
    }

    /**
     * @return The entity scrolling x
     */
    public float getScrollX() {
        return scrollX;
    }

    /**
     * @return The entity scrolling y
     */
    public float getScrollY() {
        return scrollY;
    }


    /**
     * Move the entity to a tile position.
     *
     * @param x Position x of a tile.
     * @param y Position y of a tile.
     * @return TRUE if we move the entity.
     */
    public boolean moveEntity( int x, int y ) {
        // The entity can be move only if it's not already moving.
        if( canMove() ) {
            findEntityScrollDirection(x,y);
            tilePositionX += x;
            tilePositionY += y;
            return true;
        }
        return false;
    }

    /**
     * Find the scrolling variables.
     * @param x
     * @param y
     */
    protected void findEntityScrollDirection(int x, int y) {
        heading = enumEntityHeading.NONE;
        // Make the positions diference.
        int dirX = (tilePositionX + x) - tilePositionX;
        int dirY = (tilePositionY + y) - tilePositionY;
        // Check for the Direction.
        if (dirY == -1) {
            scrollDirectionTopY = true;
            scrollY = 32;
            heading = enumEntityHeading.NORTH;
        } else if (dirY == 1) {
            scrollDirectionTopY = false;
            scrollY = -32;
            heading = enumEntityHeading.SOUTH;
        }
        if (dirX == -1) {
            scrollDirectionTopX = true;
            scrollX = 32;
            heading = (heading == enumEntityHeading.NONE ? enumEntityHeading.WEST : heading == enumEntityHeading.NORTH ? enumEntityHeading.NORTH_WEST : enumEntityHeading.SOUTH_WEST);
        } else if (dirX == 1) {
            scrollDirectionTopX = false;
            scrollX = -32;
            heading = (heading == enumEntityHeading.NONE ? enumEntityHeading.EAST : heading == enumEntityHeading.NORTH ? enumEntityHeading.NORTH_EAST : enumEntityHeading.SOUTH_EAST);
        }
    }

    /**
     * @return The entity heading.
     */
    public enumEntityHeading getHeading() {
        return heading;
    }

    /**
     * Entity render function. This function render all the entity sprites.
     *
     * @param g The render callback
     * @param timeDelta Time passed.
     * @param startTileX From where it's start the render.
     * @param startTileY From where it's start the render.
     */
    public void render(Graphics2D g, int startTileX, int startTileY, int startTileZ) {
        // Render only if it's visible
        if (visible == false) {
            // render all the entity sprites.
            for (int i = 0; i < entityRender.length; i++) {
                entityRender[i].Render(g,
                        (int) ((tilePositionX - startTileX) * Global.TILE_SIZE + scrollX + entityRenderPosition[i][0] * scale),
                        (int) ((tilePositionY - startTileY) * Global.TILE_SIZE + scrollY + entityRenderPosition[i][1] * scale),
                        startTileZ,
                        timePassed,
                        animated,
                        center);
            }
        }
    }

    /**
     * Entity logical function. This function make the entity logical.
     *
     * @param timeDelta
     */
    public void logical(float timeDelta) {
        timePassed = timeDelta;
        // Make the scrolling entity
        if (scrollX != 0) {
            if (scrollDirectionTopX == true) {
                scrollX -= (speedMovement * ENTITY_SCROLL_PER_FRAME) / ENTITY_SPEED_MOVEMENT_MAX;
                scrollX = (scrollX < 0 ? 0 : scrollX);
            } else {
                scrollX += (speedMovement * ENTITY_SCROLL_PER_FRAME) / ENTITY_SPEED_MOVEMENT_MAX;
                scrollX = (scrollX > 0 ? 0 : scrollX);
            }
        }
        if (scrollY != 0) {
            if (scrollDirectionTopY == true) {
                scrollY -= (speedMovement * ENTITY_SCROLL_PER_FRAME) / ENTITY_SPEED_MOVEMENT_MAX;
                scrollY = (scrollY < 0 ? 0 : scrollY);
            } else {
                scrollY += (speedMovement * ENTITY_SCROLL_PER_FRAME) / ENTITY_SPEED_MOVEMENT_MAX;
                scrollY = (scrollY > 0 ? 0 : scrollY);
            }
        }
    }
}
