/*
 * @(#)Trigger.java	1.0 Mar 5, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package aojengine.foundation;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Mar 5, 2010
 * @since
 */
public abstract class Trigger {

    /** Trigger Types **/
    public static enum typeTrigger {
        // This type of trigger has a targe sprite.

        TARGET_SPRITE
    };
    /** World Variable **/
    protected World world;

    /**
     * Pass the world variable for use of it.
     *
     * @param world
     */
    public void setWorld(World world) {
        this.world = world;
    }

    /**
     * @return The trigger type.
     */
    public abstract typeTrigger getTriggerType();

    /**
     * @return The trigger id number.
     */
    public abstract int getTriggerID();

    /**
     * Run the trigger logical.
     */
    public abstract void logical();

    /**
     * @return The trigger id name.
     */
    public abstract String getTriggerName();

    /**
     * @return IF the trigger has finished.
     */
    public abstract boolean isFinish();

    /**
     * Load the trigger data.
     *
     * @param in
     */
    public abstract void load(DataInputStream in) throws IOException;

    /**
     * Save the trigger data.
     *
     * @param out
     */
    public abstract void save(DataOutputStream out) throws IOException;

}
