/*
 * @(#)EngineException.java	1.0 Mar 6, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package aojengine.foundation;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Mar 6, 2010
 * @since
 */
public class EngineException extends Exception {

    public EngineException(String name) {
        super(name);
    }

}
