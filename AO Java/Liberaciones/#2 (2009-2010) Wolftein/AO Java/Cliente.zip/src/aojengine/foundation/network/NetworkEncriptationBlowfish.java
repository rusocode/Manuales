/*
 * @(#)NetworkEncriptationBlowfish.java	1.0 May 25, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package aojengine.foundation.network;

import aojengine.foundation.NetworkEncriptation;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,May 25, 2010
 * @since
 */
public class NetworkEncriptationBlowfish implements NetworkEncriptation {

    private byte[] keyValue;

    public byte[] BlockEnc(byte[] data) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public byte[] BlockDes(byte[] data) {
        throw new UnsupportedOperationException("Not supported yet.");
    }


    public String StringEnc(String data) {
        byte[] arrayByte = BlockEnc( ConvertStringToByteArray(data) );

        return ConvertByteArrayToString(arrayByte);
    }

    public String StringDes(String data) {
        byte[] arrayByte = BlockDes( ConvertStringToByteArray(data) );

        return ConvertByteArrayToString(arrayByte);
    }

    public void SetKey(byte[] key) {
        keyValue = key;
    }

    private byte[] ConvertStringToByteArray( String str ) {
        byte[] array = new byte[str.length() + 1];
        for( int i = 0; i < array.length - 1; i++ ) {
            array[i] = (byte)str.charAt(i);
        }
        array[array.length] = 0x0;
        return array;
    }

    private String ConvertByteArrayToString( byte[] array ) {
        char[] charArray = new char[array.length];
        System.arraycopy(array, 0, charArray, 0, array.length);
        return String.valueOf(charArray);
    }
}
