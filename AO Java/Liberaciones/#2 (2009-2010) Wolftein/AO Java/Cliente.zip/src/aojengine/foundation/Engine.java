/*
 * @(#)Engine.java	1.0 Mar 5, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package aojengine.foundation;

import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import aojengine.foundation.Entity.enumEntityHeading;
import java.io.IOException;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Mar 5, 2010
 * @since
 */
public class Engine {

    public final static float ENGINE_FPS = 60.0f;
    protected Entity character;
    protected World world;

    public Engine(Vector2f viewport) {
        world = new World(viewport);
        character = new Entity("FreeView", 0);
    }

    public void render(Graphics2D g) {
        if (world.isLoaded()) {
            world.render(g, character.getPositionX(), character.getPositionY(),
                    character.getScrollX(), character.getScrollY());
        }
    }

    public void logical(float timeDelta) {
        if (world.isLoaded()) {
            world.logical(timeDelta);
        }
    }

    public void setWorld(World world) {
        this.world = world;
        this.world.loaded = Boolean.TRUE;
    }

    public void setWorld(String worldFilename) throws EngineException {
        if (world != null) {
            world.reset();
        }
        try {
            world.load(worldFilename);
        } catch (IOException ex) {
            throw new EngineException("Error loading world map");
        }
    }

    public Entity getUserEntity() {
        return character;
    }

    public void move(enumEntityHeading h) {
        switch (h) {
            case SOUTH:
                character.moveEntity(0, +1);
                break;
            case NORTH:
                character.moveEntity(0, -1);
                break;
            case EAST:
                character.moveEntity(-1, 0);
                break;
            case WEST:
                character.moveEntity(+1, 0);
                break;
        }
    }
}
