/*
 * @(#)SpriteManager.java	1.0 Mar 5, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package aojengine.foundation;

import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import java.io.DataInputStream;
import java.io.IOException;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Mar 5, 2010
 * @since
 */
public class SpriteManager {
    
    private final static int   DEFAULT_SPRITE_SIZE  = Global.TILE_SIZE;
    private final static float DEFAULT_SPRITE_SPEED = 1.0000f;

    /** Structure for sprite file **/
    public static class SpriteFileClass {

        public String version;
        public SpriteData[] spriteList;
    }

    /** List of Sprites in the game **/
    protected static SpriteFileClass spriteFile;
    /** List of Character Sprites Data **/
    protected static int[][] headList;
    protected static int[][] bodyList;
    protected static int[][] weaponList;

    /**
     * Load the Sprite data from the a file.
     *
     * @param Filename The file where to load
     */
    public static boolean initModule(String filename){
        DataInputStream in = Runtime.getClassLoader().getResourceAsStream(filename);
        try {
            spriteFile = new SpriteFileClass();
            // Load the version of the file
            spriteFile.version = in.readUTF();
            // Load each Sprite data
            spriteFile.spriteList = new SpriteData[in.readInt()];
            for (int i = 0; i < spriteFile.spriteList.length; i++) {
                spriteFile.spriteList[i] = new SpriteData();
                spriteFile.spriteList[i].index = i;
                // Get the Frame list
                byte frameList = in.readByte();
                if (frameList > 0) {
                    spriteFile.spriteList[i].spriteList = new int[frameList];
                    for (int j = 0; j < frameList; j++) {
                        spriteFile.spriteList[i].spriteList[j] = in.readInt();
                    }
                    spriteFile.spriteList[i].speed = in.readFloat();
                } else {
                    spriteFile.spriteList[i].spriteList = new int[1];
                    spriteFile.spriteList[i].spriteList[0] = i;
                    spriteFile.spriteList[i].speed = DEFAULT_SPRITE_SPEED;
                }
                // Load the sprite data.
                spriteFile.spriteList[i].filename = in.readUTF();
                spriteFile.spriteList[i].sourceX = in.readShort();
                spriteFile.spriteList[i].sourceY = in.readShort();
                spriteFile.spriteList[i].sourceWidth = in.readShort();
                spriteFile.spriteList[i].sourceHeight = in.readShort();
                // Precalculate the tile's
                spriteFile.spriteList[i].computedPixelX = spriteFile.spriteList[i].sourceWidth / DEFAULT_SPRITE_SIZE;
                spriteFile.spriteList[i].computedPixelY = spriteFile.spriteList[i].sourceHeight / DEFAULT_SPRITE_SIZE;
            }
            // Now load each character data sprite.
            headList = new int[in.readInt()][4]; // Load the HEAD data.
            for (int i = 0; i < headList.length; i++) {
                headList[i][0] = in.readInt();
                headList[i][1] = in.readInt();
                headList[i][2] = in.readInt();
                headList[i][3] = in.readInt();
            }
            bodyList = new int[in.readInt()][6];  // Load the BODY data.
            for (int i = 0; i < bodyList.length; i++) {
                bodyList[i][0] = in.readInt();
                bodyList[i][1] = in.readInt();
                bodyList[i][2] = in.readInt();
                bodyList[i][3] = in.readInt();
                bodyList[i][4] = in.readInt();
                bodyList[i][5] = in.readInt();
            }
            weaponList = new int[in.readInt()][4]; // Load the WEAPON data.
            for (int i = 0; i < weaponList.length; i++) {
                weaponList[i][0] = in.readInt();
                weaponList[i][1] = in.readInt();
                weaponList[i][2] = in.readInt();
                weaponList[i][3] = in.readInt();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }

    public static SpriteData getSprite( int index ) {
        return spriteFile.spriteList[index];
    }

    /**
     * Get a body from the entity head list.
     *
     * @param index
     * @return
     */
    public static int[] getHead( int index ) {
        return headList[index];
    }

    /**
     * Get a body from the entity body list.
     *
     * @param index
     * @return
     */
    public static int[] getBody( int index ) {
        return bodyList[index];
    }

}
