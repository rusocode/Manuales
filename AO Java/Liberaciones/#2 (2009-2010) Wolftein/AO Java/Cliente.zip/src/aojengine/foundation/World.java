/*
 * @(#)World.java	1.0 Mar 5, 2010
 *
 * Copyright 2010 AB Group, Inc. All rights reserved.
 * ABGROUP PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package aojengine.foundation;

import abGroup.sgGaming.Engine.Minix2D.device.Graphics2D;
import abGroup.sgGaming.Engine.Minix2D.kernel.Runtime;
import abGroup.sgGaming.Engine.Minix2D.math.FastMath;
import abGroup.sgGaming.Engine.Minix2D.math.Vector2f;
import aojengine.foundation.Sprite.SpriteAnimationType;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;

/**
 * @author Agustin L. Alvarez
 * @version 1.0 ,Mar 5, 2010
 * @since
 */
public class World {

    /** Renderer Constant **/
    protected final static int RENDER_TILE_SIZE = Global.TILE_SIZE;
    protected final static int RENDER_OFFSCREEN_TILE = 15; // 10x10 offscreen renderer.

    /** Constant that indicate the cell flag at the load time **/
    protected final static int FLAG_LOAD_VALID = 2^0,
                               FLAG_LOAD_BLOCK = 2^1;

    protected String version, name, music;
    public WorldTile[][] worldTile;
    protected ArrayList<Trigger> executeTrigger = new ArrayList<Trigger>();
    protected int renderViewX, renderViewY;
    protected float  renderTime;
    protected boolean loaded;

    public World(Vector2f viewport) {
        setWorldView((int)viewport.x, (int)viewport.y);
    }

    /**
     * Load a world map from a source.
     *
     * @param name The name of the map to load.
     * @return TRUE if we load succesfull./
     */
    public void load(String name) throws IOException {
        byte mapFlag = 0;
        // Open the map file.
        DataInputStream in = Runtime.getClassLoader().getResourceAsStream(name);
        // Load the map property.
        version = in.readUTF();
        name = in.readUTF();
        music = in.readUTF();
        // Load each map tile.
        worldTile = new WorldTile[in.readInt()][in.readInt()];
        for (int x = 0; x < worldTile.length; x++) {
            for (int y = 0; y < worldTile[x].length; y++) {
                // Read the flag that contain information related to the cell
                // this flags make the map contain less information with just
                // only one more byte in each cell.
                mapFlag = in.readByte();
                // Always check if we need to allocate the cell
                if ((mapFlag | FLAG_LOAD_VALID) > 0) {
                    // Allocate the cell in the memory
                    worldTile[x][y] = new WorldTile();
                    // Set the blocked function of the cell
                    worldTile[x][y].blocked = ((mapFlag | FLAG_LOAD_BLOCK) > 0);
                    for (int i = 0; i < worldTile[x][y].tile.length; i++) {
                        // That tile contain TILE information.
                        if (in.readBoolean() == true) {
                            worldTile[x][y].tile[i] = new Sprite(in.readInt(), SpriteAnimationType.Loop);
                        }
                    }
                    // Load the trigger
                    // Todo Trigger load.
                }
            }
        }
        loaded = true;
    }


    /**
     * Render the game world map and all of his entity without buffer optimization
     * but supported by all.
     *
     * [NOTE]: Z from 100.0f - 97.0f
     *
     * @param g
     * @param x
     * @param y
     * @param scrollX
     * @param scrollY
     */
    public void render(Graphics2D g, int x, int y, float scrollX, float scrollY) {
        // get the min and max position for render.
        int renderTileMinX = x - renderViewX - RENDER_OFFSCREEN_TILE;
        int renderTileMinY = y - renderViewY - RENDER_OFFSCREEN_TILE;
        int renderTileMaxX = x + renderViewX + RENDER_OFFSCREEN_TILE;
        int renderTileMaxY = y + renderViewY + RENDER_OFFSCREEN_TILE;
        // get the tile bound.
        int renderTileMinBoundX = (int) FastMath.clamp(0, renderTileMinX, worldTile.length);
        int renderTileMinBoundY = (int) FastMath.clamp(0, renderTileMinY, worldTile[0].length);
        int renderTileMaxBoundX = (int) FastMath.clamp(0, renderTileMaxX, worldTile.length);
        int renderTileMaxBoundY = (int) FastMath.clamp(0, renderTileMaxY, worldTile[0].length);
        int renderTileStartScreenX = (renderTileMinX >= 0 ? 0 : (-renderTileMinX) * RENDER_TILE_SIZE) - (RENDER_OFFSCREEN_TILE * RENDER_TILE_SIZE);
        int renderTileStartScreenY = (renderTileMinY >= 0 ? 0 : (-renderTileMinY) * RENDER_TILE_SIZE) - (RENDER_OFFSCREEN_TILE * RENDER_TILE_SIZE);
        // Start the rendering of the screen.
        for (int j = renderTileMinBoundX; j < renderTileMaxBoundX; j++) {
            // Render(X0..Y0..Yn..X1..Y0..Yn..Xn..Yn)
            for (int k = renderTileMinBoundY; k < renderTileMaxBoundY; k++) {
                if (worldTile[j][k] != null) {
                    worldTile[j][k].render(g,
                            (int) ((j - renderTileMinBoundX) * 32 + scrollX) + renderTileStartScreenX,
                            (int) ((k - renderTileMinBoundY) * 32 + scrollY) + renderTileStartScreenY,
                            renderTileMinBoundX,
                            renderTileMinBoundY,
                            renderTime);
                }
            }
        }
    }

    /**
     * Reset all the world variables.
     */
    public void reset( ) {
        worldTile = null;
        loaded = false;
    }

    public boolean isLoaded() {
        return loaded;
    }

    /**
     * Set the world view client.

     * @param width
     * @param height
     */
    public void setWorldView( int width, int height ) {
        renderViewX = (width / 32) / 2;
        renderViewY = ((height+1) / 32) / 2;
    }

    /**
     * Execute a trigger of a tile position.
     *
     * @param x
     * @param y
     */
    public void executeTrigger(int x, int y) {
        // execute valid trigger.
        if (worldTile[x][y] != null) {
            // Does the tile contain a trigger?
            if (worldTile[x][y].trigger != null) {
                // check the list of triggers
                for (int i = 0; i < worldTile[x][y].trigger.length; i++) {
                    // Check for not same trigger executing.
                    if (executeTrigger.contains(worldTile[x][y].trigger[i]) == false) {
                        executeTrigger.add(worldTile[x][y].trigger[i]);
                    }
                }
            }
        }
    }

    /**
     * Do the logical of the game world map and all of his entity.
     *
     * @param timeDelta
     */
    public void logical(float timeDelta) {
        renderTime = timeDelta;
        // execute all the trigger.
        for (int i = 0; i < executeTrigger.size(); i++) {
            executeTrigger.get(i).logical();
            // End the trigger.
            if (executeTrigger.get(i).isFinish() == true) {
                executeTrigger.remove(i);
            }
        }
    }
}
